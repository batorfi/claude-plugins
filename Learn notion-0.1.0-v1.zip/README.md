# learn-notion

A self-paced learning mentor for Cowork. Claude teaches; your learning paths, progress, quizzes, flashcards and review schedule live in Notion.

## Skills

| Skill | What it does |
|---|---|
| `learn` | Create a path, continue a lesson, quiz, help when stuck, status, modify the path, spaced-repetition reviews, flashcards |
| `learn-setup` | One-time: builds the Notion **Learning** hub with its six databases, formulas, views and config block |
| `learn-import` | Migrates a learning path from the old file-based PPW `learn` tool |

## Requirements

- The Notion connector, with access to the page where the hub lives.
- For `learn-import`: the PPW folder linked to the session.

## Notion layout

**Learning** (top-level page) → Paths · Modules · Lessons · Quizzes · Flashcards · Journal, plus a **Plugin config** block that Claude reads to find the databases. Full schema: `skills/learn/references/schema.md`.

Useful views to open on your own:

- Lessons → **Review queue** and **Board**
- Flashcards → **By due date** and **Calendar**
- Journal → **Struggles**

## Design notes

- Progress counts are Notion rollups, so they can't drift. The Notion connector can't read formula or rollup values, so Claude recomputes what it shows from lesson statuses. It can filter on formulas, which is how due reviews are found.
- Spaced repetition: lessons at 1/3/7/30 days after completion; flashcards each on their own 1/3/7/30/90-day ladder.
- "Remove" marks pages Skipped and `[removed]`, since the connector can't delete pages.
