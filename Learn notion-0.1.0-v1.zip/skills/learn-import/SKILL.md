---
name: learn-import
description: Migrates a learning path from the old file-based PPW learn tool (knowledge/**/path.md, journal.md, flashcards/, quizzes/, reviews/completion_log.md) into the Notion Learning hub. Use when the user says "import my learning path", "move my Rust path to Notion", or "migrate the PPW learning paths".
---

# Import a PPW learning path into Notion

Requires the Learning hub (run `learn-setup` if it's missing) and access to the PPW folder on the user's computer. Read `../learn/references/schema.md` first.

## 1. Locate and parse (on the user's computer)

Path folders look like `knowledge/<subfolder>/<YYYYMMDD-HHMMSS>_<slug>/`. List them, confirm which one(s) to import, and check the Paths database for an existing row whose Source names the same folder (skip those unless the user wants a re-import).

Parse with a short python script in the user's shell — never retype the file by hand:

- `path.md` header → Name (title), Status (in-progress → In progress, etc.), Level (skill_level), Daily time, Duration, Tags, Learning style, Started (created date), Last active (last_active_date), Current/Longest streak, Branch choices.
- `path.md` body → `## Overview` and `## Milestones` (copy into the path page body).
- Modules: `^## Module (\d+):\s*(.+?)\s*\[(COMPLETED|IN-PROGRESS|NOT-STARTED|SKIPPED)\](?:\s*\[BRANCH:([\w-]+)\])?`
- Lessons: `^### Lesson (\d+)\.(\d+):\s*(.+?)\s*\[(COMPLETED|CURRENT|NOT-STARTED|SKIPPED)\]` plus the `- **Objective**/**Time**/**Exercises**/**Resources**:` lines under each.
- `reviews/completion_log.md` lines `- Lesson M.N: YYYY-MM-DD HH:MM`.
- `flashcards/*_lesson-M-N_flashcards.md` → `**Front**:` / `**Back**:` pairs.
- `quizzes/*_module-N_quiz.md` → header score/total/created + body.
- `journal.md` → `## YYYY-MM-DD HH:MM — …` entries.

Show the user a summary (modules, lessons by status, cards, quizzes, journal entries) before writing.

## 2. Reconcile completion dates — avoid the stale-log bug

The old tool never cleared `completion_log.md` when a path was reset, so the log can list lessons that are no longer completed.

- For each lesson that is **COMPLETED in path.md**, use its **latest** log entry as `Completed at`. Earlier entries for the same lesson count as reviews only if they are later than the latest reset (look for a "reset"/"restart" journal entry); otherwise ignore them. Set Review count = number of counted reviews (max 4) and Last reviewed = the last one.
- Ignore log entries for lessons that are not COMPLETED in path.md. Mention how many were dropped and why.

## 3. Write to Notion (order matters)

1. Add any missing Tags options to Paths (schema.md → multi-select rule).
2. Create the Path row; Source = `Imported <today> from PPW/<relative folder>`. Body: Overview, Milestones, and a `## History` paragraph built from the journal.
3. Create the Modules (keep returned IDs by number).
4. Create the Lessons in batches of ≤ 100 with Path, Module, Code, Order (module×100 + lesson), Status, text fields, Review count, and the dates from step 2.
5. Flashcards: Path + Lesson, Step 0. Due = today if the lesson is Completed now, otherwise empty (scheduled later by **advance**).
6. Quizzes: if the path was reset after the quiz was taken, link the quiz to its **Module only** and prefix the Name with `[1st attempt]` so it doesn't count toward current stats; otherwise link Path + Module. Body = the quiz markdown.
7. Journal: one row per journal entry (Type completion for "Completed Lesson…", modification for resets/pace changes, note otherwise), plus one "Migrated from the PPW workspace" modification entry.

## 4. Verify

- `rows` query on Lessons for the path: count by Status must equal the counts parsed from path.md, and exactly one lesson is Current (unless the path is completed).
- `Due for review = true` filter returns only Completed lessons.
- Report: what was imported, what was dropped (stale log entries), and the path link. Do not modify or delete the source files.
