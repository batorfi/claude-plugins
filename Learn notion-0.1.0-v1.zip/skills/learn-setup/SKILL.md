---
name: learn-setup
description: 'One-time setup for the learn-notion plugin: builds the Notion "Learning" hub page with its six databases (Paths, Modules, Lessons, Quizzes, Flashcards, Journal), formulas, rollups, views and the plugin config block. Use when the user says "set up learn-notion", "create the learning hub", or when the learn skill can''t find the Learning hub.'
---

# Set up the Learning hub in Notion

Build the hub exactly as below. Property names must match `../learn/references/schema.md`.

## 0. Check first

Search Notion for a page titled `Learning` with a **Plugin config** block. If it exists, stop: setup is done. If a `Learning` page exists without the block, ask before reusing it.

Ask where the hub goes (default: top level of the workspace, next to the user's other areas). Create it with `notion-create-pages` (no parent = private top-level page), icon 🎓, a cover image, and a two-line intro.

## 1. Databases (in this order — later ones reference earlier IDs)

Create each with `notion-create-database`, parent = hub page. Record each returned `collection://` ID: P (Paths), M (Modules), L (Lessons), Q (Quizzes), F (Flashcards), J (Journal).

**Paths**
```
CREATE TABLE ("Name" TITLE, "Status" SELECT('Not started':gray, 'In progress':blue, 'Paused':yellow, 'Completed':green), "Level" SELECT('beginner':green, 'advanced':orange, 'mastery':red), "Daily time" RICH_TEXT, "Duration" RICH_TEXT, "Tags" MULTI_SELECT('learning':gray), "Learning style" RICH_TEXT, "Started" DATE, "Last active" DATE, "Current streak" NUMBER, "Longest streak" NUMBER, "Branch choices" RICH_TEXT, "Source" RICH_TEXT)
```

**Modules**
```
CREATE TABLE ("Name" TITLE, "Path" RELATION('P', DUAL 'Modules'), "Order" NUMBER, "Status" SELECT('Not started':gray, 'In progress':blue, 'Completed':green, 'Skipped':brown), "Branch group" RICH_TEXT, "Started" DATE, "Completed" DATE)
```

**Lessons**
```
CREATE TABLE ("Name" TITLE, "Path" RELATION('P', DUAL 'Lessons'), "Module" RELATION('M', DUAL 'Lessons'), "Code" RICH_TEXT, "Order" NUMBER, "Status" SELECT('Not started':gray, 'Current':blue, 'Completed':green, 'Skipped':brown), "Objective" RICH_TEXT, "Time" RICH_TEXT, "Exercises" RICH_TEXT, "Resources" RICH_TEXT, "Completed at" DATE, "Last reviewed" DATE, "Review count" NUMBER, "Teach-back" SELECT('good':green, 'partial':yellow, 'needs-review':red), "Next review" FORMULA('lets(rc, if(empty(prop("Review count")), 0, prop("Review count")), base, if(empty(prop("Last reviewed")), prop("Completed at"), prop("Last reviewed")), if(prop("Status") == "Completed" and !empty(base) and rc < 4, dateAdd(base, [1, 3, 7, 30].at(rc), "days"), parseDate("")))'))
```

**Quizzes**
```
CREATE TABLE ("Name" TITLE, "Path" RELATION('P', DUAL 'Quizzes'), "Module" RELATION('M', DUAL 'Quizzes'), "Kind" SELECT('module':blue, 'milestone':purple, 'retake':orange), "Score" NUMBER, "Total" NUMBER, "Taken" DATE, "Percent" FORMULA('if(prop("Total") > 0, round(prop("Score") / prop("Total") * 100), 0)'), "Passed" FORMULA('prop("Total") > 0 and prop("Score") / prop("Total") >= 0.7'))
```

**Flashcards**
```
CREATE TABLE ("Front" TITLE, "Back" RICH_TEXT, "Path" RELATION('P', DUAL 'Flashcards'), "Lesson" RELATION('L', DUAL 'Flashcards'), "Step" NUMBER, "Due" DATE, "Last result" SELECT('easy':green, 'ok':blue, 'hard':orange, 'missed':red), "Created" CREATED_TIME, "Due now" FORMULA('!empty(prop("Due")) and prop("Due") <= today()'))
```

**Journal**
```
CREATE TABLE ("Entry" TITLE, "Path" RELATION('P', DUAL 'Journal'), "Lesson" RELATION('L', DUAL 'Journal'), "Type" SELECT('completion':green, 'struggle':red, 'quiz':purple, 'review':blue, 'teach-back':yellow, 'modification':gray, 'note':default), "Date" DATE)
```

## 2. Helper formulas and rollups

Formulas that filter related rows (`prop("Lessons").filter(...)`) are rejected by the API. Use per-row 0/1 formulas and sum them with rollups instead. Run each block with `notion-update-data-source`:

- **Lessons (L):** `ADD COLUMN "Done n" FORMULA('if(prop("Status") == "Completed", 1, 0)'); ADD COLUMN "Active n" FORMULA('if(prop("Status") == "Skipped", 0, 1)'); ADD COLUMN "Current label" FORMULA('if(prop("Status") == "Current", prop("Code") + " " + prop("Name"), "")'); ADD COLUMN "Due for review" FORMULA('!empty(prop("Next review")) and prop("Next review") <= today()')`
- **Quizzes (Q):** `ADD COLUMN "Pass n" FORMULA('if(prop("Passed"), 1, 0)')`
- **Modules (M):** `ADD COLUMN "Lessons done" ROLLUP('Lessons', 'Done n', 'sum'); ADD COLUMN "Lessons total" ROLLUP('Lessons', 'Active n', 'sum'); ADD COLUMN "Done n" FORMULA('if(prop("Status") == "Completed", 1, 0)'); ADD COLUMN "Active n" FORMULA('if(prop("Status") == "Skipped", 0, 1)')` then `ADD COLUMN "Progress %" FORMULA('if(prop("Lessons total") > 0, round(prop("Lessons done") / prop("Lessons total") * 100), 0)')`
- **Paths (P):** `ADD COLUMN "Lessons done" ROLLUP('Lessons', 'Done n', 'sum'); ADD COLUMN "Lessons total" ROLLUP('Lessons', 'Active n', 'sum'); ADD COLUMN "Modules done" ROLLUP('Modules', 'Done n', 'sum'); ADD COLUMN "Modules total" ROLLUP('Modules', 'Active n', 'sum'); ADD COLUMN "Current lesson" ROLLUP('Lessons', 'Current label', 'show_unique'); ADD COLUMN "Quizzes taken" ROLLUP('Quizzes', 'Name', 'count'); ADD COLUMN "Quizzes passed" ROLLUP('Quizzes', 'Pass n', 'sum'); ADD COLUMN "Avg quiz %" ROLLUP('Quizzes', 'Percent', 'average'); ADD COLUMN "Flashcard count" ROLLUP('Flashcards', 'Front', 'count'); ADD COLUMN "Days since active" FORMULA('if(empty(prop("Last active")), 0, dateBetween(today(), prop("Last active"), "days"))')` then `ADD COLUMN "Progress %" FORMULA('if(prop("Lessons total") > 0, round(prop("Lessons done") / prop("Lessons total") * 100), 0)')`

## 3. Views (`notion-create-view`)

Formula properties can't be used in view filters or as calendar dates — filter on plain fields instead.

- Paths → table **Overview**: `SHOW "Name", "Status", "Level", "Current lesson", "Progress %", "Lessons done", "Lessons total", "Modules done", "Modules total", "Avg quiz %", "Current streak", "Last active", "Days since active"`
- Lessons → table **Review queue**: `FILTER "Status" = "Completed"; FILTER "Review count" < 4; SORT BY "Next review" ASC; SHOW "Name", "Code", "Path", "Due for review", "Next review", "Review count", "Last reviewed"`
- Lessons → board **Board**: `GROUP BY "Status"; SORT BY "Order" ASC; SHOW "Name", "Code", "Path", "Time"`
- Flashcards → table **By due date**: `SORT BY "Due" ASC; SHOW "Front", "Back", "Lesson", "Due", "Due now", "Step", "Last result"`; calendar **Calendar**: `CALENDAR BY "Due"`
- Journal → table **Struggles**: `FILTER "Type" = "struggle"; SORT BY "Date" DESC`
- On the hub page (`parent_page_id`): linked table of Paths (**My paths**) and of Lessons (**Review queue**, same config as above).

## 4. Config block

Append to the hub page (`insert_content`, end):

````
## Plugin config
Claude reads this block to find the databases. Don't edit unless a database is recreated.
```json
{
  "learn_notion_config": 1,
  "hub_page": "<hub page id>",
  "paths": "collection://…",
  "modules": "collection://…",
  "lessons": "collection://…",
  "quizzes": "collection://…",
  "flashcards": "collection://…",
  "journal": "collection://…"
}
```
````

## 5. Verify

Fetch each data source and confirm every property from `schema.md` exists. Then fetch the hub page and confirm the config block parses as JSON with all six URLs. Report the hub link and suggest starting a path with `/learn <topic>` or importing one with `learn-import`.
