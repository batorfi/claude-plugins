# Teaching guidelines

## Curriculum calibration

| Level | Module structure | Lesson style |
|---|---|---|
| beginner | Fundamentals first, build up gradually. More modules with shorter lessons. Many guided exercises. | Explain from scratch, examples, step-by-step exercises |
| advanced | Skip basics, intermediate-to-advanced topics. Fewer, deeper modules. | Assume foundations; patterns, trade-offs, complex exercises |
| mastery | Expert topics, real-world application, system design, challenging projects. | Synthesis, design decisions, open-ended problems, case studies |

| Daily time | Lesson sizing |
|---|---|
| 15–30 min | Small, focused lessons. One concept each. |
| 30–60 min | Standard lessons. 1–2 concepts with exercises. |
| 1–2 hours | Larger lessons or several per day. Hands-on projects. |

| Duration | Depth |
|---|---|
| 1 week | Overview: 2–3 modules, 2–4 lessons each |
| 2–4 weeks | Standard: 4–6 modules, 3–5 lessons each |
| 1–3 months | Deep: 6–12 modules, 4–6 lessons each, with projects |
| 3+ months | Extended: 12+ modules, capstone project |

Each lesson's Time must fit the daily time. Add milestones every 2–3 modules ("after Module N").

### Branch points

For alternative tracks, give the alternative modules the same Branch group (e.g. `ui-track`). The learner picks one when they reach it; the rest become Skipped.

## Teaching a lesson

1. Introduce the objective and why it matters.
2. Teach the concepts — clear explanations, examples, analogies, code where relevant.
3. Walk through the lesson's exercises; offer extra ones if useful.
4. Quick probe — 1–2 questions before moving on.

Adapt by level:

- **beginner** — analogies, small steps, invite questions
- **advanced** — concise, nuances and trade-offs
- **mastery** — discussion, multiple perspectives, challenge assumptions

Bias toward the path's **Learning style**. After 2–3 lessons, if no style is saved, note which approaches landed (analogies, code examples, step-by-step, visuals) and save it with set-style.

## Recap on return

Days since Last active:

- ≤ 1 — no recap
- 2–3 — one or two sentences on the last completed lesson
- 4–7 — summarize the last 2–3 completed lessons, one probe question
- 8–30 — summarize progress in the current module, mini-quiz of 2–3 questions
- > 30 — suggest restarting the current module; offer a flashcard review

## Quizzes

| Level | Question types |
|---|---|
| beginner | Recall, definitions, true/false, fill-in-the-blank, simple exercises |
| advanced | Application, comparison, "what would happen if", code review, design |
| mastery | Analysis, synthesis, real-world scenarios, trade-offs, open-ended design |

Counts: module quiz 5–8, milestone 8–12, probe 2–3.

Ask one question at a time. After each answer: judge it (generous partial credit), give the correct answer briefly, and for wrong answers explain why. Pass mark: 70%. Below 70%: encourage, name the weak areas, recommend specific lessons to review, do **not** advance.

## Help when stuck

Ask what exactly is confusing before explaining. Then try, in order: a different angle or analogy → smaller steps → a simpler isolated example → an easier stepping-stone exercise → suggest deeper research. Prefer approaches **not** in the saved Learning style, since the usual approach just failed. Log a struggle entry. Confirm understanding with a follow-up question.

## Teach-back

Every 3–4 completed lessons or at module end: "Explain <concept> in your own words, as if teaching someone else." Evaluate completeness, accuracy and misconceptions; rate good / partial / needs-review.

## Flashcards

3–5 cards per completed lesson. One fact per card, question on the front, short answer on the back, code in backticks.

## Struggle analysis

Run when the learner has needed help 3+ times on a path, or on request.
