# Notion operation recipes

Every recipe uses the data source URLs from the hub's **Plugin config** block (see `schema.md`). `PATH_ID` is the path page's ID. Run steps in order; never skip the guard checks.

Shorthand used below:

- **Q(ds, filter, sort)** — `notion-query-data-sources` with `{"mode":"rows","data_source_url":ds,"filter":…,"sort":…,"limit":100}`
- **C(ds, pages)** — `notion-create-pages` with `parent: {"type":"data_source_id","data_source_id":ds}` and `allow_async: false`
- **U(page, props)** — `notion-update-page` with `command: "update_properties"`

Filter for "rows of this path":

```json
{"type":"property","property":"Path","propertyType":"relation","operator":"relation_contains","value":{"type":"exact","value":"PATH_ID"}}
```

Combine filters with `{"type":"group","operator":"and","filters":[…]}`.

---

## list — all paths

`Q(paths, none, [{"property":"Last active","direction":"descending"}])`. Show Name, Status, Level, Last active. For a progress number per path, run **status** below only for the path the user picks.

## find-path — resolve a name

Match the user's words against Paths.Name (case-insensitive substring). One match → use it. Several → ask. None → offer to create (Flow A).

## status — progress snapshot

1. Fetch the path page (properties + body).
2. `Q(lessons, [path], [{"property":"Order","direction":"ascending"}])`. If 100 rows come back, also query with `Order ≥ last Order + 1` until fewer than 100 return.
3. Compute from Status values: done = Completed, total = all except Skipped, progress % = round(done / total × 100), current = the row with Status Current.
4. Modules: `Q(modules, [path], Order asc)`; count Completed vs not Skipped.
5. Quizzes: `Q(quizzes, [path])`; compute percent = Score/Total and pass (≥ 0.7) per row.
6. Days since active = today − Last active.
7. Pace: elapsed days since Started ÷ total planned days (from Duration) vs progress %. Ahead / on track / behind (±10 points).
8. Due reviews: run **review-due** and report the count.

## create-path — new path from an approved brief

1. If any tag is not yet an option in Paths.Tags, fetch the Paths data source, then `notion-update-data-source` with `ALTER COLUMN "Tags" SET MULTI_SELECT('existing1':color, …, 'new':color)`.
2. `C(paths, [{properties: {Name, Status:"In progress", Level, "Daily time", Duration, Tags (JSON string array), date:Started:start = today, date:Last active:start = today, Current streak: 0, Longest streak: 0}, icon, content: "## Overview …\n\n## Milestones\n- [ ] …"}])` → PATH_ID.
3. `C(modules, …)` one page per module: Name `Module N: Title`, Path `["PATH_ID"]`, Order N, Status (Module 1 = In progress + Started today; others Not started), Branch group if any. Keep the returned IDs by Order.
4. `C(lessons, …)` all lessons (≤100 per call): Name, Path, Module, Code "N.M", Order N×100+M, Status (1.1 = Current, rest Not started), Objective, Time, Exercises, Review count 0.
5. `C(journal, [{Entry:"Path created: <level>, <daily>, <duration>. <n> modules, <m> lessons.", Path, Type:"note", Date: now}])`.

## advance — finish the current lesson

Guard first: `Q(lessons, [path, Status = Current])`.

- 0 rows → if no Not started rows remain, the path is done (go to step 7); otherwise set the lowest-Order Not started lesson to Current and stop.
- 2+ rows → repair: keep the lowest Order as Current, set the others back to Not started, tell the user, continue.

Then:

1. `U(current, {Status:"Completed", date:Completed at:start: now, date:Completed at:is_datetime:1})`.
2. `Q(lessons, [path, Module contains current's module])`. If none in that module is still Not started or Current (ignoring Skipped) → `U(module, {Status:"Completed", date:Completed:start: today})` and remember "module finished".
3. Find the next lesson: `Q(lessons, [path, Status = Not started], Order asc)`, take the first row.
4. **Branch check.** If the module just finished and the next lesson's module has a non-empty Branch group whose choice is not yet recorded in Paths.Branch choices → stop here, list the modules in that group, and run **choose-branch** after the user answers. Do not set a Current lesson before the choice.
5. `U(next, {Status:"Current"})`. If next's module is Not started → `U(next module, {Status:"In progress", date:Started:start: today})`.
6. **Streak.** Read Last active, Current streak, Longest streak. If Last active = today → unchanged. If yesterday → streak + 1. Otherwise → 1. Longest = max(longest, streak). `U(path, {date:Last active:start: today, Current streak, Longest streak})`.
7. If no next lesson exists: `U(path, {Status:"Completed"})` and celebrate (Flow B step 5).
8. Journal: `C(journal, [{Entry:"Completed Lesson M.N: <title>. <notes>", Path, Lesson, Type:"completion", Date: now}])`.
9. Schedule the lesson's existing flashcards: `Q(flashcards, [Lesson contains current, Due is_empty])` → `U(card, {Step:0, date:Due:start: tomorrow})` for each.

## choose-branch

1. `Q(modules, [path])`, keep rows whose Branch group = the group.
2. Chosen module stays; for every other module in the group: `U(module, {Status:"Skipped"})`, and `Q(lessons, [Module contains it])` → `U(lesson, {Status:"Skipped"})` each.
3. Append `"<group> → Module N"` to Paths.Branch choices.
4. Continue **advance** from step 3.

## review-due — lessons due for spaced repetition

`Q(lessons, [path, {"type":"property","property":"Due for review","propertyType":"formula","operator":"any","resultFilter":{"type":"property","property":"Due for review","propertyType":"checkbox","operator":"checkbox_is","value":{"type":"exact","value":true}}}])`.

Sort the result yourself by computed next-review date (base = Last reviewed or Completed at; + [1,3,7,30][Review count] days), most overdue first. Show days overdue computed the same way.

## log-review

`U(lesson, {date:Last reviewed:start: now, date:Last reviewed:is_datetime: 1, Review count: count + 1})`, then `C(journal, [{Entry:"Reviewed Lesson M.N (review k/4)", Type:"review", …}])`. After the 4th review the formula stops scheduling the lesson.

## flashcards — save

`C(flashcards, cards)` with Front, Back, Path, Lesson, Step 0, `date:Due:start` = tomorrow (for a lesson just completed) or empty (for cards on a lesson not completed yet).

## flashcards — review session

1. `Q(flashcards, [path, Due now = true])` (formula filter, `checkbox_is true`). Optional extra filter on Lesson.
2. Show Front, wait for the learner's answer, then reveal Back and ask how it went (easy / ok / hard / missed).
3. Update each card: ladder = [1, 3, 7, 30, 90] days.
   - easy → Step + 2 (max 4) · ok → Step + 1 (max 4) · hard → Step unchanged · missed → Step 0
   - `U(card, {Step, date:Due:start: today + ladder[Step], "Last result"})`.

## save-quiz

`C(quizzes, [{properties:{Name:"Module N Quiz: <title>", Path, Module, Kind, Score, Total, date:Taken:start: now, date:Taken:is_datetime:1}, content: <quiz markdown>}])`, then a Journal entry of Type quiz: `"Module N quiz: s/t (p%) — PASSED|FAILED"`.

## save-teachback

1. `U(lesson, {"Teach-back": rating})`.
2. Append to the lesson page body with `notion-update-page` `insert_content` at end: `## Teach-back (YYYY-MM-DD)` + the learner's explanation + your evaluation.
3. Journal entry of Type teach-back.

Lessons missing a teach-back: `Q(lessons, [path, Status = Completed, Teach-back is_empty])`.

## save-notes

`notion-update-page` `insert_content` (end) on the lesson page: `## Notes (YYYY-MM-DD)` + notes.

## add-resource

Fetch the lesson, then `U(lesson, {Resources: existing + " · [Title](url)"})`. List resources: `Q(lessons, [path, Resources is_not_empty])`.

## set-style

`U(path, {"Learning style": text})`.

## add-module

Max Order among the path's modules + 1 = N. `C(modules, [{Name:"Module N: Title", Path, Order:N, Status:"Not started"}])`, then `C(lessons, …)` with Order N×100+M and Status Not started. Journal entry Type modification.

## add-lesson

In module N, take the max lesson Order in that module + 1 (e.g. 405) → Code "4.5". Create with Status Not started. If the new Order would collide (module already has 99 lessons), stop and tell the user. Journal entry Type modification.

## remove-lesson / remove-module

Guard: a lesson only if it is Not started; a module only if none of its lessons is Completed or Current. The connector cannot delete pages, so "remove" means: set Status to Skipped (on the module and all its lessons, for a module) and prefix the Name with `[removed] `. Skipped rows are excluded from every progress count. Tell the user they can delete the pages in Notion if they want them gone. Do not renumber; gaps in Code are fine. Journal entry Type modification.

## analyze — struggle patterns

`Q(journal, [path, Type = struggle], Date desc)`. Group by Lesson. Report lessons with 2+ struggles, recurring themes in the Entry text, quiz questions marked PARTIAL/INCORRECT (fetch quiz pages of this path), and lessons with Teach-back = needs-review. Suggest remedial lessons via **add-lesson**.

## skill-tree — visual map

Write a Mermaid `flowchart TD` into a toggle at the end of the path page (`insert_content`), one node per module, `:::done` / `:::current` / `:::todo` classes, branch groups as forked edges. Replace the previous skill-tree section if present (`update_content`). The Lessons **Board** view is the always-current alternative.
