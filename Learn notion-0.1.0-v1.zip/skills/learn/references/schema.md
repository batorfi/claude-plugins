# Learning hub schema

All state lives in six Notion databases under a hub page named **Learning**. Property names below are exact — use them verbatim.

## Finding the databases

1. Search Notion for the page titled `Learning` (icon 🎓). Fetch it.
2. Read the JSON code block under **Plugin config** (`"learn_notion_config": 1`). It holds the `collection://` URL of each data source.
3. Use those URLs as `data_source_id` / `data_source_url` for every call. Fetch a data source once per session if its schema is needed.

If no hub or config block exists, stop and run the `learn-setup` skill.

## Connector limits (important)

- **Formula and rollup values cannot be read.** Query and fetch results show them as `formulaResult://…` / `rollupResult://…` placeholders. They exist for the human UI. Compute anything you need to *show* from plain fields (Status, dates, numbers).
- **Formula and rollup values CAN be filtered on** in `rows` mode (`propertyType: "formula"`, operator `any`, plus a `resultFilter` typed as the formula's result: `checkbox`, `number`, `date`, `text`).
- `rows` mode returns max 100 rows and has no cursor. For paths with more than 100 lessons, split the query by Status or by Order range.
- Relation values are written as a JSON-string array of page IDs, e.g. `"[\"3ec5…\"]"`.
- Dates are written as split keys: `date:<Prop>:start`, `date:<Prop>:is_datetime` (0/1). Use local time with offset (Europe/Budapest, `+01:00`/`+02:00`) for datetimes.
- A multi-select value must already exist as an option. To add a tag, first `ALTER COLUMN "Tags" SET MULTI_SELECT(...)` listing **all existing options plus the new one** (fetch the data source to get them).
- `create-pages` accepts up to 100 pages per call; all share one parent data source.

## Paths

| Property | Type | Notes |
|---|---|---|
| Name | title | e.g. "Learning Rust Programming" |
| Status | select | Not started · In progress · Paused · Completed |
| Level | select | beginner · advanced · mastery |
| Daily time, Duration | text | "45 minutes", "6 months" |
| Tags | multi-select | add options first (see above) |
| Learning style | text | how the learner learns best |
| Started, Last active | date | date only |
| Current streak, Longest streak | number | maintained by Claude |
| Branch choices | text | "ui-track → Module 3; …" |
| Source | text | provenance |
| Modules, Lessons, Quizzes, Flashcards, Journal | relation | two-way, filled from the child side |
| Lessons done / total, Modules done / total, Progress %, Current lesson, Quizzes taken / passed, Avg quiz %, Flashcard count, Days since active | rollup/formula | UI only — not readable |

Page body: `## Overview`, `## Milestones` (to-do list), optional `## History`.

## Modules

| Property | Type | Notes |
|---|---|---|
| Name | title | `Module N: Title` |
| Path | relation | |
| Order | number | N |
| Status | select | Not started · In progress · Completed · Skipped |
| Branch group | text | modules sharing a group are alternatives |
| Started, Completed | date | |
| Lessons, Quizzes | relation | back-links |
| Lessons done / total, Progress %, Done n, Active n | rollup/formula | UI only |

## Lessons

| Property | Type | Notes |
|---|---|---|
| Name | title | lesson title without number |
| Path, Module | relation | always set both |
| Code | text | "2.3" |
| Order | number | module×100 + lesson (e.g. 203). Sort key within a path |
| Status | select | Not started · Current · Completed · Skipped. **Exactly one Current per active path** |
| Objective, Time, Exercises, Resources | text | Resources: markdown links separated by " · " |
| Completed at | date | datetime when finished |
| Last reviewed | date | last spaced-repetition review |
| Review count | number | 0–4; set 0 on creation |
| Teach-back | select | good · partial · needs-review |
| Next review | formula (date) | `Last reviewed` or `Completed at` + [1,3,7,30][Review count] days; empty after 4 reviews |
| Due for review | formula (checkbox) | Next review ≤ today — filter on this |
| Flashcards, Journal | relation | back-links |

Page body: lesson notes (Claude appends a `## Notes` section when asked to save notes).

## Quizzes

| Property | Type | Notes |
|---|---|---|
| Name | title | `Module N Quiz: Title` |
| Path, Module | relation | |
| Kind | select | module · milestone · retake |
| Score, Total | number | |
| Taken | date | datetime |
| Percent, Passed, Pass n | formula | UI only; pass mark 70% |

Page body: one `## Question n [CORRECT|PARTIAL|INCORRECT]` section per question with **Q**, **A**, **Expected**, optional **Note**, then `## Summary`.

## Flashcards

| Property | Type | Notes |
|---|---|---|
| Front | title | question |
| Back | text | answer |
| Path, Lesson | relation | |
| Step | number | index into ladder [1, 3, 7, 30, 90] days |
| Due | date | empty = not scheduled |
| Last result | select | easy · ok · hard · missed |
| Due now | formula (checkbox) | Due set and ≤ today — filter on this |

## Journal

| Property | Type | Notes |
|---|---|---|
| Entry | title | one-line description |
| Path, Lesson | relation | Lesson optional |
| Type | select | completion · struggle · quiz · review · teach-back · modification · note |
| Date | date | datetime |
