# pdf-to-notion

Convert local PDF files into well-formatted Notion pages with Claude. Text, tables and images are extracted **locally** by a
bundled Python engine (PyMuPDF); long PDFs become a parent page with chapter subpages; images are saved to disk first, then
uploaded and embedded in the pages; you choose the look (a quick preset or every option); each chapter gets
`← Previous | ↑ Contents | Next →` links; and for a database destination each PDF gets its properties (Type, Tags, and others).

Flow: **Inspect and location (Gate 1) → Formatting (Gate 2) → Extract → Build with first-PDF preview (Gate 3) → Navigation → Verify.**

## Skills

| Skill | Purpose |
|---|---|
| `pdf-to-notion` | Entry point: environment check, flow, gates, rules |
| `pdf-inspect` | Inventory, page tree and split plan, Notion location (always asked), database properties, Type and Tags table, duplicate check |
| `pdf-format-options` | Quick run (preset defaults) or Custom run (every option), `style.json`, saved profiles |
| `pdf-extract` | Local extraction of text, tables and images; OCR for scanned PDFs with consent |
| `pdf-notion-build` | Image upload, conversion to Notion markdown, preview, page creation, database properties |
| `pdf-notion-navigate` | Contents lists and previous / contents / next footers (idempotent; add, change or remove later) |
| `pdf-notion-verify` | Compares created pages with what was built; checks links and properties |

Use it with `/pdf-to-notion <folder or files>` or just ask for it. Flags: `--mode quick|custom`, `--profile NAME`,
`--parent <Notion URL>`, `--no-preview`.

## Formatting options

Quick run applies the **Readable** preset without questions; Custom run asks every option that applies to your PDFs.
Heading levels and numbering, collapsible sections (none / all / long / appendix only), contents (list on the parent or
native block), callouts for notes, warnings, tips and examples, colors, page icons, tables, image captions and
placement, code and quotes, lists, footnotes, the original PDF attached, source line, and the navigation links.
Full list with JSON keys: `skills/pdf-to-notion/references/style-options.md`.

## Database destination

When the destination is a database, each PDF becomes one entry. **Type** (single select) and **Tags** (multi-select) are set
per PDF from a table you approve: suggestions come from the PDF's own text and prefer options the database already has;
new options are created only if you approve them. Other writable properties get one shared value per batch, and a source
file name, page count, import date and original PDF can be filled automatically.

## Requirements

Python 3.10+ and `pip install -r skills/pdf-to-notion/engine/requirements.txt` (PyMuPDF, Pillow). Optional: tesseract (with
Hungarian data for Hungarian text) for scanned PDFs. A Notion connection with access to the destination. The engine runs on
your computer through the Claude desktop app; nothing is uploaded to a cloud workspace except what goes to Notion.
`python3 skills/pdf-to-notion/engine/selftest.py` builds sample PDFs and runs the whole local pipeline (needs reportlab).

## Limits worth knowing

- Notion markdown has no image width, no stored toggle open/closed state, covers are image URLs only, three heading levels and
  a fixed color palette. The plugin does not promise these.
- Layout fidelity is approximate: it reads text, tables and images, not page design. Math, forms and heavily designed pages
  need a look. Scanned PDFs need OCR and are lower fidelity. Images over 20 MiB are recompressed; an original PDF over
  20 MiB is not attached.
- Not in v1: summaries at the top of each page, chaining navigation across PDFs, per-PDF styles or shared property values.
- The Notion side (page creation, upload URLs, property formats) was developed against the connector's documentation and tested
  with simulated responses; run the first-PDF preview and the verify step before trusting a large batch.

Licences: PyMuPDF is AGPL / commercial; check that it suits how you distribute this plugin.
