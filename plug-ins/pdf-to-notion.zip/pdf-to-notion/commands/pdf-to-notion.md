---
description: Convert local PDF files into well-formatted Notion pages (split long PDFs into subpages, embed images, navigation links, database properties)
argument-hint: <folder or PDF files> [--mode quick|custom] [--profile NAME] [--parent <Notion URL>] [--no-preview]
---

Use the `pdf-to-notion` skill to convert these PDFs into Notion pages: $ARGUMENTS

Follow the skill's flow and gates. The Notion location is always asked (a `--parent` URL is shown back at Gate 1).
If no folder or files are given, ask for them. If a project for these PDFs already exists, offer to resume it.
