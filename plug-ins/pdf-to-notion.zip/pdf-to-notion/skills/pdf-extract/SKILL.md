---
name: pdf-extract
description: "This skill should be used after the style is approved, to read the PDFs locally — \"extract the PDFs\", \"pull out the text, tables and images\", \"OCR the scanned PDF\", \"PDF kinyerés\", or when the pdf-to-notion orchestrator routes here. It runs the local engine to save text blocks, tables and images to disk (images first, before anything goes to Notion), applies OCR only with consent, and reports what was found."
metadata:
  version: "0.1.0"
---

# PDF Extract

Read every PDF in the approved plan **locally** and save the result to disk. Nothing leaves the computer in this phase.

Read first: `../pdf-to-notion/references/engine-cli.md`. `ENGINE` is `../pdf-to-notion/engine/pdfnotion.py`.

## Procedure

1. **Check the gates.** `ENGINE status` must show `gate1` and `style` done. If not, go back to `pdf-inspect` or
   `pdf-format-options`; never extract against an unapproved plan.
2. **Scanned PDFs.** If inspection flagged any as scanned, say so and ask before running OCR: it needs tesseract (and the
   Hungarian language data for Hungarian text) and gives lower fidelity. Use `--ocr-lang hun+eng` (or the languages the
   user names). OCR is applied only to pages without a text layer. If tesseract is missing, offer to continue without those PDFs.
3. **Extract.** `ENGINE extract [--ocr-lang ...]`. For each PDF it saves, under `<work>/<project>/extract/<slug>/`:
   - `pages.json`: the page-by-page block model (headings, paragraphs, lists, tables, code, quotes, footnotes, images),
   - `images/`: every kept image as PNG or JPEG, plus charts drawn as vector graphics rendered at 200 dpi,
   - `images.json` and `summary.json`: counts and warnings.
   Running headers, footers and page numbers are removed; images repeated on many pages (logos) and images under the size
   filter are dropped; hyphenated words are joined; two-column pages are read column by column.
4. **Report** in plain language per PDF: words, headings, tables, images kept, lists, code blocks, callouts found,
   footnotes, and any `warnings`. Say what the converter cannot do (page layout, fonts, math, forms) when a PDF looks
   design-heavy.
5. **Spot check.** Read the first lines of one `pages.json` or one saved image if the counts look wrong (for example zero
   headings in a long document, or a table reported as text) and tell the user instead of continuing silently.

## Notes

- Extraction is independent of the style: changing the look later does not need this step again.
- Re-running it replaces the images folder of each PDF, so run it only when the plan or the PDFs changed.
- The original PDFs are never modified.
