---
name: pdf-format-options
description: "This skill should be used after the plan is approved and before extraction, or when the look of imported pages must change — \"formatting options for the PDF import\", \"quick run or custom\", \"how should headings, toggles, callouts and colors look\", \"use my saved profile\", \"formázási beállítások\", or when the pdf-to-notion orchestrator routes here. It offers Quick run (preset defaults, no questions) or Custom run (every option), writes style.json, supports saved profiles and drives Gate 2."
metadata:
  version: "0.1.0"
---

# PDF Format Options

Decide how the pages will look, **once for the whole batch**, and write it to `style.json`. The converter reads only that
file, so the look can be changed later without reading the PDFs again.

Read first: `../pdf-to-notion/references/style-options.md` (every option, its choices and its JSON). Then
`../pdf-to-notion/references/notion-output.md` if the user asks what Notion can do.
`ENGINE` is `../pdf-to-notion/engine/pdfnotion.py`.

## Procedure

1. **Mode.** Ask with AskUserQuestion unless the request said `--mode` or `--profile`:
   - **Quick run (Recommended)**: the Readable preset, no questions; a summary is shown for confirmation.
   - **Custom run**: every formatting option is asked.
   - **Saved profile** is not a third menu entry: it is used when the user names one (`--profile NAME`), and counts as a Quick run.
   Language: questions, presets and labels follow the language the user writes in (`--lang hu` for Hungarian; for another
   language, translate the labels, see the reference).
2. **Quick run.** `ENGINE style build --preset readable [--lang X]`, then show `ENGINE style describe` as a short plain-language
   list (heading levels, collapsible sections, contents, callouts, colors, tables, images, navigation, ...), leaving out
   options that do not apply to these PDFs. The user can confirm, say "change the colors" (then ask only about those
   groups, see Custom run), or switch to Custom run. If they named a profile: `ENGINE style profile-load NAME` instead.
3. **Custom run.**
   1. `ENGINE style applicable` returns the groups to `ask` and the groups `skipped` (no images, no tables, no PDF split,
      ...). Skipped groups are listed once as "skipped, not applicable"; if the user wants to be asked anyway, ask them.
   2. First question: starting preset (Faithful / **Readable** / Compact). It pre-fills the answers below, but every option
      is still asked, so nothing is applied silently.
   3. Ask the remaining groups in the order of the reference, **up to four questions per AskUserQuestion call**, recommended
      option first with "(Recommended)", and a one-line preview of the result in each option's description.
   4. Collect the answers as one nested JSON and run `ENGINE style build --preset <chosen> --answers '<json>' [--lang X]`.
4. **Gate 2.** Show `ENGINE style describe`: the exact values that will be applied. **Hard stop.** On a clear yes,
   `ENGINE style approve`. A change request goes back to step 2 or 3 for just those groups (`ENGINE style set <key> <json>`
   for a single value), then the summary is shown again.
5. **Offer to save** a Custom run as a named profile (`ENGINE style profile-save NAME`). A profile holds the look only,
   never a Notion location or property values.

## Honest limits to mention when relevant

Notion markdown cannot set image width, store whether a toggle is open or closed, use solid-color covers (URL only), or
go beyond three heading levels and the built-in color palette. These are listed in the reference; do not promise them.

## Applying a new look to pages that already exist

Re-run `ENGINE convert` after changing `style.json`, then update the existing pages through `pdf-notion-build` (chapter
pages can be replaced after the user agrees; top pages with subpages only get targeted edits). Navigation footers are
re-applied by `pdf-notion-navigate`.
