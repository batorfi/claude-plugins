---
name: pdf-inspect
description: "This skill should be used when a PDF-to-Notion project starts or its plan must change — \"inspect these PDFs\", \"which PDFs and where in Notion\", \"how will the PDFs be split\", \"choose the Notion location\", \"PDF vizsgálat\", or when the pdf-to-notion orchestrator routes here. It inventories the PDFs, proposes the page tree and split plan, always asks for the Notion location, maps database properties (Type, Tags and others), shows a per-PDF Type and Tags table, checks for duplicates and drives Gate 1."
metadata:
  version: "0.1.0"
---

# PDF Inspect

Find out what is in the PDFs, propose the page tree, and settle **where in Notion** the pages go and which properties they
get. Nothing is written to Notion in this phase. It ends at **Gate 1**.

Read first: `../pdf-to-notion/references/engine-cli.md`, `../pdf-to-notion/references/notion-output.md`.
`ENGINE` is `../pdf-to-notion/engine/pdfnotion.py` (see the orchestrator).

## Procedure

1. **Inputs.** Get the folder or the PDF files (ask if not given; the user can name them in the request, attach them or add
   the folder in the desktop app). Subfolders are only included when the user asks (`--recursive`). Password-protected
   PDFs are reported and skipped: never ask for the password.
2. **Inspect.** `ENGINE inspect <paths>` (add `--split-pages`, `--split-words`, `--range-pages`, `--min-image-px` only if the
   user wants other thresholds). Show the returned `tree` in plain language: each PDF, its pages, words, images, tables,
   and the proposed chapters with page ranges. Report `warnings` (scanned PDF needs OCR; outline titles not found in the
   text; and so on).
3. **Notion location (always asked, in both modes).** Load the Notion tools with ToolSearch (`notion-list-recent-pages`,
   `notion-list-favorite-pages`, `notion-fetch`, `notion-search`). Ask one question with AskUserQuestion:
   - **A recent or favorite page** (offer up to three real candidates from the lists),
   - **Paste a Notion page or database URL** (the "Other" field takes it),
   - **A private draft** (a private workspace page the user moves later; offered as an explicit choice, never preselected).
   If the request carried `--parent <url>`, skip the question but still show the destination back at Gate 1.
   Do not offer a search box; recent pages, favorites and a pasted URL are enough.
4. **Check the destination.** `ENGINE dest parse <url>` gives the id; `notion-fetch` it. If it cannot be read or written,
   say so and ask again (never discover this halfway through the batch). Remember whether it is a page, a database
   (note its `collection://` data source URL and title property) or a draft.
5. **Database destination only:**
   1. Read the schema from the fetched database and write a small JSON file
      `{"title_property": "...", "properties": [{"name", "type", "options": [...]}]}`; run `ENGINE dest map @schema.json`.
   2. **Type** (single select) and **Tags** (multi-select) are the two properties with per-PDF values. Match is by name
      (Type, Típus; Tags, Címkék, ...) and kind. If a property is missing or has another kind, follow the `notes`:
      ask which property to use, skip it, or **offer to add it** (select named Type, multi-select named Tags) with
      `notion-update-data-source`. Adding a property changes the database schema: only after an explicit yes.
   3. Read existing options and a sample (up to 100 entries) of existing Type and Tags values from the database
      (`notion-query-data-sources`), then `ENGINE classify --existing '{"types":[...],"tags":[...]}'`. Suggestions come
      from the PDF's own title, headings and text and prefer options the database already has.
   4. Show **one table**: each PDF with its proposed Type and Tags (existing options marked, new ones marked "new"). The
      user edits any row or says "tag everything with X". Save the approved values with
      `ENGINE record '{"<slug>": {"type": "...", "tags": [...]}}'`. New select options are created only if listed here
      and approved.
   5. **Other properties** (`dest map` lists `autofill` and `shared_candidates`): propose the auto-fill (source file name,
      page count, import date, original PDF if a Files property exists), then for each remaining writable property ask for
      **one value applied to every page** (real options for select and status; a person by name; a relation by URL) or
      leave it empty. Read-only properties (formula, rollup, created time, ...) are listed as "skipped, not writable".
      Per-PDF differences beyond Type and Tags are not supported in v1: edit them in Notion afterwards.
6. **Duplicate check.** Search the destination (children of the page, or entries of the database) for the planned titles
   (`notion-search` with `page_url` or `data_source_url`). If a title already exists, warn and offer: continue and create
   anyway, rename, or stop. The manifest also prevents re-runs from creating a second copy.
7. **Plan edits.** The user may adjust the split: `ENGINE plan split-off <slug>`, `plan ranges <slug> N`,
   `plan rename <slug> IDX "Title"`, `plan merge <slug> A B`. To split a PDF that was kept whole, re-run `inspect` with a
   lower `--split-pages`. Re-show the tree after every edit.
8. **Save the destination** in the manifest:
   `ENGINE dest set '{"kind": "page|database|draft", "id": "...", "url": "...", "title": "...", "data_source_id": "...",
   "schema": {...}, "mapping": {...}, "shared": {...}}'` (the last three only for a database).
9. **Gate 1.** Show in plain language: the page tree (`ENGINE tree`) with the destination at the top, the reading order
   that navigation will follow, the property table (Type, Tags and the rest) and any options or properties that would be
   created. **Hard stop.** On a clear yes: `ENGINE manifest mark gate1`.

## Notes

- Splitting happens when a PDF is over 30 pages or 15,000 words (defaults in `defaults.json`). Split points: the PDF's
  outline, else detected top-level headings, else ranges of 15 pages.
- A PDF kept whole becomes a single page; a split PDF becomes a top page plus chapter subpages.
- Scanned PDFs can be planned but need OCR at the extract step; say that now so the user is not surprised.
