---
name: pdf-notion-build
description: "This skill should be used after extraction, to create the Notion pages — \"build the Notion pages\", \"upload the images and create the pages\", \"update the imported pages with the new style\", \"Notion oldalak létrehozása\", or when the pdf-to-notion orchestrator routes here. It uploads images (and the original PDF), converts to Notion markdown, builds the first PDF as a preview for review (Gate 3), then creates the rest, records every page id and fills database properties."
metadata:
  version: "0.1.0"
---

# PDF Notion Build

Pass 1 of the import: upload files, convert, create the pages. The navigation links and contents lists are pass 2
(`pdf-notion-navigate`) because they need the page ids that only exist after this step.

Read first: `../pdf-to-notion/references/notion-output.md`, `../pdf-to-notion/references/engine-cli.md`.
`ENGINE` is `../pdf-to-notion/engine/pdfnotion.py`.

## Before starting

- `ENGINE status`: `gate1`, `style` and `extract` must be done; the destination must be in the manifest.
- Load the tools with ToolSearch in one call: `notion-create-file-upload`, `notion-create-pages`, `notion-update-page`,
  `notion-fetch`, `notion-get-async-task`.
- Create a task list: uploads, convert, preview, remaining pages, check.

## Procedure

1. **Uploads (images and original PDFs).** `ENGINE uploads prepare` returns the `queue` of files still to upload (files
   over 20 MiB are shrunk; an original PDF over the limit is left out and reported). For each queue item:
   1. `notion-create-file-upload {filename}` returns an upload URL, headers and the file upload id.
   2. `ENGINE uploads send --url <upload_url> --headers '<upload_headers json>' --file <upload_file> --filename <filename>`
      posts the file (one multipart request). **Never print or repeat the headers.**
   3. `ENGINE uploads record --slug <slug> --id <id> --response '<json from send>' --file-upload-id <id>` keeps the returned
      markdown reference in the manifest.
   A failed upload is retried once, then reported by file name; pages are not created while an image is missing
   (`convert` refuses). When the queue is empty, `ENGINE uploads done`.
2. **Convert.** `ENGINE convert` writes `build/pages/*.md` (parts for pages over 60,000 characters) and `build/pages.json`
   (titles, icons, parents, files, expected counts). It stops with a list if an image has no upload yet.
3. **Preview (Gate 3), unless the request said `--no-preview`.** Build only the **first PDF** (steps 4 to 6 for that PDF),
   give the user the page title and tell them to look at it in Notion. Hard stop: wait for approval or for a request to change
   something (a style change goes through `pdf-format-options`, then `convert`, then replace the preview pages after the
   user agrees). Only then build the remaining PDFs.
4. **Create the top page of a PDF** with `notion-create-pages` (`allow_async: false` so the id comes back at once):
   - destination **page**: `parent: {"page_id": ...}`, `properties: {"title": <title>}`;
   - destination **database**: fetch the database first and use its data source id; `properties` come from
     `ENGINE dest props @spec.json` (spec: `{"mapping", "schema", "shared", "pdfs": [{slug, title, source_file, pages,
     type, tags}]}`); check the value format of each property type against the schema shown by the fetch (for example how a
     multi-select or a date is expected) before the first create, and create any approved new select options first;
   - destination **draft**: `creation_mode: "draft"` and no parent; tell the user it is private and offer to move it;
   - `content` is the first file of the page from `build/pages.json`; `icon` and `cover` come from there too (omit when null).
   Record it: `ENGINE manifest record-page <slug> - --page-id <id> --url <url>`.
5. **Create the chapter subpages** (split PDFs) the same way with `parent: {"page_id": <top page id>}`, in reading order, then
   `ENGINE manifest record-page <slug> <chapter_id> --page-id <id> --url <url>` for each. Pages with several files get the
   remaining parts appended in order with `notion-update-page` (`insert_content`, position end).
6. **Resume and re-runs.** A page that already has an id in the manifest is not created again. To bring an existing page up to
   date, fetch it and use targeted edits; **chapter pages** may use `replace_content` after the user agrees, **top pages that
   have child pages never do** (it would delete the subpages).
7. After the last page: `ENGINE manifest mark pages` (add a note if the preview was skipped). Report: pages created, links
   to the top pages, files skipped, anything created in the database schema.

## Rules

- Never create a page outside the confirmed destination, never delete or move existing pages, never create duplicates.
- Create pages one at a time or in small groups so a failure leaves a clean, recorded state; the manifest is the record.
- The `PDFNOTION-TOC` line on top pages is a placeholder: leave it, `pdf-notion-navigate` replaces it.
- Tell the user plainly if a call is rejected for size; the page is then split into more parts (`max_page_chars` in
  `defaults.json` is 60,000).
