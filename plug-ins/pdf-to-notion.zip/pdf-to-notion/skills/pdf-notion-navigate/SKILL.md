---
name: pdf-notion-navigate
description: "This skill should be used after the pages exist, to add or change previous / next navigation — \"add navigation links\", \"previous and next links at the bottom of each page\", \"update or remove the navigation footers\", \"fill the contents list\", \"navigációs linkek\", or when the pdf-to-notion orchestrator routes here. It is pass 2 of the import: it replaces the contents placeholder on each top page and writes the ← Previous | ↑ Contents | Next → footer on each chapter page, idempotently."
metadata:
  version: "0.1.0"
---

# PDF Notion Navigate

Give the reader a way to move back and forth between the chapter pages of a split PDF. It works on pages that already exist
(their ids are in the manifest), so it can be run right after the build, later with a different layout, or to remove the links.

Read first: `../pdf-to-notion/references/notion-output.md`. `ENGINE` is `../pdf-to-notion/engine/pdfnotion.py`.
Load `notion-fetch` and `notion-update-page` with ToolSearch.

## What is written

```
---
← Previous: <page mention> | ↑ Contents: <page mention of the PDF's top page> | Next: <page mention> →
```

- The links are native page mentions (they follow renames); the first chapter has no previous link, the last has no next link.
- Options come from `style.json` (`chrome.navigation`): placement bottom or top and bottom, contents link yes/no, link labels
  (both, title only, generic), divider yes/no. A PDF that is not split gets only a "Contents" link back to the destination
  page when `single_page_footer` is `contents` and the destination is a page.
- On the top page of a split PDF the `PDFNOTION-TOC` placeholder becomes a numbered list of the chapters with their page ranges
  (when `structure.toc` is `parent_list`).

## Procedure

1. **Check.** `ENGINE status`: `pages` must be done. `ENGINE nav build` returns `pages` (footer markdown per page) and `missing`
   (pages without an id). If anything is missing, stop and go back to `pdf-notion-build`.
2. **Contents lists.** `ENGINE toc build` returns one list per split PDF. On each top page, `notion-update-page` with
   `update_content`: replace the exact text `PDFNOTION-TOC` with the list. If the placeholder is gone (a re-run), fetch the page,
   save its markdown to a file and run `ENGINE toc find --file <file>`; replace the returned `existing` text with the new list.
3. **Footers, per page** (`notion-fetch` the page, save the markdown to a file, `ENGINE nav find --file <file>`):
   - an existing **bottom** footer was found: `update_content` with `old_str` = the returned text and `new_str` = the new
     footer (replace, never stack a second one);
   - none found: `insert_content` at the **end** with the page's `bottom` markdown (and at the **start** with `top` when
     placement is `top_and_bottom`);
   - removing navigation: `update_content` with the found text as `old_str` and an empty `new_str` (the user asked for it,
     so this is allowed; remove nothing else).
   Use the fetched text exactly as `old_str`; if the page was edited by hand and nothing matches, say so and show the user the
   proposed footer instead of guessing.
4. **Finish.** `ENGINE nav done`. Report how many footers were written, replaced or removed and give one example page to open.

## Notes

- Links use the page ids recorded in the manifest, so moving a page in Notion does not break them. If the user reorders
  subpages by hand, rebuild the footers by re-running this skill after updating the plan order.
- Generic labels ("Previous", "Next") are text links to the page; Notion may convert a link to a Notion page into a mention
  that shows the page title. Say so if the user chooses that layout.
- Chaining the last chapter of one PDF to the first of the next one is not part of v1.
