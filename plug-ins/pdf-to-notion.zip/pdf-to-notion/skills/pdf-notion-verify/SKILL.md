---
name: pdf-notion-verify
description: "This skill should be used after pages are created and linked, to check the import — \"verify the Notion import\", \"check the converted pages\", \"did all the images and tables make it\", \"are the navigation links right\", \"import ellenőrzése\", or when the pdf-to-notion orchestrator routes here. It fetches each created page, compares headings, tables, images and word counts with what was built, checks navigation links and database properties, and writes a short report."
metadata:
  version: "0.1.0"
---

# PDF Notion Verify

Compare what is now in Notion with what was built, and report problems plainly.

Read first: `../pdf-to-notion/references/engine-cli.md`. `ENGINE` is `../pdf-to-notion/engine/pdfnotion.py`.
Load `notion-fetch` with ToolSearch. This is the last task of the task list; a different reader than the one that built the
pages is preferred for high-stakes batches (a fresh subagent that only gets the manifest and the report path).

## Procedure

1. **Fetch.** For every page in `ENGINE manifest show` (top pages and chapter subpages) call `notion-fetch` and save the page
   markdown to `<work>/<project>/build/fetched/<page id, 32 hex, no dashes>.md` with the Write tool. If a result says it was
   truncated or has unknown blocks, note it; those pages cannot be fully checked.
2. **Properties (database destination).** Collect the fetched `type` and `tags` of each top page into a JSON file
   `{"<page id>": {"type": "...", "tags": [...]}}`.
3. **Run.** `ENGINE verify --fetched <work>/<project>/build/fetched [--props @props.json]`. It checks per page:
   headings, tables and images match the converter's expected counts; words within a tolerance; no `pending:` image placeholders;
   each chapter's footer links to its previous, next and contents pages and to nothing else; Type and Tags match what was approved.
4. **Report** in plain language: pages checked, pages with problems, and for each problem what is wrong and the fix:
   - counts differ: the page may have been edited by hand, or a block was rejected; offer to rebuild that page;
   - footer wrong or missing: re-run `pdf-notion-navigate`;
   - image placeholder left: re-run `pdf-notion-build` uploads for that PDF;
   - property mismatch: correct it with `notion-update-page` (`update_properties`) after the user agrees.
   The full report is saved as `build/verify.md`; mention the path.
5. **What cannot be checked.** The engine compares structure, not appearance. Ask the user to open one page of each PDF and
   look at it; say plainly that layout fidelity, scanned text without OCR, math and heavily designed pages are only
   approximated.
6. `ENGINE verify` marks the step; state the final result in one or two sentences with links to the top pages.
