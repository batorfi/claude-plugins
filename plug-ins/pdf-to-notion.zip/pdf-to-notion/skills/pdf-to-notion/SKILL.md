---
name: pdf-to-notion
description: "This skill should be used when the user wants local PDF files turned into well-formatted Notion pages — \"convert these PDFs to Notion\", \"import PDFs into Notion\", \"put this PDF in Notion as pages\", \"split this long PDF into subpages\", \"PDF-ek átemelése Notionbe\", \"PDF Notion oldalakká\", or \"continue my PDF import\". It is the entry point: it checks the local environment, enforces the approval gates (inspect and destination, formatting, preview) and routes to pdf-inspect, pdf-format-options, pdf-extract, pdf-notion-build, pdf-notion-navigate and pdf-notion-verify."
metadata:
  version: "0.1.0"
---

# PDF to Notion (Orchestrator)

Turn local PDF files into well-formatted Notion pages: text, tables and images are extracted **locally** by a bundled
Python engine, long PDFs are split into subpages, the look is chosen by the user (a quick preset or every option),
previous / contents / next links are added, and for a database destination each PDF gets its properties (Type, Tags,
and others). Claude directs the engine, talks to Notion through the Notion connector, and keeps the user in control.

Read first: `references/engine-cli.md`. Then as needed: `references/style-options.md`, `references/notion-output.md`.

## The engine

`ENGINE` is `engine/pdfnotion.py` in this skill's folder:
`python3 <skill folder>/engine/pdfnotion.py [--work DIR] [--project NAME] <command>`. JSON goes to stdout, logs to stderr.
Python 3.10 or newer. **Run it with the shell on the user's computer** (the PDFs are local files and nothing is
uploaded to a cloud workspace). If the session has no shell on the user's computer, say so and ask them to link the
chat in the Claude desktop app and add the PDF folder; do not copy PDFs elsewhere.

## Step 0: Environment

1. Run `ENGINE doctor`. Report in plain language what is present: PyMuPDF (required), Pillow (needed to shrink images
   over 20 MiB), tesseract (only for scanned PDFs).
2. Fix what blocks the job, **after asking**: `pip install -r engine/requirements.txt` (prefer a virtual environment).
   Missing optional tools only limit scanned-PDF support or very large images; say which.
3. Choose the work folder once: `$PDF_TO_NOTION_WORK`, else `pdf-to-notion-work` next to the PDFs. A project is
   `<work>/<project>/` (see `references/engine-cli.md`). Use a short project name from the folder or the user's words.
4. If `ENGINE status` shows an existing project, offer to **resume** at the next missing step instead of starting over.

## Flow

1. `pdf-inspect`: inventory and page tree, **Notion location (always asked)**, database properties with a per-PDF
   Type / Tags table, duplicate check. **Gate 1: the user approves the page tree, destination and property values.**
2. `pdf-format-options`: **Quick run** (preset defaults, no questions) or **Custom run** (every option), asked once
   for the whole batch. **Gate 2: the user approves `style.json`.**
3. `pdf-extract`: text, tables and images to disk (OCR only if the user agrees).
4. `pdf-notion-build`: upload images, convert, create the pages. The **first PDF is built alone as a preview**
   (skipped with `--no-preview`); **Gate 3: the user reviews it** before the rest are built.
5. `pdf-notion-navigate`: contents lists and the `← Previous | ↑ Contents | Next →` footers (pass 2).
6. `pdf-notion-verify`: compare the created pages with what was built and report.

| User intent | Route |
|---|---|
| New import | flow above |
| Continue or status | `ENGINE status`; resume at `next` |
| Change the look of imported PDFs | `pdf-format-options`, then `pdf-notion-build` (updates existing pages) |
| Add, change or remove navigation links | `pdf-notion-navigate` |
| Check what was imported | `pdf-notion-verify` |
| Different split of one PDF | `pdf-inspect` (plan edit), then rebuild that PDF |

Flags in the user's request: `--mode quick|custom` skips the mode question, `--profile NAME` applies a saved style
profile (counts as a Quick run), `--parent <Notion URL>` pre-fills the destination (still shown back at Gate 1),
`--no-preview` skips the first-PDF preview.

## Rules

- **Hard stop at each gate.** Edits and corrections are not approval; wait for a clear yes. Record gates with
  `ENGINE manifest mark gate1` (and the engine marks the others).
- **The location is always asked.** Never choose a Notion destination for the user, never write outside the confirmed
  parent. A private draft is offered as an explicit choice, never as the default.
- **Notion only through the connector.** The engine never talks to Notion. Never ask for, print or store a token.
  Upload headers returned by `notion-create-file-upload` go straight into `uploads send` and are never shown.
- **Never duplicate, never destroy.** Before creating a page, check the manifest (a page id means it exists) and the
  destination for the same title. Do not delete pages or databases. Never `replace_content` on a top page that has
  child pages; use targeted edits. Properties that do not exist are added only with the user's explicit approval.
- **Never invent content.** The pages contain what the PDF contains. Suggested Type and Tags are heuristics, always
  shown for approval.
- **Language follows the user's input** (questions, presets, labels). Page content stays in the PDF's own language.
- Report plainly what could not be checked or reproduced: scanned pages without OCR, layout fidelity, images skipped,
  the original PDF left out when over 20 MiB.
- Plain language with the user; give file names and Notion page titles, not ids or JSON.

## Gates

| Gate | Advances when | Recorded |
|---|---|---|
| 1 Plan | User approves page tree, destination and property values | `manifest.steps.gate1` |
| 2 Style | User approves the formatting summary or answers | `manifest.steps.style` |
| 3 Preview | User reviews the first PDF (or skipped it) | note on `pages` step |
| Done | Verification passes or its problems are accepted | `manifest.steps.verify` |

Not in v1: summaries at the top of each page, chaining the last page of one PDF to the first of the next, per-PDF
differences in style or shared property values (re-run the format step for one PDF instead).
