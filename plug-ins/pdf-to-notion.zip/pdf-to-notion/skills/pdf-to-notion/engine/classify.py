"""Suggested Type (single select) and Tags (multi-select) for each PDF.

Heuristics only: they read the PDF's own title, headings and text, and where the destination database
already has options they prefer those, so existing tag style stays consistent. Always shown to the
user for approval; nothing is written without it.
"""
from __future__ import annotations

import re
from collections import Counter

TYPE_RULES = {
    "Manual": ["manual", "user guide", "installation", "troubleshooting", "getting started", "kézikönyv",
               "felhasználói", "telepítés", "hibaelhárítás", "step 1", "setup"],
    "Report": ["executive summary", "findings", "conclusions", "quarterly", "annual report", "results", "jelentés",
               "összefoglaló", "következtetések", "eredmények", "recommendations"],
    "Paper": ["abstract", "references", "doi", "keywords", "methodology", "related work", "absztrakt",
              "irodalomjegyzék", "módszertan", "hypothesis"],
    "Slides": [],
    "Contract": ["agreement", "parties", "hereby", "termination", "governing law", "szerződés", "felek",
                 "jelen szerződés", "liability", "confidentiality"],
    "Datasheet": ["datasheet", "specifications", "technical data", "features", "adatlap", "műszaki adatok",
                  "ordering information", "absolute maximum"],
    "Proposal": ["proposal", "scope of work", "pricing", "deliverables", "ajánlat", "árazás", "timeline"],
    "Specification": ["requirements", "shall", "must", "specification", "specifikáció", "követelmények",
                      "normative"],
    "Reference": ["reference", "api", "glossary", "appendix", "index", "referencia", "szószedet", "függelék"],
}
TYPE_WEIGHT = {"Reference": 0.5, "Specification": 0.7}  # weak, very common words
SYNONYMS = {"manual": {"guide", "handbook", "kézikönyv", "manuals"}, "report": {"reports", "jelentés"},
            "paper": {"papers", "article", "research", "tanulmány"}, "slides": {"presentation", "deck", "prezentáció"},
            "contract": {"agreement", "szerződés"}, "datasheet": {"data sheet", "adatlap"},
            "proposal": {"offer", "ajánlat"}, "specification": {"spec", "specifikáció"},
            "reference": {"docs", "documentation", "dokumentáció"}}
STOP = set("""a an the and or of to in on at for with by from as is are was were be been it this that these those
not no yes can will may should must have has had do does did if then than so such also into over under about
between within without per via its their our your you we they he she i his her them us
és az egy hogy nem is de vagy mint ez ezek amely amelyek van volt lesz kell lehet meg még már csak során alapján
szerint illetve valamint által ellen között után előtt miatt
page pages figure table chapter section fig appendix contents introduction overview summary note example
oldal ábra táblázat fejezet bevezetés áttekintés összefoglalás megjegyzés példa""".split())


def _words(text: str) -> list[str]:
    return [w for w in re.findall(r"[^\W\d_]{3,}", text.lower(), flags=re.UNICODE) if w not in STOP]


def _count(text: str, kw: str) -> int:
    return len(re.findall(r"(?<!\w)" + re.escape(kw) + r"(?!\w)", text))


def suggest_type(title: str, headings: list[str], text: str, landscape: bool, avg_words: int,
                 existing: list[str]) -> dict:
    body = text.lower()
    title_l = title.lower()
    heads_l = " ".join(headings[:40]).lower()
    scores: Counter = Counter()
    for name, kws in TYPE_RULES.items():
        total = 0.0
        for kw in kws:
            total += 8 * min(_count(title_l, kw), 1) + 2 * min(_count(heads_l, kw), 3) + min(_count(body, kw), 4)
        scores[name] = total * TYPE_WEIGHT.get(name, 1.0)
    if landscape and avg_words < 90:
        scores["Slides"] += 6
    best, score = (scores.most_common(1)[0] if scores else ("Document", 0))
    if score < 3:
        best, confidence = "Document", "low"
    else:
        confidence = "high" if score >= 8 else "medium"
    match = _match_existing(best, existing)
    return {"value": match or best, "existing": bool(match), "confidence": confidence, "score": score}


def _match_existing(value: str, options: list[str]) -> str | None:
    v = value.lower()
    for o in options:
        if o.lower() == v:
            return o
    syn = SYNONYMS.get(v, set())
    for o in options:
        ol = o.lower()
        if v in ol or ol in v or ol in syn or any(s in ol for s in syn):
            return o
    return None


def _casing(options: list[str]):
    if not options:
        return lambda t: t[:1].upper() + t[1:]
    caps = sum(1 for o in options if o[:1].isupper())
    if caps > len(options) / 2:
        return lambda t: t[:1].upper() + t[1:]
    return lambda t: t.lower()


def suggest_tags(title: str, headings: list[str], text: str, existing: list[str], limit: int = 5) -> list[dict]:
    lower = text.lower()
    picked: list[dict] = []
    # 1) existing options that appear in the document
    scored = []
    for opt in existing:
        n = _count(lower, opt.lower()) + 3 * _count((title + " " + " ".join(headings)).lower(), opt.lower())
        if n:
            scored.append((n, opt))
    for n, opt in sorted(scored, reverse=True)[:limit]:
        picked.append({"value": opt, "existing": True})
    # 2) new terms from title, headings and frequent words
    if len(picked) < limit:
        weight: Counter = Counter()
        for w in _words(title):
            weight[w] += 6
        for h in headings:
            for w in _words(h):
                weight[w] += 3
        for w, c in Counter(_words(text)).items():
            if c >= 4:
                weight[w] += c
        bigrams: Counter = Counter()
        for h in [title] + headings:
            ws = _words(h)
            for a, b in zip(ws, ws[1:]):
                bigrams[f"{a} {b}"] += 4
        taken = {p["value"].lower() for p in picked}
        fmt = _casing(existing)
        for term, _ in (bigrams.most_common(3) + weight.most_common(30)):
            if len(picked) >= limit:
                break
            if term in taken or any(term in t or t in term for t in taken):
                continue
            picked.append({"value": fmt(term), "existing": False})
            taken.add(term)
    return picked[:limit]


def classify_pdf(info: dict, sample: dict, existing_types: list[str], existing_tags: list[str]) -> dict:
    text = sample.get("category_text") or sample.get("text", "")
    return {
        "slug": info["slug"], "title": info["title"],
        "type": suggest_type(info["title"], sample.get("headings", []), text, info.get("landscape", False),
                             info.get("avg_words_per_page", 200), existing_types),
        "tags": suggest_tags(info["title"], sample.get("headings", []), text, existing_tags),
    }
