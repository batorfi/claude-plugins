"""Shared helpers for the pdf-to-notion engine (no third-party imports)."""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

NOTION_ESCAPE = "\\*~`$[]<>{}|^"


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def sha1_bytes(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()


def sha1_file(path: str | Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def slugify(text: str, max_len: int = 48) -> str:
    norm = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    norm = re.sub(r"[^A-Za-z0-9]+", "-", norm).strip("-").lower()
    return (norm[:max_len].strip("-")) or "item"


def esc(text: str) -> str:
    """Escape Notion-flavoured markdown special characters in plain text."""
    return "".join("\\" + c if c in NOTION_ESCAPE else c for c in text)


def read_json(path: str | Path, default=None):
    p = Path(path)
    if not p.exists():
        return default
    with open(p, "r", encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path: str | Path, data) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    os.replace(tmp, p)


def write_text(path: str | Path, text: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(text)


def emit(obj) -> None:
    """JSON to stdout (the engine contract: JSON on stdout, logs on stderr)."""
    json.dump(obj, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


def log(msg: str) -> None:
    print(msg, file=sys.stderr)


class Project:
    """Paths of one project folder: <work>/<project>/..."""

    def __init__(self, work: str | Path, name: str):
        self.work = Path(work).expanduser().resolve()
        self.name = name
        self.root = self.work / name
        self.manifest = self.root / "manifest.json"
        self.inventory = self.root / "inventory.json"
        self.plan = self.root / "plan.json"
        self.style = self.root / "style.json"
        self.extract = self.root / "extract"
        self.build = self.root / "build"
        self.profiles = self.work / "profiles"

    def ensure(self) -> "Project":
        self.root.mkdir(parents=True, exist_ok=True)
        return self


def deep_merge(base: dict, over: dict) -> dict:
    out = json.loads(json.dumps(base))
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def word_count(text: str) -> int:
    return len(re.findall(r"\w+", text, flags=re.UNICODE))


def normalize_id(value: str) -> str | None:
    """Return a 32-hex Notion id (no dashes) from a URL, dashed uuid or raw id."""
    if not value:
        return None
    path = re.split(r"[?#]", value.strip(), maxsplit=1)[0]
    runs = re.findall(r"[0-9a-fA-F]{32,}", path.replace("-", ""))
    return runs[-1][-32:].lower() if runs else None


def dashed(id32: str) -> str:
    return f"{id32[0:8]}-{id32[8:12]}-{id32[12:16]}-{id32[16:20]}-{id32[20:32]}"
