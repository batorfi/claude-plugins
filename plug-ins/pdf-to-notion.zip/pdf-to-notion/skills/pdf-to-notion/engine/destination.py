"""Notion destination: id parsing, database schema mapping, and per-PDF property values.

The schema is read by Claude with the Notion connector and handed over as a small JSON file:

  {"title_property": "Name",
   "properties": [{"name": "Type", "type": "select", "options": ["Manual", "Report"]},
                  {"name": "Tags", "type": "multi_select", "options": ["rust", "ai"]}, ...]}
"""
from __future__ import annotations

import re
from datetime import date

from common import dashed, normalize_id

READ_ONLY = {"formula", "rollup", "created_time", "created_by", "last_edited_time", "last_edited_by",
             "unique_id", "button", "verification"}
TYPE_NAMES = {"type", "típus", "tipus", "kind", "document type", "doc type", "dokumentum típusa", "dokumentumtípus"}
TAG_NAMES = {"tags", "tag", "címkék", "cimkek", "címke", "cimke", "labels", "topics", "témák"}
AUTOFILL_HINTS = {
    "source": ({"source", "source file", "filename", "file name", "fájl", "fájlnév", "forrás"},
               {"rich_text", "url", "title"}),
    "pages": ({"pages", "page count", "oldalak", "oldalszám", "oldalszam"}, {"number"}),
    "imported": ({"imported", "import date", "imported on", "date", "dátum", "importálva"}, {"date"}),
    "original_pdf": ({"pdf", "original", "original pdf", "file", "files", "attachment", "eredeti", "csatolmány"},
                     {"files"}),
}


def parse(value: str) -> dict:
    pid = normalize_id(value)
    if not pid:
        raise SystemExit("no Notion page or database id found in that value")
    return {"id": pid, "uuid": dashed(pid), "url": value if value.startswith("http") else f"https://www.notion.so/{pid}"}


def _norm(name: str) -> str:
    return re.sub(r"\s+", " ", name.strip().lower())


def map_schema(schema: dict) -> dict:
    props = schema.get("properties", [])
    by_name = {_norm(p["name"]): p for p in props}
    title = schema.get("title_property") or next((p["name"] for p in props if p["type"] == "title"), None)
    result: dict = {"title_property": title, "type": None, "tags": None, "autofill": {}, "shared_candidates": [],
                    "read_only": [], "notes": []}

    def find(names: set[str], kinds: set[str]):
        exact = [p for p in props if _norm(p["name"]) in names]
        good = [p for p in exact if p["type"] in kinds]
        return (good[0], None) if good else ((None, exact[0]) if exact else (None, None))

    t_ok, t_bad = find(TYPE_NAMES, {"select", "status"})
    g_ok, g_bad = find(TAG_NAMES, {"multi_select"})
    result["type"] = {"property": t_ok["name"], "kind": t_ok["type"], "options": t_ok.get("options", [])} if t_ok else None
    result["tags"] = {"property": g_ok["name"], "kind": g_ok["type"], "options": g_ok.get("options", [])} if g_ok else None
    if not t_ok:
        result["notes"].append(
            f"Type property found with the wrong kind ({t_bad['name']}: {t_bad['type']}); ask which to use or add one"
            if t_bad else "no Type property: offer to add a select property named Type (needs explicit approval)")
    if not g_ok:
        result["notes"].append(
            f"Tags property found with the wrong kind ({g_bad['name']}: {g_bad['type']}); ask which to use or add one"
            if g_bad else "no Tags property: offer to add a multi-select property named Tags (needs explicit approval)")
    used = {result["type"]["property"] if result["type"] else None,
            result["tags"]["property"] if result["tags"] else None, title}
    for key, (names, kinds) in AUTOFILL_HINTS.items():
        for p in props:
            if p["name"] in used or p["type"] in READ_ONLY:
                continue
            if _norm(p["name"]) in names and p["type"] in kinds and p["type"] != "title":
                result["autofill"][key] = p["name"]
                used.add(p["name"])
                break
    for p in props:
        if p["type"] in READ_ONLY:
            result["read_only"].append(p["name"])
        elif p["name"] not in used and p["type"] != "title":
            result["shared_candidates"].append({"name": p["name"], "type": p["type"], "options": p.get("options", [])})
    return result


def convert_value(kind: str, name: str, value) -> dict:
    """One property value in the form notion-create-pages expects (verify against the fetched schema)."""
    if value is None or value == "":
        return {}
    if kind == "date":
        return {f"date:{name}:start": str(value), f"date:{name}:is_datetime": 0}
    if kind == "checkbox":
        return {name: "__YES__" if str(value).lower() in ("1", "true", "yes", "y", "__yes__") else "__NO__"}
    if kind == "number":
        return {name: float(value) if "." in str(value) else int(value)}
    if kind in ("multi_select", "people", "relation", "files"):
        return {name: list(value) if isinstance(value, (list, tuple)) else [str(value)]}
    return {name: str(value)}


def build_properties(mapping: dict, pdf: dict, shared: dict, schema: dict) -> dict:
    """mapping: output of map_schema (possibly edited); pdf: {title, source_file, pages, type, tags};
    shared: {property: value} applied to every page."""
    kinds = {p["name"]: p["type"] for p in schema.get("properties", [])}
    out: dict = {}
    out[mapping["title_property"]] = pdf["title"]
    if mapping.get("type") and pdf.get("type"):
        out.update(convert_value(mapping["type"]["kind"], mapping["type"]["property"], pdf["type"]))
    if mapping.get("tags") and pdf.get("tags"):
        out.update(convert_value("multi_select", mapping["tags"]["property"], pdf["tags"]))
    auto = mapping.get("autofill", {})
    if "source" in auto:
        out.update(convert_value(kinds.get(auto["source"], "rich_text"), auto["source"], pdf.get("source_file")))
    if "pages" in auto:
        out.update(convert_value("number", auto["pages"], pdf.get("pages")))
    if "imported" in auto:
        out.update(convert_value("date", auto["imported"], pdf.get("imported") or date.today().isoformat()))
    for name, value in (shared or {}).items():
        if kinds.get(name) in READ_ONLY:
            continue
        out.update(convert_value(kinds.get(name, "rich_text"), name, value))
    return out


def new_options(mapping: dict, per_pdf: list[dict]) -> dict:
    """Select / multi-select options the approved values would create (needs the user's approval first)."""
    created: dict = {"type": [], "tags": []}
    if mapping.get("type"):
        known = {o.lower() for o in mapping["type"].get("options", [])}
        created["type"] = sorted({p["type"] for p in per_pdf if p.get("type") and p["type"].lower() not in known})
    if mapping.get("tags"):
        known = {o.lower() for o in mapping["tags"].get("options", [])}
        created["tags"] = sorted({t for p in per_pdf for t in p.get("tags", []) if t.lower() not in known})
    return created
