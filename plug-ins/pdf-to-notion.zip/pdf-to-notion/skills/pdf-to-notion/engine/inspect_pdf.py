"""Inspection: inventory of the PDFs and the proposed page tree / split plan (Gate 1 material)."""
from __future__ import annotations

import re
from pathlib import Path

try:
    import pymupdf
except ImportError:  # pragma: no cover
    import fitz as pymupdf  # type: ignore

from common import Project, read_json, sha1_file, slugify, word_count, write_json, log
from pdfscan import extract_document, summarize

HU_WORDS = {"a", "az", "és", "hogy", "nem", "is", "egy", "meg", "van", "de", "csak", "mint", "ez", "vagy", "volt",
            "kell", "lehet", "során", "szerint", "alapján", "illetve"}
EN_WORDS = {"the", "and", "of", "to", "in", "is", "that", "for", "with", "as", "are", "this", "be", "or", "by",
            "from", "which", "not", "on"}


def collect_pdfs(inputs: list[str], recursive: bool = False) -> list[Path]:
    found: list[Path] = []
    for raw in inputs:
        p = Path(raw).expanduser()
        if p.is_dir():
            it = p.rglob("*") if recursive else p.glob("*")
            found += [f for f in it if f.is_file() and f.suffix.lower() == ".pdf"]
        elif p.is_file() and p.suffix.lower() == ".pdf":
            found.append(p)
        else:
            log(f"skipped (not a PDF or folder): {p}")

    def natural(path: Path):
        return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", path.name)]

    return sorted({f.resolve() for f in found}, key=lambda f: (str(f.parent), natural(f)))


def guess_language(text: str) -> str:
    toks = re.findall(r"[^\W\d_]+", text.lower())[:4000]
    hu = sum(1 for t in toks if t in HU_WORDS) + sum(1 for t in toks if re.search(r"[őű]", t)) * 2
    en = sum(1 for t in toks if t in EN_WORDS)
    if hu > en * 0.8 and hu > 5:
        return "hu"
    return "en" if en > 5 else "unknown"


def pretty_title(path: Path) -> str:
    return re.sub(r"[_\-]+", " ", path.stem).strip().title() or path.stem


def pick_title(doc, extraction: dict, path: Path) -> str:
    meta = (doc.metadata or {}).get("title", "").strip()
    if meta and len(meta) > 3 and not re.search(r"\.(pdf|docx?|pptx?|indd)$|^untitled|^microsoft", meta, re.I):
        return meta
    for p in extraction["pages"][:2]:
        for b in p["blocks"]:
            if b["t"] == "title":
                return b["text"]
    for p in extraction["pages"][:2]:
        for b in p["blocks"]:
            if b["t"] == "heading" and b["level"] == 1:
                return b["text"]
    return pretty_title(path)


def _chapter_words(extraction: dict, start: int, end: int) -> int:
    total = 0
    for p in extraction["pages"][start - 1:end]:
        for b in p["blocks"]:
            if b["t"] == "table":
                total += sum(word_count(c) for r in b["rows"] for c in r)
            else:
                total += word_count(b.get("text", ""))
    return total


def propose_chapters(extraction: dict, npages: int, words: int, split_cfg: dict, labels: dict) -> tuple[bool, str, list[dict]]:
    """Return (split?, reason, chapters)."""
    if npages <= split_cfg["threshold_pages"] and words <= split_cfg["threshold_words"]:
        return False, f"{npages} pages / {words} words is under the split threshold", []
    starts: list[tuple[int, str]] = []
    reason = ""
    for method in split_cfg["points"]:
        if method == "outline":
            toc = [t for t in extraction["outline"] if t[1].strip()]
            if toc:
                top = min(t[0] for t in toc)
                seen: dict[int, str] = {}
                for lvl, title, pg in toc:
                    if lvl == top and 1 <= pg <= npages and pg not in seen:
                        seen[pg] = title.strip()
                if len(seen) >= 2:
                    starts, reason = sorted(seen.items()), "split at the top level of the PDF outline"
                    break
        elif method == "h1":
            seen = {}
            for p in extraction["pages"]:
                for b in p["blocks"]:
                    if b["t"] == "heading" and b["level"] == 1 and p["page"] not in seen:
                        seen[p["page"]] = b["text"]
            if len(seen) >= 2:
                starts, reason = sorted(seen.items()), "split at detected top-level headings"
                break
        elif method == "ranges":
            step = max(1, split_cfg["range_pages"])
            starts = [(pg, "") for pg in range(1, npages + 1, step)]
            reason = f"no outline or headings found; split into ranges of {step} pages"
            break
    if len(starts) < 2:
        return False, "no usable split points found", []

    chapters: list[dict] = []
    first_page = starts[0][0]
    if first_page > 1:
        front_words = _chapter_words(extraction, 1, first_page - 1)
        if front_words >= 60:
            chapters.append({"title": labels.get("front_matter", "Front matter"), "start_page": 1,
                             "end_page": first_page - 1})
        else:
            starts[0] = (1, starts[0][1])
    for i, (pg, title) in enumerate(starts):
        end = (starts[i + 1][0] - 1) if i + 1 < len(starts) else npages
        if not title:
            title = f"{labels.get('pages', 'pages').capitalize()} {pg}–{end}"
        chapters.append({"title": title, "start_page": pg, "end_page": end})
    for ch in chapters:
        ch["words"] = _chapter_words(extraction, ch["start_page"], ch["end_page"])
    return True, reason, chapters


def finalize_ids(chapters: list[dict]) -> list[dict]:
    seen: set[str] = set()
    for i, ch in enumerate(chapters, 1):
        base = f"c{i:02d}-{slugify(ch['title'], 32)}"
        ch["id"] = base if base not in seen else f"{base}-{i}"
        seen.add(ch["id"])
    return chapters


def inspect_pdf(path: Path, proj: Project, split_cfg: dict, labels: dict, ocr_lang: str | None) -> tuple[dict, dict, dict]:
    doc = pymupdf.open(str(path))
    if doc.needs_pass:
        raise SystemExit(f"{path.name} is password-protected; unlock it first (the plugin never asks for passwords)")
    slug = slugify(path.stem) + "-" + sha1_file(path)[:6]
    extraction = extract_document(doc, slug, min_image_px=split_cfg["min_image_px"], images_dir=None, ocr_lang=None)
    stats = summarize(extraction)
    sample = " ".join(b.get("text", "") for p in extraction["pages"][:12] for b in p["blocks"] if b["t"] in ("para", "heading", "li"))
    scanned = extraction["scanned"]
    title = pick_title(doc, extraction, path)
    rects = [doc[i].rect for i in range(min(3, doc.page_count))]
    landscape = bool(rects) and sum(1 for r in rects if r.width > r.height) > len(rects) / 2
    split, reason, chapters = propose_chapters(extraction, doc.page_count, stats["words"], split_cfg, labels)
    chapters = finalize_ids(chapters) if split else []
    info = {
        "slug": slug, "source": str(path), "file": path.name, "bytes": path.stat().st_size,
        "title": title, "pages": doc.page_count, "language": guess_language(sample),
        "scanned": scanned, "scanned_pages": extraction["scanned_pages"], "landscape": landscape,
        "has_outline": bool(extraction["outline"]), "outline_entries": len(extraction["outline"]),
        "outline_used_for_headings": extraction["outline_used"], "body_font_size": extraction["body_size"],
        "stats": stats, "warnings": extraction["warnings"],
        "avg_words_per_page": round(stats["words"] / max(1, doc.page_count)),
    }
    if scanned:
        info["warnings"].append("scanned PDF: text needs OCR (lower fidelity); run extract with --ocr-lang")
    plan = {"slug": slug, "source": str(path), "title": title, "pages": doc.page_count, "split": split,
            "reason": reason, "chapters": chapters}
    sample_blocks = {"headings": [b["text"] for p in extraction["pages"] for b in p["blocks"] if b["t"] == "heading"][:80],
                     "text": sample[:6000], "category_text": " ".join(
                         b.get("text", "") for p in extraction["pages"] for b in p["blocks"] if b["t"] in ("para", "heading", "title"))[:60000]}
    doc.close()
    return info, plan, sample_blocks


def run_inspect(proj: Project, inputs: list[str], recursive: bool, split_cfg: dict, labels: dict) -> dict:
    pdfs = collect_pdfs(inputs, recursive)
    if not pdfs:
        raise SystemExit("no PDF files found in the given paths")
    infos, plans = [], []
    for path in pdfs:
        log(f"inspecting {path.name} ...")
        info, plan, sample = inspect_pdf(path, proj, split_cfg, labels, None)
        write_json(proj.extract / info["slug"] / "inspect-sample.json", sample)
        infos.append(info)
        plans.append(plan)
    feats = {"headings": 0, "tables": 0, "images": 0, "list_items": 0, "code_blocks": 0, "quotes": 0,
             "callout_candidates": 0, "footnote_candidates": 0}
    for i in infos:
        for k in feats:
            feats[k] += i["stats"].get(k, 0)
    feats["split_pdfs"] = sum(1 for p in plans if p["split"])
    inventory = {"pdfs": infos, "features": feats,
                 "totals": {"pdfs": len(infos), "pages": sum(i["pages"] for i in infos),
                            "words": sum(i["stats"]["words"] for i in infos)}}
    write_json(proj.inventory, inventory)
    write_json(proj.plan, {"pdfs": plans})
    return inventory


def render_tree(proj: Project, dest_label: str = "(destination not chosen yet)") -> list[str]:
    inv = read_json(proj.inventory, {"pdfs": []})
    plan = read_json(proj.plan, {"pdfs": []})
    by_slug = {i["slug"]: i for i in inv["pdfs"]}
    lines = [f"Destination: {dest_label}"]
    for p in plan["pdfs"]:
        i = by_slug.get(p["slug"], {})
        flags = []
        if i.get("scanned"):
            flags.append("scanned, OCR needed")
        s = i.get("stats", {})
        lines.append(f"- {p['title']}  [{p['pages']} pp, {s.get('words', 0)} words, {s.get('images', 0)} images, "
                     f"{s.get('tables', 0)} tables{', ' + ', '.join(flags) if flags else ''}]")
        if p["split"]:
            lines.append(f"    ({p['reason']})")
            for n, ch in enumerate(p["chapters"], 1):
                lines.append(f"    {n}. {ch['title']}  (pp. {ch['start_page']}–{ch['end_page']}, {ch.get('words', 0)} words)")
        else:
            lines.append(f"    single page ({p['reason']})")
    return lines


def edit_plan(proj: Project, slug: str, op: str, args: list[str], split_cfg: dict, labels: dict) -> dict:
    plan = read_json(proj.plan)
    entry = next((p for p in plan["pdfs"] if p["slug"] == slug or p["slug"].startswith(slug)), None)
    if entry is None:
        raise SystemExit(f"no PDF {slug!r} in plan")
    if op == "split-off":
        entry.update({"split": False, "chapters": [], "reason": "kept as a single page (your choice)"})
    elif op == "ranges":
        step = int(args[0])
        entry["chapters"] = [{"title": "", "start_page": pg, "end_page": min(entry["pages"], pg + step - 1)}
                             for pg in range(1, entry["pages"] + 1, step)]
        for ch in entry["chapters"]:
            ch["title"] = f"{labels.get('pages', 'pages').capitalize()} {ch['start_page']}–{ch['end_page']}"
        entry.update({"split": True, "reason": f"ranges of {step} pages (your choice)"})
    elif op == "rename":
        idx, title = int(args[0]), " ".join(args[1:])
        entry["chapters"][idx - 1]["title"] = title
    elif op == "merge":
        a, b = int(args[0]), int(args[1])
        if b != a + 1:
            raise SystemExit("merge needs two consecutive chapters, e.g. merge 3 4")
        ca, cb = entry["chapters"][a - 1], entry["chapters"][b - 1]
        ca["end_page"] = cb["end_page"]
        ca["words"] = ca.get("words", 0) + cb.get("words", 0)
        del entry["chapters"][b - 1]
    elif op == "split-on":
        raise SystemExit("re-run inspect with a lower threshold (--split-pages) to split a PDF that was kept whole")
    else:
        raise SystemExit(f"unknown plan op {op!r}")
    if entry["split"]:
        finalize_ids(entry["chapters"])
    write_json(proj.plan, plan)
    return entry
