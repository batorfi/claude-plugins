"""manifest.json: the single record of a run (destination, pages created, uploads, gates).

Everything resumable lives here, so a stopped run can continue without asking again and a
re-run never creates duplicate pages.
"""
from __future__ import annotations

from common import Project, now_iso, read_json, write_json

STEPS = [
    "inspect",      # inventory + split plan written
    "destination",  # Notion location (and database properties) confirmed
    "gate1",        # user approved tree + destination + properties
    "style",        # style.json approved
    "extract",      # blocks and images on disk
    "uploads",      # images (and original PDFs) uploaded to Notion
    "pages",        # pages created (pass 1)
    "nav",          # navigation + contents lists written (pass 2)
    "verify",       # verification report written
]


def load(proj: Project) -> dict:
    m = read_json(proj.manifest)
    if m is None:
        m = {"version": 1, "project": proj.name, "created": now_iso(), "destination": None,
             "pdfs": {}, "steps": {}}
    return m


def save(proj: Project, m: dict) -> None:
    m["updated"] = now_iso()
    write_json(proj.manifest, m)


def mark(proj: Project, step: str, note: str | None = None) -> dict:
    if step not in STEPS:
        raise SystemExit(f"unknown step {step!r}; expected one of {STEPS}")
    m = load(proj)
    m["steps"][step] = {"at": now_iso(), **({"note": note} if note else {})}
    save(proj, m)
    return m["steps"][step]


def status(proj: Project) -> dict:
    m = load(proj)
    done = [s for s in STEPS if s in m["steps"]]
    nxt = next((s for s in STEPS if s not in m["steps"]), None)
    pdfs = m.get("pdfs", {})
    pages_total = sum(1 + len(p.get("chapters", [])) for p in pdfs.values())
    pages_done = sum((1 if p.get("notion", {}).get("page_id") else 0) +
                     sum(1 for c in p.get("chapters", []) if c.get("page_id")) for p in pdfs.values())
    return {"project": proj.name, "done": done, "next": nxt, "pdfs": len(pdfs),
            "pages_created": pages_done, "pages_planned": pages_total,
            "destination": m.get("destination")}


def set_destination(proj: Project, dest: dict) -> dict:
    m = load(proj)
    m["destination"] = dest
    save(proj, m)
    return dest


def ensure_pdf(m: dict, slug: str, **fields) -> dict:
    entry = m["pdfs"].setdefault(slug, {"chapters": [], "images": {}})
    entry.update({k: v for k, v in fields.items() if v is not None})
    return entry


def record_page(proj: Project, slug: str, chapter_id: str | None, page_id: str, url: str | None) -> dict:
    """chapter_id None records the PDF's top page; otherwise the chapter subpage."""
    m = load(proj)
    entry = m["pdfs"].get(slug)
    if entry is None:
        raise SystemExit(f"unknown pdf slug {slug!r}")
    if chapter_id is None:
        entry["notion"] = {"page_id": page_id, "url": url}
    else:
        for ch in entry["chapters"]:
            if ch["id"] == chapter_id:
                ch["page_id"], ch["url"] = page_id, url
                break
        else:
            raise SystemExit(f"unknown chapter {chapter_id!r} in {slug!r}")
    save(proj, m)
    return {"slug": slug, "chapter": chapter_id, "page_id": page_id}


def record_upload(proj: Project, slug: str, image_id: str, **fields) -> dict:
    m = load(proj)
    entry = m["pdfs"].get(slug)
    if entry is None:
        raise SystemExit(f"unknown pdf slug {slug!r}")
    img = entry["images"].setdefault(image_id, {})
    img.update({k: v for k, v in fields.items() if v is not None})
    save(proj, m)
    return img
