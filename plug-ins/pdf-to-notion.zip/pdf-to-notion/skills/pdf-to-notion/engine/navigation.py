"""Previous / Contents / Next footers and the contents list on the PDF's top page.

The footer is plain Notion markdown, so it can be found again on a fetched page and replaced
(idempotent: re-running never stacks a second footer).

    ---
    ← Previous: <mention-page ...>Title</mention-page> | ↑ Contents: <mention-page ...>Doc</mention-page> | Next: <mention-page ...>Title</mention-page> →
"""
from __future__ import annotations

import re

from common import esc, normalize_id, read_json, write_json, Project

SEP = " \\| "  # escaped pipe: '|' is a Notion-markdown special character


def page_url(rec: dict) -> str | None:
    if rec.get("url"):
        return rec["url"]
    pid = normalize_id(rec.get("page_id", ""))
    return f"https://www.notion.so/{pid}" if pid else None


def mention(url: str, title: str) -> str:
    safe = title.replace("<", "").replace(">", "")
    return f'<mention-page url="{url}">{safe}</mention-page>'


def _part(kind: str, target: dict | None, style: dict, labels: dict) -> str | None:
    if not target or not target.get("url"):
        return None
    mode = style["chrome"]["navigation"]["link_labels"]
    url, title = target["url"], target["title"]
    word = {"prev": labels.get("previous", "Previous"), "contents": labels.get("contents", "Contents"),
            "next": labels.get("next", "Next")}[kind]
    arrow_l, arrow_r = {"prev": ("← ", ""), "contents": ("↑ ", ""), "next": ("", " →")}[kind]
    if mode == "generic":
        return f"[{arrow_l}{esc(word)}{arrow_r}]({url})"
    if mode == "title":
        return f"{arrow_l}{mention(url, title)}{arrow_r}"
    return f"{arrow_l}{esc(word)}: {mention(url, title)}{arrow_r}"


def footer_line(prev, parent, nxt, style: dict, labels: dict) -> str | None:
    ncfg = style["chrome"]["navigation"]
    parts = [_part("prev", prev, style, labels)]
    if ncfg["contents_link"]:
        parts.append(_part("contents", parent, style, labels))
    parts.append(_part("next", nxt, style, labels))
    parts = [p for p in parts if p]
    return SEP.join(parts) if parts else None


def build_footers(prev, parent, nxt, style: dict, labels: dict) -> dict:
    ncfg = style["chrome"]["navigation"]
    line = footer_line(prev, parent, nxt, style, labels)
    if not line:
        return {"top": None, "bottom": None}
    div = ncfg["divider"]
    bottom = ("---\n" if div else "") + line + "\n"
    top = line + "\n" + ("---\n" if div else "")
    place = ncfg["placement"]
    return {"top": top if place == "top_and_bottom" else None, "bottom": bottom}


def nav_plan(proj: Project, style: dict, manifest: dict) -> dict:
    """Footer markdown for every page that needs one, keyed by page id."""
    plan = read_json(proj.plan, {"pdfs": []})
    labels = style["labels"]
    ncfg = style["chrome"]["navigation"]
    dest = manifest.get("destination") or {}
    out, missing = [], []
    if not ncfg["enabled"]:
        return {"pages": [], "missing": [], "note": "navigation is switched off in style.json"}
    for pdf in plan["pdfs"]:
        entry = manifest["pdfs"].get(pdf["slug"], {})
        top = entry.get("notion", {})
        top_ref = {"url": page_url(top), "title": pdf["title"]} if top.get("page_id") else None
        if not top_ref or not top_ref["url"]:
            missing.append(f"{pdf['title']} (top page)")
            continue
        if not pdf["split"]:
            if ncfg["single_page_footer"] == "contents" and dest.get("kind") == "page" and dest.get("url"):
                f = build_footers(None, {"url": dest["url"], "title": dest.get("title") or "Contents"}, None, style, labels)
                if f["bottom"]:
                    out.append({"slug": pdf["slug"], "page_id": top["page_id"], "title": pdf["title"], **f})
            continue
        chapters = entry.get("chapters", [])
        refs = []
        for ch in chapters:
            if not ch.get("page_id") or not page_url(ch):
                missing.append(f"{pdf['title']} / {ch['title']}")
            refs.append({"url": page_url(ch), "title": ch["title"]})
        if len(missing):
            continue
        for i, ch in enumerate(chapters):
            f = build_footers(refs[i - 1] if i > 0 else None, top_ref, refs[i + 1] if i + 1 < len(refs) else None,
                              style, labels)
            out.append({"slug": pdf["slug"], "page_id": ch["page_id"], "title": ch["title"],
                        "chapter_id": ch["id"], **f})
    result = {"pages": out, "missing": missing}
    write_json(proj.build / "nav.json", result)
    return result


def toc_markdown(pdf: dict, entry: dict, style: dict) -> str | None:
    labels = style["labels"]
    chapters = entry.get("chapters", [])
    lines = [f"**{esc(labels.get('contents', 'Contents'))}**"]
    for n, ch in enumerate(pdf["chapters"], 1):
        rec = next((c for c in chapters if c["id"] == ch["id"]), None)
        if not rec or not page_url(rec):
            return None
        span = f"{ch['start_page']}–{ch['end_page']}" if ch["end_page"] > ch["start_page"] else str(ch["start_page"])
        word = labels.get("pages", "pages") if ch["end_page"] > ch["start_page"] else labels.get("page", "page")
        lines.append(f"{n}. {mention(page_url(rec), ch['title'])} · {esc(word)} {span}")
    return "\n".join(lines) + "\n"


def toc_plan(proj: Project, style: dict, manifest: dict) -> list[dict]:
    plan = read_json(proj.plan, {"pdfs": []})
    out = []
    if style["structure"]["toc"] != "parent_list":
        return out
    for pdf in plan["pdfs"]:
        if not pdf["split"]:
            continue
        entry = manifest["pdfs"].get(pdf["slug"], {})
        md = toc_markdown(pdf, entry, style)
        top = entry.get("notion", {})
        if md and top.get("page_id"):
            out.append({"slug": pdf["slug"], "page_id": top["page_id"], "markdown": md})
    return out


# ------------------------------------------------------------------ finding existing footers
def is_nav_line(line: str) -> bool:
    s = line.strip()
    if not s or len(s) > 900:
        return False
    if "<mention-page" not in s and "notion.so/" not in s:
        return False
    return bool(re.match(r"^(\[?←|\[?↑)", s) or re.search(r"(→|→\]\([^)]*\))\s*$", s))


def find_footers(md: str) -> dict:
    """Locate an existing footer (and optional top bar) in a fetched page; exact substrings to replace."""
    lines = md.splitlines()
    n = len(lines)
    result = {"bottom": None, "top": None}
    nonempty = [i for i, ln in enumerate(lines) if ln.strip()]
    tail = [i for i in nonempty[-6:] if is_nav_line(lines[i])]
    if tail:
        i = tail[-1]
        j = i - 1
        while j >= 0 and not lines[j].strip():
            j -= 1
        start = j if j >= 0 and lines[j].strip() == "---" else i
        result["bottom"] = "\n".join(lines[start:i + 1])
    head = [i for i in nonempty[:6] if is_nav_line(lines[i])]
    if head and (not tail or head[0] != tail[-1]):
        i = head[0]
        j = i + 1
        while j < n and not lines[j].strip():
            j += 1
        end = j if j < n and lines[j].strip() == "---" else i
        result["top"] = "\n".join(lines[i:end + 1])
    return result


def find_toc(md: str, contents_label: str) -> str | None:
    lines = md.splitlines()
    label = re.escape(esc(contents_label))
    for i, ln in enumerate(lines):
        if re.fullmatch(r"\*\*" + label + r"\*\*", ln.strip()) or ln.strip() == f"**{contents_label}**":
            j = i + 1
            while j < len(lines) and re.match(r"^\d+\.\s", lines[j].strip()) and "mention-page" in lines[j]:
                j += 1
            if j > i + 1:
                return "\n".join(lines[i:j])
    return None
