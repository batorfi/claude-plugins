"""Block model + style.json -> Notion-flavoured markdown, one file per Notion page.

Notion markdown notes that shaped this module (from the Enhanced Markdown spec):
  * children of toggles/callouts are indented with tabs; table cells hold rich text only
  * headings stop at level 3 (4 is accepted but we use 1-3); toggle headings use {toggle="true"}
  * there is no image-width attribute and no stored open/closed state for toggles
  * special characters  \\ * ~ ` $ [ ] < > { } | ^  must be escaped in plain text
"""
from __future__ import annotations

import re
from pathlib import Path

from common import Project, esc, read_json, word_count, write_json, write_text

TOC_TOKEN = "PDFNOTION-TOC"
APPENDIX_RE = re.compile(r"^\s*(appendix|appendices|references|bibliography|glossary|footnotes|notes|függelék|"
                         r"irodalom|irodalomjegyzék|források|szószedet|jegyzetek|mellékletek?)\b", re.IGNORECASE)
NUMBERING_RE = re.compile(r"^\s*(?:(?:chapter|fejezet|section|part)\s+\d+[.:]?|\d+(?:\.\d+)*\.?|[IVXLC]+\.|[A-Z]\.)\s+",
                          re.IGNORECASE)
CALLOUT_STYLE = {
    "note": ("ℹ️", "blue_bg"), "warning": ("⚠️", "red_bg"), "tip": ("💡", "green_bg"),
    "important": ("❗", "orange_bg"), "example": ("📘", "gray_bg"),
}
TYPE_ICONS = {
    "manual": "📘", "guide": "📘", "handbook": "📘", "report": "📊", "paper": "🔬", "article": "📰",
    "slides": "🖥️", "presentation": "🖥️", "contract": "📑", "agreement": "📑", "datasheet": "📋",
    "reference": "📚", "book": "📖", "invoice": "🧾", "proposal": "📝", "specification": "📐",
}


def icon_for_type(type_name: str | None) -> str:
    return TYPE_ICONS.get((type_name or "").strip().lower(), "📄")


def strip_numbering(text: str) -> str:
    stripped = NUMBERING_RE.sub("", text, count=1)
    return stripped if stripped.strip() else text


def guess_code_language(code: str) -> str:
    c = code.strip()
    if re.match(r"^(def |class |import |from \w+ import |@\w+)", c) or re.search(r"^\s*(if|for|while) .*:$", c, re.M):
        return "python"
    if re.search(r"\b(function|const|let|var)\b.*[=({]|=>|console\.log", c):
        return "javascript"
    if c.startswith(("<?xml", "<!DOCTYPE", "<html", "<div", "<")) and c.rstrip().endswith(">"):
        return "html" if re.search(r"<(html|div|body|span|p)\b", c) else "xml"
    if (c.startswith("{") and c.endswith("}")) or (c.startswith("[") and c.endswith("]")):
        return "json"
    if re.match(r"^(SELECT|INSERT|UPDATE|DELETE|CREATE)\b", c, re.I):
        return "sql"
    if re.match(r"^(\$ |sudo |apt |pip |npm |cd |ls |curl |git |brew )", c):
        return "bash"
    if re.search(r"#include|std::|int main\(", c):
        return "c++"
    return "plain text"


# ------------------------------------------------------------------ rendering primitives
def indent(lines: list[str], n: int = 1) -> list[str]:
    pad = "\t" * n
    return [(pad + ln) if ln else ln for ln in lines]


def heading_line(level: int, text: str, style: dict, toggle: bool) -> str:
    attrs = []
    if toggle:
        attrs.append('toggle="true"')
    if style["look"]["color"]["headings"]:
        attrs.append(f'color="{style["look"]["color"]["accent"]}"')
    suffix = (" {" + " ".join(attrs) + "}") if attrs else ""
    return f"{'#' * level} {esc(text)}{suffix}"


def table_lines(rows: list[list[str]], style: dict) -> list[str]:
    tcfg = style["blocks"]["tables"]
    ncols = max(len(r) for r in rows)
    rows = [r + [""] * (ncols - len(r)) for r in rows]
    chunks = [list(range(ncols))]
    if tcfg["wide"] == "split" and ncols > tcfg["max_columns"]:
        step = tcfg["max_columns"] - 1
        rest = list(range(1, ncols))
        chunks = [[0] + rest[i:i + step] for i in range(0, len(rest), step)]
    out: list[str] = []
    for ci, cols in enumerate(chunks):
        attrs = ['fit-page-width="true"']
        attrs.append(f'header-row="{"true" if tcfg["header_row"] else "false"}"')
        if tcfg["header_column"]:
            attrs.append('header-column="true"')
        out.append("<table " + " ".join(attrs) + ">")
        for ri, r in enumerate(rows):
            tr = "<tr"
            if ri == 0 and tcfg["header_row"] and style["look"]["color"]["table_header"]:
                tr += ' color="gray_bg"'
            tr += ">"
            out.append("\t" + tr)
            for c in cols:
                out.append("\t\t<td>" + esc(r[c]).replace("\n", "<br>") + "</td>")
            out.append("\t</tr>")
        out.append("</table>")
    return out


def callout_lines(blk: dict, style: dict) -> list[str]:
    ccfg, col = style["look"]["callouts"], style["look"]["color"]
    if not ccfg["enabled"]:
        label = (blk.get("label") or blk["callout"]).capitalize()
        return [f"**{esc(label)}:** {blk['text']}"]
    icon, color = CALLOUT_STYLE.get(blk["callout"], ("💬", "gray_bg"))
    attrs = []
    if ccfg["icons"] == "per_type":
        attrs.append(f'icon="{icon}"')
    elif ccfg["icons"] == "single":
        attrs.append('icon="💬"')
    if col["callouts_by_type"]:
        attrs.append(f'color="{"gray_bg" if col["palette"] == "mono" else color}"')
    return ["<callout" + ((" " + " ".join(attrs)) if attrs else "") + ">", "\t" + blk["text"], "</callout>"]


def pdf_block(rec: dict, file: str) -> list[str] | None:
    """The attached original PDF: Notion's own suggested markdown first, else a <pdf> block."""
    if rec.get("suggested_markdown"):
        return [rec["suggested_markdown"]]
    if rec.get("markdown_source"):
        return [f'<pdf src="{rec["markdown_source"]}">{esc(file)}</pdf>']
    return None


def image_line(blk: dict, style: dict, images: dict, allow_pending: bool, problems: list[str]) -> list[str]:
    icfg = style["blocks"]["images"]
    caption = ""
    if icfg["captions"]:
        cap, label = (blk.get("caption") or "").strip(), (blk.get("label") or "").strip()
        if icfg["numbering"] == "keep" and label:
            caption = f"{label}: {cap}" if cap else label
        else:
            caption = cap
    rec = images.get(blk["id"], {})
    src, sug = rec.get("markdown_source"), rec.get("suggested_markdown")
    if caption and src:
        return [f"![{esc(caption)}]({src})"]
    if sug:
        return [sug]
    if src:
        return [f"![]({src})"]
    if not allow_pending:
        problems.append(blk["id"])
    return [f"![{esc(caption)}](pending:{blk['id']})"]


# ------------------------------------------------------------------ section tree
class Node:
    def __init__(self, depth: int, level: int, text: str):
        self.depth, self.level, self.text = depth, level, text
        self.children: list = []      # Node | list[str] (a rendered chunk)
        self.deferred: list[list[str]] = []
        self.words = 0


def _depth_map(blocks: list[dict], style: dict) -> dict[int, int]:
    raw = sorted({b["level"] for b in blocks if b["t"] == "heading"})
    hm = style["structure"]["heading_map"]
    mapping: dict[int, int] = {}
    for rank, lv in enumerate(raw, 1):
        mapping[lv] = rank
    return mapping


def _notion_level(depth: int, style: dict) -> int | None:
    hm = style["structure"]["heading_map"]
    if hm["mode"] == "manual":
        lv = hm["levels"].get(str(depth))
        if lv is not None:
            return int(lv)
    elif depth <= 3:
        return depth
    # deeper than the mapped levels
    return 3 if hm["deeper"] in ("merge", "toggle") else None


def build_tree(blocks: list[dict], style: dict, images: dict, allow_pending: bool,
               problems: list[str], footnotes: list[tuple[int, str]]) -> Node:
    root = Node(0, 0, "")
    stack = [root]
    dmap = _depth_map(blocks, style)
    placement = style["blocks"]["images"]["placement"]
    deeper = style["structure"]["heading_map"]["deeper"]
    list_counters: dict[int, int] = {}
    prev_was_li = False
    prev_ordered = False

    def container() -> Node:
        return stack[-1]

    for blk in blocks:
        t = blk["t"]
        if t != "li":
            list_counters.clear()
            prev_was_li = False
        if t == "title":
            continue
        if t == "footnote":
            footnotes.append((blk["n"], blk["text"]))
            continue
        if t == "heading":
            depth = dmap[blk["level"]]
            level = _notion_level(depth, style)
            text = strip_numbering(blk["text"]) if style["structure"]["chapter_numbering"] == "strip" else blk["text"]
            if level is None:  # deeper than three levels and set to bold
                container().children.append([f"**{esc(text)}**"])
                container().words += word_count(text)
                continue
            node = Node(depth if level == 3 and depth > 3 and deeper != "toggle" else min(depth, 4), level, text)
            if depth > 3:  # merged or toggle level: nest under the nearest level-3 section
                node.depth = 4
            while len(stack) > 1 and stack[-1].depth >= node.depth:
                stack.pop()
            stack[-1].children.append(node)
            stack.append(node)
            continue
        chunk: list[str]
        words = word_count(blk.get("text", "")) if t != "table" else sum(word_count(c) for r in blk["rows"] for c in r)
        if t == "para":
            chunk = callout_lines(blk, style) if blk.get("callout") else [blk["text"]]
        elif t == "li":
            depth = 0 if style["blocks"]["lists"] == "flatten" else blk["depth"]
            if not prev_was_li or prev_ordered != blk["ordered"]:
                list_counters.clear()  # a new list (or a bullet list turning into a numbered one) restarts at 1
            prev_ordered = blk["ordered"]
            list_counters = {d: n for d, n in list_counters.items() if d <= depth}
            list_counters[depth] = list_counters.get(depth, 0) + 1
            marker = f"{list_counters[depth]}." if blk["ordered"] else "-"
            chunk = ["\t" * depth + f"{marker} {blk['text']}"]
            prev_was_li = True
            # consecutive list items form one logical chunk
            cont = container().children
            if cont and isinstance(cont[-1], list) and getattr(cont[-1], "is_list", False) \
                    and getattr(cont[-1], "ordered", None) == blk["ordered"]:
                cont[-1].extend(chunk)
            else:
                lst = _ListChunk(chunk)
                lst.ordered = blk["ordered"]
                cont.append(lst)
            container().words += words
            continue
        elif t == "code":
            if style["blocks"]["code"]["blocks"]:
                lang = guess_code_language(blk["text"]) if style["blocks"]["code"]["language_guess"] else "plain text"
                chunk = [f"```{lang}"] + blk["text"].split("\n") + ["```"]
            else:
                chunk = ["`" + blk["text"].replace("`", "'").replace("\n", "<br>") + "`"]
        elif t == "quote":
            chunk = ["> " + blk["text"]] if style["blocks"]["quotes"] == "preserve" else [blk["text"]]
        elif t == "table":
            chunk = table_lines(blk["rows"], style)
        elif t == "image":
            chunk = image_line(blk, style, images, allow_pending, problems)
            if placement == "end_of_section":
                container().deferred.append(chunk)
                continue
        else:
            continue
        container().children.append(chunk)
        container().words += words
    _propagate_words(root)
    return root


class _ListChunk(list):
    is_list = True


def _propagate_words(node: Node) -> int:
    total = node.words
    for ch in node.children:
        if isinstance(ch, Node):
            total += _propagate_words(ch)
    node.words = total
    return total


def render_node_children(node: Node, style: dict, first_top: list[bool]) -> list[list[str]]:
    """Render a node's children to top-level chunks (each chunk = lines of one block)."""
    coll = style["structure"]["collapsible"]
    dividers = style["structure"]["dividers"] == "between_sections"
    chunks: list[list[str]] = []
    for ch in node.children:
        if isinstance(ch, Node):
            toggle = False
            if ch.depth == 1:
                if coll["mode"] == "all":
                    toggle = True
                elif coll["mode"] == "long":
                    toggle = ch.words > coll["min_words"]
                elif coll["mode"] == "appendix":
                    toggle = bool(APPENDIX_RE.match(ch.text))
            elif ch.depth == 4 and style["structure"]["heading_map"]["deeper"] == "toggle":
                toggle = True
            if ch.depth == 1 and dividers and not first_top[0]:
                chunks.append(["---"])
            if ch.depth == 1:
                first_top[0] = False
            head = heading_line(ch.level, ch.text, style, toggle)
            inner = render_node_children(ch, style, first_top)
            if toggle:
                body: list[str] = []
                for c in inner:
                    body += indent(c)
                chunks.append([head] + body)
            else:
                chunks.append([head])
                chunks.extend(inner)
        else:
            chunks.append(list(ch))
    chunks.extend(node.deferred)
    return chunks


def footnote_chunks(footnotes: list[tuple[int, str]], style: dict, labels: dict) -> list[list[str]]:
    if not footnotes:
        return []
    items = [[f"**{n}** {text}"] for n, text in footnotes]
    if style["blocks"]["footnotes"] == "collapsible":
        body: list[str] = []
        for it in items:
            body += indent(it)
        return [["<details>", f"<summary>{esc(labels.get('footnotes', 'Footnotes'))}</summary>", *body, "</details>"]]
    return [[f"{it[0]} {{color=\"gray\"}}"] for it in items]


def source_line(file: str, start: int, end: int, style: dict, labels: dict) -> list[str]:
    pages_word = labels.get("pages", "pages") if end > start else labels.get("page", "page")
    span = f"{start}–{end}" if end > start else f"{start}"
    return [f"{esc(labels.get('source', 'Source'))}: {esc(file)} · {esc(pages_word)} {span} {{color=\"gray\"}}"]


def count_markdown(md: str) -> dict:
    """Comparable counts used by verification: headings, tables, images, callouts, words."""
    text_lines = []
    in_code = False
    for ln in md.splitlines():
        if ln.strip().startswith("```"):
            in_code = not in_code
            continue
        text_lines.append(ln)
    body = "\n".join(text_lines)
    plain = re.sub(r"<[^>]+>|!\[[^\]]*\]\([^)]*\)|\{[^}]*\}", " ", body)
    plain = re.sub(r"[\\*_`~#>|\-]", " ", plain)
    return {
        "headings": len(re.findall(r"^[\t ]*#{1,4} ", md, flags=re.M)),
        "tables": len(re.findall(r"<table[ >]", md)),
        "images": len(re.findall(r"^[\t ]*!\[[^\]]*\]\(", md, flags=re.M)),
        "callouts": len(re.findall(r"<callout[ >]", md)),
        "words": word_count(plain),
    }


# ------------------------------------------------------------------ page assembly
def split_parts(chunks: list[list[str]], max_chars: int) -> list[str]:
    parts: list[list[str]] = [[]]
    size = 0
    for c in chunks:
        text_len = sum(len(x) + 1 for x in c)
        if parts[-1] and size + text_len > max_chars:
            parts.append([])
            size = 0
        parts[-1].extend(c)
        size += text_len
    return ["\n".join(p) + "\n" for p in parts if p]


def convert_project(proj: Project, style: dict, manifest: dict, allow_pending: bool = False) -> dict:
    plan = read_json(proj.plan, {"pdfs": []})
    inventory = read_json(proj.inventory, {"pdfs": []})
    meta = {i["slug"]: i for i in inventory["pdfs"]}
    labels = style["labels"]
    max_chars = style["limits"]["max_page_chars"]
    pages_out: list[dict] = []
    problems: list[str] = []
    out_dir = proj.build / "pages"
    for old in out_dir.glob("*.md") if out_dir.exists() else []:
        old.unlink()

    for pdf in plan["pdfs"]:
        slug = pdf["slug"]
        scan = read_json(proj.extract / slug / "pages.json")
        if scan is None:
            raise SystemExit(f"{pdf['title']}: no extraction found; run extract first")
        entry = manifest["pdfs"].get(slug, {})
        images = entry.get("images", {})
        ptype = entry.get("type")
        file = Path(pdf["source"]).name
        all_pages = scan["pages"]

        def page_blocks(a: int, b: int) -> list[dict]:
            return [blk for p in all_pages[a - 1:b] for blk in p["blocks"]]

        def make_page(blocks: list[dict], title: str, start: int, end: int, extra_head: list[list[str]],
                      with_toc_native: bool) -> list[str]:
            blocks = list(blocks)
            # the first heading that repeats the page title is the page title itself
            for i, b in enumerate(blocks[:6]):
                if b["t"] == "heading" and re.sub(r"\W+", "", b["text"].lower()) == re.sub(r"\W+", "", title.lower()):
                    del blocks[i]
                    break
            footnotes: list[tuple[int, str]] = []
            tree = build_tree(blocks, style, images, allow_pending, problems, footnotes)
            first_top = [True]
            body = render_node_children(tree, style, first_top)
            chunks: list[list[str]] = list(extra_head)
            if style["chrome"]["source_line"]:
                chunks.append(source_line(file, start, end, style, labels))
            if with_toc_native and style["structure"]["toc"] == "native" and any(
                    isinstance(c, Node) for c in tree.children):
                chunks.append(["<table_of_contents/>"])
            chunks.extend(body)
            chunks.extend(footnote_chunks(footnotes, style, labels))
            return split_parts(chunks, max_chars)

        if pdf["split"]:
            top_head: list[list[str]] = []
            n_ch, n_pages = len(pdf["chapters"]), pdf["pages"]
            top_head.append([f"{esc(labels.get('overview', 'Overview'))}: {n_ch} · {n_pages} "
                             f"{esc(labels.get('pages', 'pages'))} {{color=\"gray\"}}"])
            if style["structure"]["toc"] == "parent_list":
                top_head.append([TOC_TOKEN])
            if style["chrome"]["attach_original_pdf"]:
                rec = entry.get("original_pdf", {})
                blk = pdf_block(rec, file)
                if blk:
                    top_head.append(blk)
                elif not allow_pending and entry.get("original_pdf_expected"):
                    problems.append(f"{slug}:original_pdf")
            parts = split_parts(top_head + ([source_line(file, 1, n_pages, style, labels)] if style["chrome"]["source_line"] else []), max_chars)
            _emit(out_dir, f"{slug}", parts, pages_out, {
                "slug": slug, "kind": "pdf", "chapter_id": None, "title": pdf["title"],
                "icon": icon_for_type(ptype) if style["look"]["page_icon"] == "by_type" else None,
                "start_page": 1, "end_page": n_pages})
            for ch in pdf["chapters"]:
                title = strip_numbering(ch["title"]) if style["structure"]["chapter_numbering"] == "strip" else ch["title"]
                parts = make_page(page_blocks(ch["start_page"], ch["end_page"]), ch["title"], ch["start_page"],
                                  ch["end_page"], [], True)
                _emit(out_dir, f"{slug}.{ch['id']}", parts, pages_out, {
                    "slug": slug, "kind": "chapter", "chapter_id": ch["id"], "title": title,
                    "icon": "📄" if style["look"]["page_icon"] == "by_type" else None,
                    "start_page": ch["start_page"], "end_page": ch["end_page"]})
        else:
            extra: list[list[str]] = []
            if style["chrome"]["attach_original_pdf"]:
                rec = entry.get("original_pdf", {})
                blk = pdf_block(rec, file)
                if blk:
                    extra.append(blk)
                elif not allow_pending and entry.get("original_pdf_expected"):
                    problems.append(f"{slug}:original_pdf")
            parts = make_page(page_blocks(1, pdf["pages"]), pdf["title"], 1, pdf["pages"], extra, True)
            _emit(out_dir, f"{slug}", parts, pages_out, {
                "slug": slug, "kind": "pdf", "chapter_id": None, "title": pdf["title"],
                "icon": icon_for_type(ptype) if style["look"]["page_icon"] == "by_type" else None,
                "start_page": 1, "end_page": pdf["pages"]})

    cover = style["look"]["page_cover"]
    for p in pages_out:
        p["cover"] = cover["url"] if cover["mode"] == "url" else None
    result = {"pages": pages_out, "pending_images": sorted(set(problems))}
    write_json(proj.build / "pages.json", result)
    return result


def _emit(out_dir: Path, stem: str, parts: list[str], pages_out: list[dict], info: dict) -> None:
    files = []
    for i, text in enumerate(parts, 1):
        name = f"{stem}.md" if i == 1 else f"{stem}.part{i}.md"
        write_text(out_dir / name, text)
        files.append(str(out_dir / name))
    full = "".join(parts)
    pages_out.append({**info, "files": files, "chars": len(full), "counts": count_markdown(full)})
