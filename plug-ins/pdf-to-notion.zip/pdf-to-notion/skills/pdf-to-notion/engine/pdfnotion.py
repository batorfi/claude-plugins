#!/usr/bin/env python3
"""pdfnotion: local engine for the pdf-to-notion plugin. JSON on stdout, logs on stderr.

  python3 pdfnotion.py [--work DIR] [--project NAME] <command> ...

Commands: doctor, inspect, tree, plan, classify, dest, style, extract, uploads, convert,
          nav, toc, manifest, verify, status
Everything runs locally; the engine never talks to Notion. Claude does that with the connector.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import classify as classify_mod  # noqa: E402
import destination as dest_mod  # noqa: E402
import inspect_pdf as inspect_mod  # noqa: E402
import manifest as mf  # noqa: E402
import navigation as nav_mod  # noqa: E402
import notion_md  # noqa: E402
import style as style_mod  # noqa: E402
import uploads as up_mod  # noqa: E402
import verify as verify_mod  # noqa: E402
from common import Project, emit, log, read_json, sha1_file, write_json  # noqa: E402


def _json_arg(value: str):
    if value.startswith("@"):
        return json.loads(Path(value[1:]).read_text(encoding="utf-8"))
    return json.loads(value)


def _proj(args) -> Project:
    work = args.work or os.environ.get("PDF_TO_NOTION_WORK") or "./pdf-to-notion-work"
    return Project(work, args.project).ensure()


def _style(proj: Project) -> dict:
    s = read_json(proj.style)
    if s is None:
        raise SystemExit("no style.json yet; run the format step (style build) first")
    return s


# ---------------------------------------------------------------- doctor
def cmd_doctor(args):
    out = {"python": sys.version.split()[0], "checks": []}

    def check(name, ok, detail="", required=True):
        out["checks"].append({"name": name, "ok": bool(ok), "required": required, "detail": detail})

    try:
        import pymupdf  # noqa: F401
        check("PyMuPDF", True, getattr(pymupdf, "VersionBind", "") or "")
    except ImportError:
        try:
            import fitz  # noqa: F401
            check("PyMuPDF", True, "imported as fitz (older install)")
        except ImportError:
            check("PyMuPDF", False, "pip install pymupdf")
    try:
        import PIL  # noqa: F401
        check("Pillow", True, PIL.__version__, required=False)
    except ImportError:
        check("Pillow", False, "pip install Pillow (needed to shrink images over 20 MiB)", required=False)
    check("tesseract", shutil.which("tesseract"), "needed only for scanned PDFs (OCR); install with Hungarian data "
          "for Hungarian text", required=False)
    check("ocrmypdf", shutil.which("ocrmypdf"), "optional", required=False)
    check("defaults.json", style_mod.DEFAULTS_PATH.exists(), str(style_mod.DEFAULTS_PATH))
    out["ok"] = all(c["ok"] for c in out["checks"] if c["required"])
    emit(out)


# ---------------------------------------------------------------- inspect / plan / tree
def cmd_inspect(args):
    proj = _proj(args)
    defaults = style_mod.load_defaults()
    split_cfg = dict(defaults["split"])
    if args.split_pages:
        split_cfg["threshold_pages"] = args.split_pages
    if args.split_words:
        split_cfg["threshold_words"] = args.split_words
    if args.range_pages:
        split_cfg["range_pages"] = args.range_pages
    if args.min_image_px:
        split_cfg["min_image_px"] = args.min_image_px
    inv = inspect_mod.run_inspect(proj, args.paths, args.recursive, split_cfg, defaults["labels"][args.language])
    m = mf.load(proj)
    for i in inv["pdfs"]:
        mf.ensure_pdf(m, i["slug"], source=i["source"], title=i["title"], pages=i["pages"])
    mf.save(proj, m)
    mf.mark(proj, "inspect")
    emit({"inventory": str(proj.inventory), "plan": str(proj.plan), "totals": inv["totals"],
          "features": inv["features"], "tree": inspect_mod.render_tree(proj),
          "warnings": {i["file"]: i["warnings"] for i in inv["pdfs"] if i["warnings"]}})


def cmd_tree(args):
    proj = _proj(args)
    m = mf.load(proj)
    dest = m.get("destination") or {}
    label = dest.get("title") or dest.get("url") or "(destination not chosen yet)"
    emit({"tree": inspect_mod.render_tree(proj, f"{dest.get('kind', '')} {label}".strip())})


def cmd_plan(args):
    proj = _proj(args)
    defaults = style_mod.load_defaults()
    entry = inspect_mod.edit_plan(proj, args.slug, args.op, args.rest, defaults["split"],
                                  defaults["labels"][args.language])
    emit({"edited": entry["slug"], "split": entry["split"], "chapters": entry["chapters"]})


# ---------------------------------------------------------------- destination, classify
def cmd_dest(args):
    proj = _proj(args)
    if args.op == "parse":
        emit(dest_mod.parse(args.value))
    elif args.op == "map":
        emit(dest_mod.map_schema(_json_arg(args.value)))
    elif args.op == "set":
        d = _json_arg(args.value)
        mf.set_destination(proj, d)
        mf.mark(proj, "destination")
        emit(d)
    elif args.op == "props":
        spec = _json_arg(args.value)  # {mapping, schema, shared, pdfs:[{slug,title,source_file,pages,type,tags}]}
        out = {p["slug"]: dest_mod.build_properties(spec["mapping"], p, spec.get("shared", {}), spec["schema"])
               for p in spec["pdfs"]}
        emit({"properties": out, "new_options": dest_mod.new_options(spec["mapping"], spec["pdfs"])})
    else:
        raise SystemExit("dest ops: parse | map | set | props")


def cmd_classify(args):
    proj = _proj(args)
    inv = read_json(proj.inventory)
    if inv is None:
        raise SystemExit("run inspect first")
    existing = _json_arg(args.existing) if args.existing else {}
    out = []
    for info in inv["pdfs"]:
        sample = read_json(proj.extract / info["slug"] / "inspect-sample.json", {})
        out.append(classify_mod.classify_pdf(info, sample, existing.get("types", []), existing.get("tags", [])))
    emit({"suggestions": out})


def cmd_record(args):
    """Save approved per-PDF Type / Tags (and the shared property values) into the manifest."""
    proj = _proj(args)
    m = mf.load(proj)
    data = _json_arg(args.value)  # {slug: {"type": "...", "tags": [...]}}
    for slug, vals in data.items():
        entry = mf.ensure_pdf(m, slug)
        if "type" in vals:
            entry["type"] = vals["type"]
        if "tags" in vals:
            entry["tags"] = vals["tags"]
    mf.save(proj, m)
    emit({"recorded": list(data)})


# ---------------------------------------------------------------- style
def cmd_style(args):
    proj = _proj(args)
    op = args.op
    if op == "presets":
        emit({"presets": sorted(style_mod.PRESETS), "labels_languages": sorted(style_mod.load_defaults()["labels"])})
    elif op == "build":
        answers = _json_arg(args.answers) if args.answers else None
        s = style_mod.build(args.preset, answers, args.lang)
        write_json(proj.style, s)
        emit({"style": str(proj.style), "labels_need_translation": s["labels_need_translation"],
              "summary": style_mod.describe(s)})
    elif op == "describe":
        s = _style(proj)
        inv = read_json(proj.inventory)
        skip = {x["key"] for x in style_mod.applicable(inv)["skipped"]} if inv else set()
        emit({"summary": style_mod.describe(s, skip), "skipped": sorted(skip)})
    elif op == "applicable":
        inv = read_json(proj.inventory)
        if inv is None:
            raise SystemExit("run inspect first")
        emit(style_mod.applicable(inv))
    elif op == "set":
        s = _style(proj)
        style_mod.set_path(s, args.key, _json_arg(args.value))
        problems = style_mod.validate(s)
        if problems:
            raise SystemExit("invalid: " + "; ".join(problems))
        write_json(proj.style, s)
        emit({"set": args.key, "value": style_mod.get_path(s, args.key)})
    elif op == "profile-save":
        emit({"saved": style_mod.save_profile(proj, args.key, _style(proj))})
    elif op == "profile-load":
        s = style_mod.load_profile(proj, args.key)
        write_json(proj.style, s)
        emit({"loaded": args.key, "summary": style_mod.describe(s)})
    elif op == "profile-list":
        emit({"profiles": sorted(p.stem for p in proj.profiles.glob("*.json"))})
    elif op == "approve":
        mf.mark(proj, "style", args.key)
        emit({"approved": True})
    else:
        raise SystemExit("style ops: presets | build | describe | applicable | set | profile-save | profile-load | "
                         "profile-list | approve")


# ---------------------------------------------------------------- extract
def cmd_extract(args):
    import pymupdf
    from pdfscan import extract_document, summarize
    proj = _proj(args)
    s = _style(proj)
    plan = read_json(proj.plan)
    if plan is None:
        raise SystemExit("run inspect first")
    m = mf.load(proj)
    report = []
    for pdf in plan["pdfs"]:
        slug = pdf["slug"]
        out_dir = proj.extract / slug
        img_dir = out_dir / "images"
        if img_dir.exists():
            shutil.rmtree(img_dir)
        img_dir.mkdir(parents=True, exist_ok=True)
        log(f"extracting {Path(pdf['source']).name} ...")
        doc = pymupdf.open(pdf["source"])
        ex = extract_document(doc, slug, min_image_px=s["split"]["min_image_px"], images_dir=img_dir,
                              ocr_lang=args.ocr_lang)
        doc.close()
        write_json(out_dir / "pages.json", {"pages": ex["pages"], "outline_used": ex["outline_used"]})
        write_json(out_dir / "images.json", ex["images"])
        stats = summarize(ex)
        write_json(out_dir / "summary.json", {"stats": stats, "warnings": ex["warnings"]})
        entry = mf.ensure_pdf(m, slug, source=pdf["source"], title=pdf["title"], pages=pdf["pages"],
                              sha1=sha1_file(pdf["source"]))
        old = {c["id"]: c for c in entry.get("chapters", [])}
        entry["chapters"] = [{"id": c["id"], "title": c["title"], "start_page": c["start_page"],
                              "end_page": c["end_page"],
                              **({k: old[c["id"]][k] for k in ("page_id", "url") if k in old.get(c["id"], {})})}
                             for c in pdf["chapters"]]
        report.append({"title": pdf["title"], "slug": slug, "images_saved": len(ex["images"]), **stats,
                       "warnings": ex["warnings"]})
    mf.save(proj, m)
    mf.mark(proj, "extract")
    emit({"extracted": report})


# ---------------------------------------------------------------- uploads, convert
def cmd_uploads(args):
    proj = _proj(args)
    if args.op == "prepare":
        res = up_mod.prepare(proj, _style(proj), mf.load(proj))
        emit(res)
    elif args.op == "send":
        headers = _json_arg(args.headers) if args.headers else {}
        resp = up_mod.send(args.url, headers, Path(args.file), args.filename)
        emit(resp)
    elif args.op == "record":
        resp = _json_arg(args.response)
        emit(up_mod.record(proj, args.slug, args.id, resp, args.file_upload_id))
    elif args.op == "done":
        mf.mark(proj, "uploads")
        emit({"marked": "uploads"})
    else:
        raise SystemExit("uploads ops: prepare | send | record | done")


def cmd_convert(args):
    proj = _proj(args)
    res = notion_md.convert_project(proj, _style(proj), mf.load(proj), allow_pending=args.allow_pending)
    if res["pending_images"] and not args.allow_pending:
        raise SystemExit("images not uploaded yet: " + ", ".join(res["pending_images"][:10]) +
                         (" ..." if len(res["pending_images"]) > 10 else "") +
                         "  (run uploads prepare/send/record first, or pass --allow-pending for a dry run)")
    emit({"pages": [{k: v for k, v in p.items() if k in ("slug", "kind", "chapter_id", "title", "icon", "files",
                                                          "chars", "counts")} for p in res["pages"]],
          "toc_token": notion_md.TOC_TOKEN})


# ---------------------------------------------------------------- navigation, toc
def cmd_nav(args):
    proj = _proj(args)
    s, m = _style(proj), mf.load(proj)
    if args.op == "build":
        emit(nav_mod.nav_plan(proj, s, m))
    elif args.op == "find":
        md = Path(args.file).read_text(encoding="utf-8")
        emit(nav_mod.find_footers(md))
    elif args.op == "done":
        mf.mark(proj, "nav")
        emit({"marked": "nav"})
    else:
        raise SystemExit("nav ops: build | find | done")


def cmd_toc(args):
    proj = _proj(args)
    s, m = _style(proj), mf.load(proj)
    if args.op == "build":
        emit({"tocs": nav_mod.toc_plan(proj, s, m), "token": notion_md.TOC_TOKEN})
    elif args.op == "find":
        md = Path(args.file).read_text(encoding="utf-8")
        emit({"existing": nav_mod.find_toc(md, s["labels"]["contents"])})
    else:
        raise SystemExit("toc ops: build | find")


# ---------------------------------------------------------------- manifest, verify, status
def cmd_manifest(args):
    proj = _proj(args)
    op = args.op
    if op == "status":
        emit(mf.status(proj))
    elif op == "mark":
        emit(mf.mark(proj, args.a, args.b))
    elif op == "record-page":
        emit(mf.record_page(proj, args.a, None if args.b in (None, "-", "") else args.b, args.page_id, args.url))
    elif op == "show":
        emit(mf.load(proj))
    else:
        raise SystemExit("manifest ops: status | mark STEP [NOTE] | record-page SLUG CHAPTER|- --page-id ID [--url U] | show")


def cmd_verify(args):
    proj = _proj(args)
    props = _json_arg(args.props) if args.props else None
    rep = verify_mod.verify(proj, _style(proj), mf.load(proj), Path(args.fetched), props)
    mf.mark(proj, "verify")
    emit({"pages_checked": rep["pages_checked"], "pages_with_problems": rep["pages_with_problems"],
          "report": str(proj.build / "verify.md"), "rows": [r for r in rep["rows"] if r["status"] != "ok"]})


def cmd_status(args):
    emit(mf.status(_proj(args)))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="pdfnotion", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--work", help="working folder (default $PDF_TO_NOTION_WORK or ./pdf-to-notion-work)")
    ap.add_argument("--project", default="default")
    ap.add_argument("--language", default="en", help="label language for split titles (en, hu)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor").set_defaults(fn=cmd_doctor)

    p = sub.add_parser("inspect")
    p.add_argument("paths", nargs="+")
    p.add_argument("--recursive", action="store_true")
    p.add_argument("--split-pages", type=int)
    p.add_argument("--split-words", type=int)
    p.add_argument("--range-pages", type=int)
    p.add_argument("--min-image-px", type=int)
    p.set_defaults(fn=cmd_inspect)

    sub.add_parser("tree").set_defaults(fn=cmd_tree)

    p = sub.add_parser("plan")
    p.add_argument("op", choices=["split-off", "ranges", "rename", "merge", "split-on"])
    p.add_argument("slug")
    p.add_argument("rest", nargs="*")
    p.set_defaults(fn=cmd_plan)

    p = sub.add_parser("dest")
    p.add_argument("op", choices=["parse", "map", "set", "props"])
    p.add_argument("value", help="URL/id, or JSON / @file.json")
    p.set_defaults(fn=cmd_dest)

    p = sub.add_parser("classify")
    p.add_argument("--existing", help='JSON {"types": [...], "tags": [...]} from the database, or @file')
    p.set_defaults(fn=cmd_classify)

    p = sub.add_parser("record")
    p.add_argument("value", help='JSON {"<slug>": {"type": "...", "tags": [...]}} or @file')
    p.set_defaults(fn=cmd_record)

    p = sub.add_parser("style")
    p.add_argument("op")
    p.add_argument("key", nargs="?")
    p.add_argument("value", nargs="?")
    p.add_argument("--preset", default="readable")
    p.add_argument("--lang", help="label language for the style (en, hu, or any code: labels then need translation)")
    p.add_argument("--answers", help="JSON or @file with overrides")
    p.set_defaults(fn=cmd_style)

    p = sub.add_parser("extract")
    p.add_argument("--ocr-lang", help="tesseract languages for scanned PDFs, e.g. hun+eng")
    p.set_defaults(fn=cmd_extract)

    p = sub.add_parser("uploads")
    p.add_argument("op", choices=["prepare", "send", "record", "done"])
    p.add_argument("--url")
    p.add_argument("--headers", help="JSON of upload_headers from notion-create-file-upload")
    p.add_argument("--file")
    p.add_argument("--filename")
    p.add_argument("--slug")
    p.add_argument("--id")
    p.add_argument("--response", help="JSON from the upload POST")
    p.add_argument("--file-upload-id", dest="file_upload_id")
    p.set_defaults(fn=cmd_uploads)

    p = sub.add_parser("convert")
    p.add_argument("--allow-pending", action="store_true")
    p.set_defaults(fn=cmd_convert)

    p = sub.add_parser("nav")
    p.add_argument("op", choices=["build", "find", "done"])
    p.add_argument("--file")
    p.set_defaults(fn=cmd_nav)

    p = sub.add_parser("toc")
    p.add_argument("op", choices=["build", "find"])
    p.add_argument("--file")
    p.set_defaults(fn=cmd_toc)

    p = sub.add_parser("manifest")
    p.add_argument("op")
    p.add_argument("a", nargs="?")
    p.add_argument("b", nargs="?")
    p.add_argument("--page-id")
    p.add_argument("--url")
    p.set_defaults(fn=cmd_manifest)

    p = sub.add_parser("verify")
    p.add_argument("--fetched", required=True, help="folder with <page_id>.md for every created page")
    p.add_argument("--props", help="JSON {page_id: {type, tags}} of fetched properties")
    p.set_defaults(fn=cmd_verify)

    sub.add_parser("status").set_defaults(fn=cmd_status)

    args = ap.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
