"""Local PDF analysis: text, headings, lists, tables, images and figures as a block model.

The block model is style-independent. Style decisions (heading levels, callouts, toggles,
colours, ...) are applied later by notion_md.py, so restyling never needs a re-read of the PDF.

Blocks (all carry "page"):
  {"t": "title",   "text"}
  {"t": "heading", "level": 1..4, "text"}
  {"t": "para",    "text", "callout": optional type}
  {"t": "li",      "ordered": bool, "depth": int, "text"}
  {"t": "code",    "text"}
  {"t": "quote",   "text"}
  {"t": "table",   "rows": [[str]]}
  {"t": "image",   "id", "file", "w", "h", "caption", "label"}
  {"t": "footnote", "n", "text"}
"""
from __future__ import annotations

import contextlib
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

try:
    import pymupdf
except ImportError:  # older installs
    import fitz as pymupdf  # type: ignore

from common import esc, sha1_bytes, word_count

MONO_HINTS = ("mono", "courier", "consolas", "menlo", "code", "typewriter", "lucida console")
BULLET_RE = re.compile(r"^\s*([•●▪◦‣∙·–—\-\*])\s+(?=\S)")
NUM_RE = re.compile(r"^\s*(\d{1,3}|[a-zA-Z])[.)]\s+(?=\S)")
CALLOUT_WORDS = {
    "note": "note", "megjegyzés": "note", "megjegyzes": "note",
    "warning": "warning", "caution": "warning", "danger": "warning", "figyelem": "warning",
    "figyelmeztetés": "warning", "vigyázat": "warning",
    "tip": "tip", "hint": "tip", "tipp": "tip", "ötlet": "tip",
    "important": "important", "fontos": "important",
    "example": "example", "példa": "example", "pelda": "example",
}
CALLOUT_RE = re.compile(r"^\s*(" + "|".join(sorted(CALLOUT_WORDS, key=len, reverse=True)) + r")\s*[:.\-–—]\s*(.+)$",
                        re.IGNORECASE | re.DOTALL)
CAPTION_RE = re.compile(r"^\s*((?:figure|fig\.?|ábra|abra|kép|chart|diagram)\s*\d+[.\d]*)\s*[:.\-–—]?\s*(.*)$",
                        re.IGNORECASE | re.DOTALL)
SUPERSCRIPT = str.maketrans("0123456789+-=()n", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿ")


@contextlib.contextmanager
def _quiet():
    """PyMuPDF sometimes prints hints to stdout; the engine's stdout is reserved for JSON."""
    with contextlib.redirect_stdout(sys.stderr):
        yield


def norm_key(text: str) -> str:
    return re.sub(r"[^0-9a-zà-ž]+", "", text.lower())


# ---------------------------------------------------------------- spans -> inline markdown
TRUST_FONTS = True  # OCR text layers carry a fixed fake font, so style cues are ignored for them


def _span_fmt(sp: dict) -> tuple:
    if not TRUST_FONTS:
        return (False, False, False, False)
    flags, font = sp.get("flags", 0), sp.get("font", "").lower()
    bold = bool(flags & 16) or any(k in font for k in ("bold", "black", "heavy", "semibold", "demi"))
    italic = bool(flags & 2) or "italic" in font or "oblique" in font
    mono = bool(flags & 8) or any(k in font for k in MONO_HINTS)
    sup = bool(flags & 1)
    return (bold, italic, mono, sup)


def _render_runs(runs: list[tuple[str, tuple]], allow_bold: bool = True) -> str:
    merged: list[list] = []
    for text, fmt in runs:
        if merged and merged[-1][1] == fmt:
            merged[-1][0] += text
        else:
            merged.append([text, fmt])
    out = []
    for text, (bold, italic, mono, sup) in merged:
        if not text:
            continue
        lead = text[: len(text) - len(text.lstrip())]
        trail = text[len(text.rstrip()):]
        core = text.strip()
        if not core:
            out.append(text)
            continue
        if sup and re.fullmatch(r"[0-9+\-=()n]+", core):
            piece = core.translate(SUPERSCRIPT)
        elif mono:
            piece = "`" + core.replace("`", "'") + "`"
        else:
            piece = esc(core)
            if bold and allow_bold:
                piece = f"**{piece}**"
            if italic:
                piece = f"*{piece}*"
        out.append(lead + piece + trail)
    return re.sub(r"[ \t]{2,}", " ", "".join(out)).strip()


def _block_runs(block: dict, skip_lines: set[int] | None = None) -> tuple[list[tuple[str, tuple]], str]:
    """Runs with de-hyphenated line joins, plus the plain text."""
    runs: list[tuple[str, tuple]] = []
    first = True
    for li, line in enumerate(block.get("lines", [])):
        if skip_lines and li in skip_lines:
            continue
        line_runs = [(sp["text"], _span_fmt(sp)) for sp in line["spans"] if sp.get("text")]
        if not line_runs:
            continue
        if not first and runs:
            last_text, last_fmt = runs[-1]
            nxt = line_runs[0][0].lstrip()
            stripped = last_text.rstrip()
            if (stripped.endswith("-") and len(stripped) > 1 and stripped[-2].isalpha()
                    and nxt[:1].islower()):
                runs[-1] = (stripped[:-1], last_fmt)
                line_runs[0] = (nxt, line_runs[0][1])
            else:
                runs[-1] = (last_text.rstrip() + " ", last_fmt)
                line_runs[0] = (line_runs[0][0].lstrip(), line_runs[0][1])
        runs.extend(line_runs)
        first = False
    plain = re.sub(r"\s+", " ", "".join(t for t, _ in runs)).strip()
    return runs, plain


def _dominant_size(block: dict) -> float:
    c: Counter = Counter()
    for line in block.get("lines", []):
        for sp in line["spans"]:
            c[round(sp["size"] * 2) / 2] += len(sp["text"].strip())
    return c.most_common(1)[0][0] if c else 0.0


def _bold_fraction(block: dict) -> float:
    tot = bold = 0
    for line in block.get("lines", []):
        for sp in line["spans"]:
            n = len(sp["text"].strip())
            tot += n
            if _span_fmt(sp)[0]:
                bold += n
    return bold / tot if tot else 0.0


def _all_mono(block: dict) -> bool:
    seen = False
    for line in block.get("lines", []):
        for sp in line["spans"]:
            if sp["text"].strip():
                seen = True
                if not _span_fmt(sp)[2]:
                    return False
    return seen


def _italic_fraction(block: dict) -> float:
    tot = it = 0
    for line in block.get("lines", []):
        for sp in line["spans"]:
            n = len(sp["text"].strip())
            tot += n
            if _span_fmt(sp)[1]:
                it += n
    return it / tot if tot else 0.0


# ---------------------------------------------------------------- document statistics
def _page_dict(page, ocr_lang: str | None = None) -> dict:
    flags = pymupdf.TEXT_MEDIABOX_CLIP | pymupdf.TEXT_PRESERVE_WHITESPACE
    if ocr_lang and len(page.get_text().strip()) < 25:
        try:
            tp = page.get_textpage_ocr(flags=flags, language=ocr_lang, dpi=300, full=True)
            return page.get_text("dict", flags=flags, textpage=tp)
        except Exception:
            pass
    return page.get_text("dict", flags=flags)


def _lines(pd: dict):
    for b in pd.get("blocks", []):
        if b.get("type") == 0:
            for ln in b["lines"]:
                text = "".join(sp["text"] for sp in ln["spans"]).strip()
                if text:
                    yield b, ln, text


def body_size_of(pages: list[dict]) -> float:
    c: Counter = Counter()
    for pd in pages:
        for b in pd.get("blocks", []):
            if b.get("type") != 0:
                continue
            for ln in b["lines"]:
                for sp in ln["spans"]:
                    c[round(sp["size"] * 2) / 2] += len(sp["text"].strip())
    return c.most_common(1)[0][0] if c else 10.0


def repeated_margin_keys(pages: list[dict], heights: list[float]) -> set[str]:
    n = len(pages)
    seen: dict[str, set[int]] = defaultdict(set)
    for i, (pd, h) in enumerate(zip(pages, heights)):
        for b, ln, text in _lines(pd):
            y0, y1 = ln["bbox"][1], ln["bbox"][3]
            if y1 < h * 0.09 or y0 > h * 0.91:
                seen[re.sub(r"\d+", "#", text.lower())].add(i)
    need = max(3, int(0.4 * n)) if n >= 4 else 10 ** 9
    return {k for k, pgs in seen.items() if len(pgs) >= need}


def is_page_number(text: str) -> bool:
    t = text.strip().lower()
    return bool(re.fullmatch(r"(page|oldal|p\.?)?\s*\d{1,4}(\s*(/|of|from)\s*\d{1,4})?", t))


def detect_heading_sizes(pages: list[dict], body: float) -> tuple[list[float], float | None]:
    """Heading font sizes sorted large->small, plus the document-title size if it occurs once."""
    cnt: Counter = Counter()
    for pd in pages:
        for b in pd.get("blocks", []):
            if b.get("type") != 0 or len(b["lines"]) > 2:
                continue
            size = _dominant_size(b)
            text = " ".join("".join(sp["text"] for sp in ln["spans"]) for ln in b["lines"]).strip()
            if size >= body * 1.12 and 0 < len(text) <= 160 and not text.endswith((".", ",", ";")):
                cnt[size] += 1
    sizes = sorted(cnt, reverse=True)
    title_size = None
    if len(sizes) >= 2 and cnt[sizes[0]] == 1:
        title_size = sizes[0]
        sizes = sizes[1:]
    return sizes[:4], title_size


# ---------------------------------------------------------------- images
def _save_image(doc, xref: int, dest_base: Path) -> tuple[Path, int, int] | None:
    try:
        info = doc.extract_image(xref)
    except Exception:
        return None
    if not info:
        return None
    w, h = info.get("width", 0), info.get("height", 0)
    ext, smask, cs = info.get("ext", "png"), info.get("smask", 0), info.get("colorspace", 3)
    try:
        if not smask and ext in ("png", "jpeg", "jpg") and cs in (1, 3):
            out = dest_base.with_suffix(".jpg" if ext in ("jpeg", "jpg") else ".png")
            out.write_bytes(info["image"])
            return out, w, h
        pix = pymupdf.Pixmap(doc, xref)
        if pix.colorspace is not None and pix.colorspace.n not in (1, 3):
            pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
        if smask:
            pix = pymupdf.Pixmap(pix, pymupdf.Pixmap(doc, smask))
        out = dest_base.with_suffix(".png")
        pix.save(str(out))
        return out, pix.width, pix.height
    except Exception:
        return None


# ---------------------------------------------------------------- main extraction
def extract_document(doc, slug: str, *, min_image_px: int = 64, images_dir: Path | None = None,
                     ocr_lang: str | None = None) -> dict:
    global TRUST_FONTS
    TRUST_FONTS = not ocr_lang
    try:
        return _extract_document(doc, slug, min_image_px, images_dir, ocr_lang)
    finally:
        TRUST_FONTS = True


def _extract_document(doc, slug: str, min_image_px: int, images_dir: Path | None, ocr_lang: str | None) -> dict:
    npages = doc.page_count
    page_objs = [doc[i] for i in range(npages)]
    page_dicts = [_page_dict(p, ocr_lang) for p in page_objs]
    heights = [p.rect.height for p in page_objs]
    body = body_size_of(page_dicts)
    margin_keys = repeated_margin_keys(page_dicts, heights)
    head_sizes, title_size = detect_heading_sizes(page_dicts, body)

    # outline-driven headings when the PDF has a usable outline
    toc = [t for t in doc.get_toc(simple=True) if t[1].strip()]
    toc_map: dict[str, list[tuple[int, int]]] = defaultdict(list)
    for lvl, title, pg in toc:
        toc_map[norm_key(title)].append((min(lvl, 4), pg))

    # decorative images: same xref on many pages (logos, watermarks)
    xref_pages: dict[int, set[int]] = defaultdict(set)
    for i, p in enumerate(page_objs):
        for im in p.get_images(full=True):
            xref_pages[im[0]].add(i)
    decorative = {x for x, pgs in xref_pages.items() if len(pgs) >= 3 and len(pgs) >= 0.2 * npages}

    outline_hits = 0
    pages_out: list[dict] = []
    images_out: list[dict] = []
    bold_candidates = 0
    saved_by_xref: dict[int, dict] = {}
    fig_counter = 0

    for pi, (page, pd) in enumerate(zip(page_objs, page_dicts)):
        pw, ph = page.rect.width, page.rect.height
        items: list[dict] = []

        # tables
        table_boxes: list[pymupdf.Rect] = []
        try:
            with _quiet():
                tabs = page.find_tables().tables
        except Exception:
            tabs = []
        for tab in tabs:
            try:
                rows = [[(c or "").replace("\n", " ").strip() for c in r] for r in tab.extract()]
            except Exception:
                continue
            rows = [r for r in rows if any(c for c in r)]
            if len(rows) < 2 or max((len(r) for r in rows), default=0) < 2:
                continue
            rect = pymupdf.Rect(tab.bbox)
            table_boxes.append(rect)
            items.append({"bbox": tuple(rect), "block": {"t": "table", "rows": rows}})

        # embedded images
        scanned_page = False
        text_chars = sum(len(t) for _, _, t in _lines(pd))
        for im in page.get_images(full=True):
            xref = im[0]
            if xref in decorative:
                continue
            try:
                rects = page.get_image_rects(xref)
            except Exception:
                rects = []
            for r in rects:
                if r.width < 24 or r.height < 24:
                    continue
                if (r.width * r.height) > 0.8 * pw * ph and text_chars < 25 + 0:
                    scanned_page = True
                    continue
                if (r.width * r.height) > 0.85 * pw * ph and ocr_lang:
                    continue
                if xref not in saved_by_xref:
                    if images_dir is None:
                        info = None
                        try:
                            ei = doc.extract_image(xref)
                            info = (ei["width"], ei["height"]) if ei else None
                        except Exception:
                            info = None
                        if not info or min(info) < min_image_px:
                            saved_by_xref[xref] = {"skip": True}
                            continue
                        saved_by_xref[xref] = {"id": f"{slug}-p{pi + 1:03d}-{len(saved_by_xref) + 1:02d}",
                                               "file": None, "w": info[0], "h": info[1], "bytes": 0, "sha1": None}
                    else:
                        iid = f"{slug}-p{pi + 1:03d}-{len(saved_by_xref) + 1:02d}"
                        res = _save_image(doc, xref, images_dir / iid)
                        if res is None or min(res[1], res[2]) < min_image_px:
                            if res is not None:
                                res[0].unlink(missing_ok=True)
                            saved_by_xref[xref] = {"skip": True}
                            continue
                        data = res[0].read_bytes()
                        saved_by_xref[xref] = {"id": iid, "file": str(res[0]), "w": res[1], "h": res[2],
                                               "bytes": len(data), "sha1": sha1_bytes(data)}
                        images_out.append(saved_by_xref[xref])
                rec = saved_by_xref[xref]
                if rec.get("skip"):
                    continue
                if images_dir is None and rec not in images_out:
                    images_out.append(rec)
                items.append({"bbox": tuple(r), "block": {
                    "t": "image", "id": rec["id"], "file": rec["file"], "w": rec["w"], "h": rec["h"],
                    "caption": None, "label": None}})

        # vector figures (charts drawn with paths have no embedded image)
        fig_rects: list[pymupdf.Rect] = []
        try:
            with _quiet():
                drawings = page.get_drawings()
        except Exception:
            drawings = []
        figure_paths = []
        for d in drawings:
            r = d.get("rect")
            if r is None or r.is_empty:
                continue
            if r.width * r.height > 0.9 * pw * ph or (r.width < 1.5 and r.height < 1.5):
                continue
            if any(tb.contains(r) or tb.intersects(r) and (tb & r).get_area() > 0.6 * r.get_area()
                   for tb in table_boxes):
                continue
            if r.height < 1.5 or r.width < 1.5:  # rules and underlines
                continue
            figure_paths.append(r)
        if len(figure_paths) >= 6:
            u = pymupdf.Rect(figure_paths[0])
            for r in figure_paths[1:]:
                u |= r
            u = pymupdf.Rect(u.x0 - 4, u.y0 - 4, u.x1 + 4, u.y1 + 4) & page.rect
            inside_words = 0
            for b in pd.get("blocks", []):
                if b.get("type") == 0 and (pymupdf.Rect(b["bbox"]) & u).get_area() > 0.6 * pymupdf.Rect(b["bbox"]).get_area():
                    inside_words += sum(len(sp["text"].split()) for ln in b["lines"] for sp in ln["spans"])
            # a region full of running text is a designed layout, not a chart: keep it as text
            if inside_words <= 80 and 0.02 * pw * ph <= u.get_area() <= 0.92 * pw * ph and u.width >= 60 and u.height >= 60:
                fig_counter += 1
                iid = f"{slug}-p{pi + 1:03d}-v{fig_counter:02d}"
                rec = {"id": iid, "file": None, "w": int(u.width * 200 / 72), "h": int(u.height * 200 / 72),
                       "bytes": 0, "sha1": None}
                if images_dir is not None:
                    out = images_dir / f"{iid}.png"
                    page.get_pixmap(clip=u, dpi=200).save(str(out))
                    data = out.read_bytes()
                    rec.update({"file": str(out), "bytes": len(data), "sha1": sha1_bytes(data)})
                images_out.append(rec)
                fig_rects.append(u)
                items.append({"bbox": tuple(u), "block": {
                    "t": "image", "id": iid, "file": rec["file"], "w": rec["w"], "h": rec["h"],
                    "caption": None, "label": None, "vector": True}})

        # text blocks
        text_items: list[dict] = []
        for b in pd.get("blocks", []):
            if b.get("type") != 0:
                continue
            bb = pymupdf.Rect(b["bbox"])
            if any(((tb & bb).get_area() > 0.6 * bb.get_area()) for tb in table_boxes if tb.intersects(bb)):
                continue
            if any(((fr & bb).get_area() > 0.6 * bb.get_area()) for fr in fig_rects if fr.intersects(bb)):
                continue
            skip: set[int] = set()
            for li, ln in enumerate(b["lines"]):
                text = "".join(sp["text"] for sp in ln["spans"]).strip()
                key = re.sub(r"\d+", "#", text.lower())
                y0, y1 = ln["bbox"][1], ln["bbox"][3]
                in_margin = y1 < ph * 0.09 or y0 > ph * 0.91
                if not text or (in_margin and (key in margin_keys or is_page_number(text))):
                    skip.add(li)
            if len(skip) == len(b["lines"]):
                continue
            text_items.append({"bbox": tuple(bb), "raw": b, "skip": skip})

        # reading order (two-column pages, full-width separators)
        all_items = items + text_items
        if not all_items:
            pages_out.append({"page": pi + 1, "blocks": [], "scanned": scanned_page})
            continue
        mid = pw / 2
        tx = [it for it in text_items if it["bbox"][2] - it["bbox"][0] < 0.6 * pw]
        left = [it for it in tx if it["bbox"][2] <= mid + 6]
        right = [it for it in tx if it["bbox"][0] >= mid - 6]
        two_col = len(left) >= 3 and len(right) >= 3 and (len(left) + len(right)) >= 0.7 * max(1, len(text_items))
        if two_col:
            # the right column's vertical extent defines the "columns" region; anything above or below it
            # (title, intro, footer notes) is read in plain top-to-bottom order
            y_top = min(it["bbox"][1] for it in right)
            y_bot = max(it["bbox"][3] for it in right)
            wide = [it for it in all_items if it["bbox"][2] - it["bbox"][0] >= 0.6 * pw
                    and it["bbox"][1] >= y_top - 2 and it["bbox"][3] <= y_bot + 2]
            for it in all_items:
                x0, y0, x1, y1 = it["bbox"]
                if y1 <= y_top + 2:
                    it["key"] = (0, 0, 0, y0, x0)
                elif y0 >= y_bot - 2:
                    it["key"] = (2, 0, 0, y0, x0)
                elif it in wide:
                    above = sum(1 for f in wide if f is not it and f["bbox"][3] <= y0 + 2)
                    it["key"] = (1, above, 2, y0, x0)
                else:
                    above = sum(1 for f in wide if f["bbox"][3] <= y0 + 2)
                    it["key"] = (1, above, 0 if (x0 + x1) / 2 < mid else 1, y0, x0)
            all_items.sort(key=lambda it: it["key"])
        else:
            all_items.sort(key=lambda it: (round(it["bbox"][1] / 3), it["bbox"][0]))

        # raw text blocks -> merged paragraphs
        seq: list[dict] = []
        for it in all_items:
            if "block" in it:
                seq.append(it)
                continue
            raw = it["raw"]
            if seq and "raw" in seq[-1]:
                prev = seq[-1]
                pb, cb = prev["raw"], raw
                gap = it["bbox"][1] - prev["bbox"][3]
                sz = _dominant_size(cb)
                if (abs(_dominant_size(pb) - sz) < 0.3 and 0 <= gap <= 0.45 * sz and abs(prev["bbox"][0] - it["bbox"][0]) < 2.5
                        and not prev["skip"] and not it["skip"] and not BULLET_RE.match("".join(s["text"] for s in cb["lines"][0]["spans"]))
                        and not NUM_RE.match("".join(s["text"] for s in cb["lines"][0]["spans"]))
                        and not _all_mono(cb) and sz < body * 1.12):
                    pb = {"lines": pb["lines"] + cb["lines"], "bbox": tuple(pymupdf.Rect(prev["bbox"]) | pymupdf.Rect(it["bbox"]))}
                    prev["raw"] = pb
                    prev["bbox"] = pb["bbox"]
                    continue
            seq.append(dict(it))

        blocks: list[dict] = []
        list_x0: float | None = None
        for it in seq:
            if "block" in it:
                blocks.append(dict(it["block"], page=pi + 1, y=it["bbox"][1]))
                continue
            b, skip = it["raw"], it.get("skip", set())
            runs, plain = _block_runs(b, skip)
            if not plain:
                continue
            size = _dominant_size(b)
            nlines = len([1 for i in range(len(b["lines"])) if i not in skip])
            y0 = it["bbox"][1]

            # footnote at the bottom of the page in small type
            if y0 > ph * 0.82 and size < body * 0.93 and re.match(r"^\d{1,3}[\s.)]", plain):
                m = re.match(r"^(\d{1,3})[\s.)]+(.*)$", plain)
                body_md = re.sub(r"^[*\\ ]*\d{1,3}[*\\]*[\s.)]+", "", _render_runs(runs), count=1)
                blocks.append({"t": "footnote", "n": int(m.group(1)), "text": body_md or m.group(2),
                               "page": pi + 1, "y": y0})
                continue

            # heading detection
            level = None
            if title_size is not None and abs(size - title_size) < 0.3 and nlines <= 3 and pi <= 1:
                blocks.append({"t": "title", "text": plain, "page": pi + 1, "y": y0})
                continue
            if toc and len(toc) >= 3:
                key = norm_key(plain)
                if len(key) >= 3:
                    for tk, entries in toc_map.items():
                        if key.startswith(tk) and len(key) <= len(tk) + 10:
                            level = entries[0][0]
                            outline_hits += 1
                            break
            else:
                if nlines <= 2 and len(plain) <= 160 and not plain.endswith((".", ",", ";")):
                    for idx, s in enumerate(head_sizes):
                        if abs(size - s) < 0.3:
                            level = idx + 1
                            break
                    if level is None and size <= body + 0.3 and _bold_fraction(b) > 0.9 and nlines == 1 \
                            and len(plain) <= 90 and not plain.endswith((":", "!", "?")):
                        level = min(len(head_sizes) + 1, 4)
                        bold_candidates += 1
            if level is not None:
                blocks.append({"t": "heading", "level": level, "text": plain, "page": pi + 1, "y": y0})
                continue

            # code
            if _all_mono(b):
                code_lines = []
                for i, ln in enumerate(b["lines"]):
                    if i in skip:
                        continue
                    code_lines.append("".join(sp["text"] for sp in ln["spans"]).rstrip())
                blocks.append({"t": "code", "text": "\n".join(code_lines), "page": pi + 1, "y": y0})
                continue

            # lists: a block whose lines start with bullets / numbers
            first_line = "".join(sp["text"] for sp in b["lines"][0]["spans"]) if b["lines"] else ""
            if BULLET_RE.match(first_line) or NUM_RE.match(first_line):
                list_blocks = _split_list_block(b, skip)
                if list_blocks:
                    base_x = min(x for x, _, _, _ in list_blocks)
                    for x, ordered, depth_runs, plain_item in list_blocks:
                        depth = min(3, max(0, int(round((x - base_x) / max(body * 1.4, 8)))))
                        blocks.append({"t": "li", "ordered": ordered, "depth": depth,
                                       "text": _render_runs(depth_runs), "page": pi + 1, "y": y0})
                    continue

            rendered = _render_runs(runs)
            # callout candidates
            m = CALLOUT_RE.match(plain)
            if m and len(plain) < 700:
                kind = CALLOUT_WORDS[m.group(1).lower()]
                body_runs = rendered
                cut = re.match(r"^\W*\**\s*" + re.escape(m.group(1)) + r"\**\s*[:.\-–—]\s*", rendered, re.IGNORECASE)
                if cut:
                    body_runs = rendered[cut.end():]
                blocks.append({"t": "para", "text": body_runs or rendered, "callout": kind, "label": m.group(1),
                               "page": pi + 1, "y": y0})
                continue

            # quotes: indented italic short paragraphs
            if _italic_fraction(b) > 0.9 and it["bbox"][0] > 40 + 12 and word_count(plain) <= 90 and nlines >= 1 \
                    and it["bbox"][0] > min(x["bbox"][0] for x in seq) + 18:
                blocks.append({"t": "quote", "text": rendered, "page": pi + 1, "y": y0})
                continue

            blocks.append({"t": "para", "text": rendered, "page": pi + 1, "y": y0})

        _attach_captions(blocks)
        pages_out.append({"page": pi + 1, "blocks": blocks, "scanned": scanned_page})

    _merge_cross_page_paragraphs(pages_out)

    outline_used = bool(toc and len(toc) >= 3 and outline_hits >= max(2, int(0.5 * len(toc))))
    warnings: list[str] = []
    if toc and len(toc) >= 3 and not outline_used:
        warnings.append("outline titles were not found in the page text; headings come from font sizes")
    scanned_pages = sum(1 for p in pages_out if p["scanned"])
    return {"pages": pages_out, "images": images_out, "body_size": body, "heading_sizes": head_sizes,
            "title_size": title_size, "outline_used": outline_used, "outline": toc,
            "scanned": scanned_pages >= max(1, npages // 2), "scanned_pages": scanned_pages,
            "warnings": warnings}


def _split_list_block(b: dict, skip: set[int]):
    items: list[list] = []  # [x0, ordered, runs]
    for li, ln in enumerate(b["lines"]):
        if li in skip:
            continue
        text = "".join(sp["text"] for sp in ln["spans"])
        mb, mn = BULLET_RE.match(text), NUM_RE.match(text)
        runs = [(sp["text"], _span_fmt(sp)) for sp in ln["spans"] if sp.get("text")]
        if mb or mn:
            marker_len = (mb or mn).end()
            cut, new_runs = marker_len, []
            for t, f in runs:
                if cut >= len(t):
                    cut -= len(t)
                    continue
                new_runs.append((t[cut:], f))
                cut = 0
            items.append([ln["bbox"][0], bool(mn and not mb), new_runs])
        elif items:
            items[-1][2] = items[-1][2] + [(" ", (False, False, False, False))] + runs
        else:
            return None
    return [(x, ordered, runs, "".join(t for t, _ in runs)) for x, ordered, runs in items]


def _attach_captions(blocks: list[dict]) -> None:
    """A paragraph right after (or before) an image that starts with Figure N: becomes its caption."""
    i = 0
    while i < len(blocks):
        blk = blocks[i]
        if blk["t"] == "image" and blk.get("caption") is None:
            for j in (i + 1, i - 1):
                if 0 <= j < len(blocks) and blocks[j]["t"] == "para" and not blocks[j].get("callout"):
                    m = CAPTION_RE.match(re.sub(r"\\([\\*~`$\[\]<>{}|^])", r"\1", blocks[j]["text"]).replace("*", ""))
                    if m:
                        blk["label"] = m.group(1).strip()
                        blk["caption"] = (m.group(2) or "").strip()
                        del blocks[j]
                        if j < i:
                            i -= 1
                        break
        i += 1


def _merge_cross_page_paragraphs(pages: list[dict]) -> None:
    for a, b in zip(pages, pages[1:]):
        if not a["blocks"] or not b["blocks"]:
            continue
        last, first = a["blocks"][-1], b["blocks"][0]
        if last["t"] == "para" and first["t"] == "para" and not last.get("callout") and not first.get("callout"):
            if not re.search(r"[.!?:;»”\")\]]$", last["text"].rstrip()) and first["text"][:1].islower():
                last["text"] = last["text"].rstrip() + " " + first["text"].lstrip()
                b["blocks"].pop(0)


def summarize(extraction: dict) -> dict:
    c: Counter = Counter()
    words = 0
    heads_by_level: Counter = Counter()
    for p in extraction["pages"]:
        for blk in p["blocks"]:
            t = blk["t"]
            c[t] += 1
            if t in ("para", "li", "heading", "quote", "code", "title"):
                words += word_count(blk.get("text", ""))
            if t == "table":
                words += sum(word_count(cell) for row in blk["rows"] for cell in row)
            if t == "heading":
                heads_by_level[blk["level"]] += 1
            if t == "para" and blk.get("callout"):
                c["callout"] += 1
    return {
        "words": words,
        "headings": c["heading"] + c["title"],
        "headings_by_level": dict(heads_by_level),
        "tables": c["table"],
        "images": c["image"],
        "list_items": c["li"],
        "code_blocks": c["code"],
        "quotes": c["quote"],
        "callout_candidates": c["callout"],
        "footnote_candidates": c["footnote"],
    }
