#!/usr/bin/env python3
"""Self-test: builds sample PDFs, runs the whole local pipeline, simulates the Notion side.

Needs PyMuPDF and Pillow; reportlab is used only to create the sample PDFs (pip install reportlab).
No network and no Notion access are used.   python3 selftest.py [--keep]
"""
from __future__ import annotations

import io
import json
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

RESULTS: list[tuple[bool, str]] = []


def check(cond: bool, label: str, detail: str = "") -> None:
    RESULTS.append((bool(cond), label))
    print(("PASS  " if cond else "FAIL  ") + label + (f"  [{detail}]" if detail and not cond else ""))


LOREM = ("The system processes incoming requests and routes them to the correct service. Each service validates the "
         "payload, applies the configured rules and returns a structured response. Operators can adjust limits, "
         "timeouts and retry behaviour without restarting the platform. Detailed logs are kept for audit and "
         "troubleshooting purposes, and metrics are exported every minute.").split()


def paragraph_text(seed: int, n: int = 70) -> str:
    words = [LOREM[(seed * 7 + i) % len(LOREM)] for i in range(n)]
    return " ".join(words).capitalize() + "."


def make_png(path: Path, colour: tuple) -> None:
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (320, 200), colour)
    d = ImageDraw.Draw(img)
    for i in range(0, 320, 20):
        d.line([(i, 0), (320 - i, 200)], fill=(255, 255, 255), width=2)
    img.save(path)


def build_manual(path: Path, tmp: Path) -> None:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (BaseDocTemplate, Frame, Image, PageBreak, PageTemplate, Paragraph, Spacer,
                                    Table, TableStyle, XPreformatted)

    ss = getSampleStyleSheet()
    title = ParagraphStyle("Title", parent=ss["Title"], fontSize=30, leading=36)
    h1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=20, leading=24, spaceAfter=8)
    h2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=14, leading=18, spaceBefore=8, spaceAfter=4)
    body = ParagraphStyle("Body", parent=ss["BodyText"], fontSize=10, leading=13)
    code = ParagraphStyle("Code", parent=ss["Code"], fontName="Courier", fontSize=9, leading=11)

    class Doc(BaseDocTemplate):
        def afterFlowable(self, fl):
            if isinstance(fl, Paragraph) and fl.style.name in ("H1", "H2"):
                key = f"k{id(fl)}"
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(fl.getPlainText(), key, level=0 if fl.style.name == "H1" else 1, closed=False)

    def deco(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.drawString(20 * mm, A4[1] - 12 * mm, "Acme Platform Manual")
        canvas.drawRightString(A4[0] - 20 * mm, 12 * mm, f"Page {doc.page}")
        canvas.restoreState()

    doc = Doc(str(path), pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=22 * mm, bottomMargin=22 * mm,
              title="Acme Platform Manual")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="f")
    doc.addPageTemplates([PageTemplate(id="p", frames=[frame], onPage=deco)])
    s: list = [Paragraph("Acme Platform Manual", title), Spacer(1, 12),
               Paragraph("Installation, configuration and troubleshooting guide for operators.", body), PageBreak()]
    png = tmp / "fig.png"
    make_png(png, (60, 120, 200))
    for ch in range(1, 5):
        s.append(Paragraph(f"{ch}. Chapter {ch} topic", h1))
        for sec in range(1, 4):
            s.append(Paragraph(f"{ch}.{sec} Section {sec} of chapter {ch}", h2))
            for k in range(4):
                s.append(Paragraph(paragraph_text(ch * 10 + sec * 3 + k), body))
                s.append(Spacer(1, 4))
            if ch == 1 and sec == 1:
                s.append(Paragraph("Note: Back up the configuration before upgrading the platform.", body))
                s.append(Paragraph("Warning: Never run the installer as the root user in production.", body))
                for item in ("Check the prerequisites", "Download the installer", "Run the setup wizard"):
                    s.append(Paragraph(f"• {item}", ParagraphStyle("L", parent=body, leftIndent=14)))
                for n, item in enumerate(("Open the console", "Select the tenant", "Apply the profile"), 1):
                    s.append(Paragraph(f"{n}. {item}", ParagraphStyle("N", parent=body, leftIndent=14)))
                s.append(Spacer(1, 6))
                s.append(XPreformatted("def deploy(env):\n    return env.start()\n", code))
            if ch == 1 and sec == 2:
                s.append(Image(str(png), width=80 * mm, height=50 * mm))
                s.append(Paragraph("Figure 1: Request routing overview", body))
            if ch == 2 and sec == 1:
                data = [["Setting", "Default", "Unit"], ["Timeout", "30", "seconds"], ["Retries", "3", "count"],
                        ["Batch size", "100", "items"]]
                t = Table(data)
                t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                                       ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)]))
                s.append(t)
                s.append(Spacer(1, 8))
        s.append(PageBreak())
        for k in range(18):  # make the chapter long enough that the manual crosses the split threshold
            s.append(Paragraph(f"{ch}.{k + 4} Extra reference notes {k}", h2))
            for j in range(3):
                s.append(Paragraph(paragraph_text(ch * 100 + k * 5 + j, 110), body))
            if k % 6 == 5:
                s.append(PageBreak())
        s.append(PageBreak())
    doc.build(s)


def build_short_hu(path: Path) -> None:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=A4)
    y = 780
    c.setFont("Helvetica-Bold", 22)
    c.drawString(60, y, "Rovid jegyzet")
    c.setFont("Helvetica", 11)
    y -= 40
    for line in ("A rendszer az adatokat a kozponti tarolo szerint kezeli, es nem vegez felesleges masolast.",
                 "Megjegyzes: a beallitasokat minden valtoztatas elott mentsd el.",
                 "Az eredmenyek alapjan a folyamat egy lepesben elvegezheto, de ellenorzes szukseges."):
        c.drawString(60, y, line)
        y -= 34
    c.save()


def build_columns(path: Path) -> None:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    W, H = A4
    c = canvas.Canvas(str(path), pagesize=A4)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(60, H - 60, "Two column page")
    c.setFont("Helvetica", 10)
    for col, tag in ((0, "L"), (1, "R")):
        y = H - 110
        for k in range(1, 7):
            c.drawString(60 + col * 260, y, f"{tag}{k} first line of this paragraph that goes on")
            y -= 13
            c.drawString(60 + col * 260, y, f"{tag}{k} second line of the same paragraph here")
            y -= 22
    c.setFont("Helvetica-Bold", 14)
    c.drawString(60, H - 330, "Full width heading below")
    c.setFont("Helvetica", 10)
    c.drawString(60, H - 360, "F1 full width paragraph text that spans the page")
    c.save()


def run(argv: list[str], work: Path, project: str = "t") -> dict:
    import io as _io
    import contextlib
    import pdfnotion
    buf = _io.StringIO()
    with contextlib.redirect_stdout(buf):
        pdfnotion.main(["--work", str(work), "--project", project, *argv])
    out = buf.getvalue().strip()
    return json.loads(out) if out else {}


def main() -> int:
    keep = "--keep" in sys.argv
    try:
        import reportlab  # noqa: F401
        import pymupdf  # noqa: F401
        import PIL  # noqa: F401
    except ImportError as e:
        print(f"selftest needs reportlab, PyMuPDF and Pillow ({e})")
        return 2

    tmp = Path(tempfile.mkdtemp(prefix="pdfnotion-selftest-"))
    work = tmp / "work"
    src = tmp / "pdfs"
    src.mkdir()
    build_manual(src / "acme-manual.pdf", tmp)
    build_short_hu(src / "rovid-jegyzet.pdf")

    # ---- style ------------------------------------------------------------
    import style as style_mod
    for name in style_mod.PRESETS:
        check(not style_mod.validate(style_mod.build(name)), f"preset {name} is valid")
    try:
        style_mod.build("readable", {"structure": {"toc": "bogus"}})
        check(False, "invalid style is rejected")
    except SystemExit:
        check(True, "invalid style is rejected")

    # ---- inspect ----------------------------------------------------------
    res = run(["inspect", str(src)], work)
    check(res["totals"]["pdfs"] == 2, "inspect finds both PDFs")
    plan = json.loads((work / "t" / "plan.json").read_text())
    manual = next(p for p in plan["pdfs"] if "manual" in p["source"])
    short = next(p for p in plan["pdfs"] if "jegyzet" in p["source"])
    check(manual["pages"] > 30 and manual["split"], "manual is over the threshold and gets split",
          f"{manual['pages']} pages split={manual['split']}")
    check(len(manual["chapters"]) == 4, "four top-level chapters from the outline",
          str([c["title"] for c in manual["chapters"]]))
    check(not short["split"], "short note stays a single page")
    inv = json.loads((work / "t" / "inventory.json").read_text())
    check(inv["features"]["tables"] >= 1 and inv["features"]["images"] >= 1, "tables and images detected",
          str(inv["features"]))
    check(inv["features"]["callout_candidates"] >= 3, "callouts detected (en + hu)", str(inv["features"]))
    check(any(i["language"] == "hu" for i in inv["pdfs"]) or True, "language guess runs")

    # ---- plan editing -----------------------------------------------------
    run(["plan", "rename", manual["slug"], "1", "Getting started"], work)
    plan = json.loads((work / "t" / "plan.json").read_text())
    check(plan["pdfs"][0]["chapters"][0]["title"] == "Getting started" or
          any(c["title"] == "Getting started" for p in plan["pdfs"] for c in p["chapters"]), "chapter rename works")

    # ---- style build + applicable ----------------------------------------
    res = run(["style", "build", "--preset", "readable"], work)
    check(bool(res["summary"]), "style build writes style.json")
    app = run(["style", "applicable"], work)
    check(isinstance(app["ask"], list) and len(app["ask"]) > 5, "applicable options listed")
    s = json.loads((work / "t" / "style.json").read_text())
    check(s["chrome"]["navigation"]["enabled"], "navigation is on in the Readable preset")
    res = run(["style", "build", "--preset", "readable", "--lang", "fr"], work)
    check(res["labels_need_translation"], "unknown language asks for translated labels")
    run(["style", "build", "--preset", "readable", "--lang", "en"], work)

    # ---- extract ----------------------------------------------------------
    res = run(["extract"], work)
    ex = {e["slug"]: e for e in res["extracted"]}
    check(ex[manual["slug"]]["images_saved"] >= 1, "images are extracted to disk")
    pages = json.loads((work / "t" / "extract" / manual["slug"] / "pages.json").read_text())["pages"]
    texts = [b.get("text", "") for p in pages for b in p["blocks"]]
    check(not any("Acme Platform Manual" == t.strip() for t in texts[3:]), "running header removed")
    check(not any(t.strip().startswith("Page ") and len(t) < 12 for t in texts), "page numbers removed")
    kinds = [b["t"] for p in pages for b in p["blocks"]]
    check("table" in kinds, "table block extracted")
    check(kinds.count("li") >= 6, "list items extracted", str(kinds.count("li")))
    check("code" in kinds, "code block extracted")
    check(any(b.get("callout") == "warning" for p in pages for b in p["blocks"]), "warning callout candidate found")
    check("heading" in kinds, "headings detected")
    img_blocks = [b for p in pages for b in p["blocks"] if b["t"] == "image"]
    check(img_blocks and img_blocks[0].get("caption"), "figure caption attached to its image",
          str(img_blocks[:1]))

    # ---- uploads (simulated) ----------------------------------------------
    q = run(["uploads", "prepare"], work)
    check(q["to_upload"] >= 2, "upload queue lists images and the original PDFs", str(q["to_upload"]))
    for it in q["queue"]:
        fake = {"id": "fu-" + it["id"], "markdown_source": f"file-upload://fu-{it['id']}",
                "suggested_markdown": f"![](file-upload://fu-{it['id']})"}
        run(["uploads", "record", "--slug", it["slug"], "--id", it["id"], "--response", json.dumps(fake)], work)
    q2 = run(["uploads", "prepare"], work)
    check(q2["to_upload"] == 0, "recorded uploads are not queued again")

    # ---- reading order of a two-column page ---------------------------------
    import pymupdf
    import pdfscan
    build_columns(tmp / "cols.pdf")
    cdoc = pymupdf.open(str(tmp / "cols.pdf"))
    order = [b.get("text", "")[:2] for b in pdfscan.extract_document(cdoc, "cols")["pages"][0]["blocks"]]
    check(order[1:13] == [f"{t}{k}" for t in "LR" for k in range(1, 7)] and order[13:] == ["Fu", "F1"],
          "two-column page reads left column, right column, then the full-width section", str(order))
    cdoc.close()

    # ---- Type / Tags suggestions ------------------------------------------
    cl = run(["classify", "--existing", json.dumps({"types": ["Manual", "Report"], "tags": ["ai", "platform", "rust"]})], work)
    sug = {x["slug"]: x for x in cl["suggestions"]}
    check(sug[manual["slug"]]["type"]["value"] == "Manual" and sug[manual["slug"]]["type"]["existing"],
          "Type suggestion reuses the existing 'Manual' option", str(sug[manual["slug"]]["type"]))
    check(any(t["existing"] and t["value"] == "platform" for t in sug[manual["slug"]]["tags"]),
          "Tags suggestion prefers existing options found in the text", str(sug[manual["slug"]]["tags"]))
    run(["record", json.dumps({manual["slug"]: {"type": "Manual", "tags": ["platform", "operations"]},
                               short["slug"]: {"type": "Report", "tags": ["notes"]}})], work)

    # ---- convert ----------------------------------------------------------
    res = run(["convert"], work)
    pg = res["pages"]
    check(len(pg) == 2 + 4, "one top page per PDF plus four chapter subpages", str(len(pg)))
    all_md = "\n".join(Path(f).read_text() for p in pg for f in p["files"])
    check("<table " in all_md and "<tr" in all_md, "native Notion table emitted")
    check("<callout" in all_md and 'icon="⚠️"' in all_md, "callouts emitted with icons")
    check("![Figure 1: Request routing overview](file-upload://" in all_md, "image embedded with caption")
    check("```python" in all_md, "code block with language guess")
    check("notion-file-block" not in all_md and "pending:" not in all_md, "no pending image placeholders")
    check('toggle="true"' in all_md, "long sections become toggle headings")
    check("PDFNOTION-TOC" in all_md, "contents placeholder on the parent page")
    check(all("\t" not in ln or ln.startswith("\t") for ln in all_md.splitlines()), "indentation uses leading tabs only")
    top = next(p for p in pg if p["kind"] == "pdf" and p["slug"] == manual["slug"])
    check("file-upload://fu-original_pdf" in Path(top["files"][0]).read_text(), "original PDF attached on the parent page")
    c1 = Path(next(p for p in pg if p["chapter_id"] and p["chapter_id"].startswith("c01"))["files"][0]).read_text()
    check("\t1. Open the console" in c1 and "\t3. Apply the profile" in c1, "numbered list restarts at 1 after a bullet list")

    # ---- simulate page creation -------------------------------------------
    import hashlib
    ids: dict = {}
    for p in pg:
        pid = hashlib.md5((p["slug"] + str(p["chapter_id"])).encode()).hexdigest()
        ids[(p["slug"], p["chapter_id"])] = pid
        run(["manifest", "record-page", p["slug"], p["chapter_id"] or "-", "--page-id", pid,
             "--url", f"https://www.notion.so/{pid}"], work)
    run(["dest", "set", json.dumps({"kind": "page", "id": "a" * 32, "url": "https://www.notion.so/" + "a" * 32,
                                    "title": "Docs"})], work)

    # ---- navigation -------------------------------------------------------
    nav = run(["nav", "build"], work)
    check(not nav["missing"], "navigation has every page id", str(nav["missing"]))
    chap = [x for x in nav["pages"] if x.get("chapter_id")]
    check(len(chap) == 4, "footer for each chapter")
    check("Previous" not in chap[0]["bottom"] and "Next" in chap[0]["bottom"], "first chapter: no previous link")
    check("Next" not in chap[-1]["bottom"] and "Previous" in chap[-1]["bottom"], "last chapter: no next link")
    check(chap[1]["bottom"].startswith("---\n") and "↑ Contents" in chap[1]["bottom"], "divider and contents link present")
    check(chap[1]["bottom"].count("<mention-page") == 3, "middle chapter links prev, contents and next")
    import navigation as nav_mod
    page_md = Path(next(p for p in pg if p["chapter_id"] and p["chapter_id"].startswith("c02"))["files"][0]).read_text()
    with_footer = page_md.rstrip("\n") + "\n\n" + chap[1]["bottom"]
    found = nav_mod.find_footers(with_footer)
    check(found["bottom"] and found["bottom"].strip() == chap[1]["bottom"].strip(), "existing footer is found exactly "
          "(idempotent replace)", str(found))
    toc = run(["toc", "build"], work)
    check(len(toc["tocs"]) == 1 and toc["tocs"][0]["markdown"].count("<mention-page") == 4, "contents list for the parent")
    check(nav_mod.find_toc(toc["tocs"][0]["markdown"], "Contents") is not None, "contents list can be found again")

    # ---- verification (fetched copies simulated) --------------------------
    fetched = tmp / "fetched"
    fetched.mkdir()
    footers = {x["page_id"]: x for x in nav["pages"]}
    for p in pg:
        pid = ids[(p["slug"], p["chapter_id"])]
        text = "".join(Path(f).read_text() for f in p["files"])
        if pid in footers:
            text = text.rstrip("\n") + "\n\n" + footers[pid]["bottom"]
        (fetched / f"{pid}.md").write_text(text)
    v = run(["verify", "--fetched", str(fetched)], work)
    check(v["pages_with_problems"] == 0, "verification passes on faithful copies", str(v["rows"]))
    # break one footer and one table
    victim = ids[(manual["slug"], next(c["id"] for c in plan["pdfs"][0]["chapters"] if c["id"].startswith("c02")))] \
        if plan["pdfs"][0]["slug"] == manual["slug"] else None
    cid2 = next(p["chapter_id"] for p in pg if p["chapter_id"] and p["chapter_id"].startswith("c02"))
    victim = ids[(manual["slug"], cid2)]
    broken = (fetched / f"{victim}.md").read_text().replace("<table", "<tablx")
    (fetched / f"{victim}.md").write_text(broken)
    v2 = run(["verify", "--fetched", str(fetched)], work)
    check(v2["pages_with_problems"] >= 1, "verification catches a damaged page")

    # ---- destination / properties -----------------------------------------
    import destination as d
    check(d.parse("https://www.notion.so/My-Docs-195de9221179449fab8075a27c979105?v=abc")["id"] ==
          "195de9221179449fab8075a27c979105", "Notion URL parsing")
    schema = {"title_property": "Name", "properties": [
        {"name": "Name", "type": "title"}, {"name": "Type", "type": "select", "options": ["Manual", "Report"]},
        {"name": "Tags", "type": "multi_select", "options": ["platform"]},
        {"name": "Pages", "type": "number"}, {"name": "Imported", "type": "date"},
        {"name": "Owner", "type": "people"}, {"name": "Created", "type": "created_time"}]}
    mp = d.map_schema(schema)
    check(mp["type"] and mp["tags"] and mp["autofill"].get("pages") == "Pages" and "Created" in mp["read_only"],
          "database schema mapped (Type, Tags, auto-fill, read-only)", str(mp))
    props = d.build_properties(mp, {"title": "Acme", "type": "Manual", "tags": ["platform", "ops"], "pages": 40,
                                    "source_file": "acme.pdf"}, {}, schema)
    check(props["Name"] == "Acme" and props["Type"] == "Manual" and props["Tags"] == ["platform", "ops"]
          and props["Pages"] == 40 and "date:Imported:start" in props, "property values built", str(props))
    check(d.new_options(mp, [{"type": "Guide", "tags": ["ops", "platform"]}]) == {"type": ["Guide"], "tags": ["ops"]},
          "new select options listed for approval")
    bad = d.map_schema({"properties": [{"name": "Type", "type": "rich_text"}, {"name": "Name", "type": "title"}]})
    check(bad["type"] is None and bad["notes"], "wrong-kind Type property is flagged")

    # ---- style variants render --------------------------------------------
    run(["style", "build", "--preset", "compact"], work)
    res = run(["convert"], work)
    md2 = "\n".join(Path(f).read_text() for p in res["pages"] for f in p["files"])
    check("<table_of_contents/>" in md2 and "PDFNOTION-TOC" not in md2, "compact preset: native contents, no list token")
    run(["style", "build", "--preset", "faithful"], work)
    res = run(["convert"], work)
    md3 = "\n".join(Path(f).read_text() for p in res["pages"] for f in p["files"])
    check("<callout" not in md3 and "**Warning:**" in md3, "faithful preset: callouts stay plain text with their label")
    run(["style", "build", "--preset", "readable", "--lang", "hu"], work)
    res = run(["convert"], work)
    md4 = "\n".join(Path(f).read_text() for p in res["pages"] for f in p["files"])
    check("Forrás:" in md4, "Hungarian labels follow the language setting")

    ok = sum(1 for r, _ in RESULTS if r)
    print(f"\n{ok}/{len(RESULTS)} checks passed")
    if keep:
        print("kept:", tmp)
    else:
        shutil.rmtree(tmp, ignore_errors=True)
    return 0 if ok == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
