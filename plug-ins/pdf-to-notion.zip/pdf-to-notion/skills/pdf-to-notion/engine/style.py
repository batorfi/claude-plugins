"""style.json: presets, merging, validation, plain-language summary, applicability, profiles."""
from __future__ import annotations

import json
from pathlib import Path

from common import Project, deep_merge, now_iso, read_json, write_json

DEFAULTS_PATH = Path(__file__).resolve().parents[3] / "defaults.json"

PRESETS = {
    "faithful": {
        "structure": {"collapsible": {"mode": "none"}, "toc": "none", "dividers": "none"},
        "look": {
            "callouts": {"enabled": False},
            "color": {"headings": False, "callouts_by_type": False, "table_header": False},
            "page_icon": "none",
        },
        "blocks": {"footnotes": "inline"},
        "chrome": {"source_line": False},
    },
    "readable": {},
    "compact": {
        "structure": {"collapsible": {"mode": "all"}, "toc": "native",
                      "heading_map": {"deeper": "bold"}},
        "look": {"page_icon": "none"},
        "blocks": {"footnotes": "collapsible"},
    },
}

ENUMS = {
    "structure.heading_map.mode": {"auto", "manual"},
    "structure.heading_map.deeper": {"bold", "toggle", "merge"},
    "structure.chapter_numbering": {"keep", "strip"},
    "structure.collapsible.mode": {"none", "all", "long", "appendix"},
    "structure.toc": {"native", "parent_list", "none"},
    "structure.dividers": {"between_sections", "none"},
    "look.callouts.icons": {"per_type", "single", "none"},
    "look.color.palette": {"muted", "mono"},
    "look.page_icon": {"by_type", "none"},
    "look.page_cover.mode": {"none", "url"},
    "blocks.tables.wide": {"keep", "split"},
    "blocks.images.numbering": {"keep", "drop"},
    "blocks.images.placement": {"inline", "end_of_section"},
    "blocks.quotes": {"preserve", "plain"},
    "blocks.lists": {"preserve", "flatten"},
    "blocks.footnotes": {"inline", "collapsible"},
    "chrome.navigation.placement": {"bottom", "top_and_bottom"},
    "chrome.navigation.layout": {"single_line"},
    "chrome.navigation.link_labels": {"title", "generic", "both"},
    "chrome.navigation.single_page_footer": {"contents", "none"},
}

NOTION_COLORS = {"gray", "brown", "orange", "yellow", "green", "blue", "purple", "pink", "red"}

# group key -> (what it controls, needs-feature or None)
GROUPS = [
    ("structure.heading_map", "Heading levels", "headings"),
    ("structure.chapter_numbering", "Chapter numbering", "headings"),
    ("structure.collapsible", "Collapsible sections", None),
    ("structure.toc", "Table of contents", None),
    ("structure.dividers", "Dividers between sections", "headings"),
    ("look.callouts", "Callouts (notes, warnings, tips)", "callouts"),
    ("look.color", "Colors", None),
    ("look.page_icon", "Page icons", None),
    ("look.page_cover", "Page cover", None),
    ("blocks.tables", "Tables", "tables"),
    ("blocks.images", "Images", "images"),
    ("blocks.code_quotes", "Code and quotes", "code_or_quotes"),
    ("blocks.lists", "Lists", "list_items"),
    ("blocks.footnotes", "Footnotes", "footnotes"),
    ("chrome.attach_original_pdf", "Attach the original PDF", None),
    ("chrome.source_line", "Source line", None),
    ("chrome.navigation", "Navigation links", "split_pdfs"),
    ("split", "Splitting and image size filter", None),
]


def load_defaults() -> dict:
    d = read_json(DEFAULTS_PATH)
    if d is None:
        raise SystemExit(f"defaults.json not found at {DEFAULTS_PATH}")
    return d


def get_path(d: dict, dotted: str):
    cur = d
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def set_path(d: dict, dotted: str, value) -> None:
    parts = dotted.split(".")
    cur = d
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
    cur[parts[-1]] = value


def resolve_labels(defaults: dict, language: str) -> tuple[dict, bool]:
    table = defaults["labels"]
    if language in table:
        return dict(table[language]), False
    return dict(table["en"]), True  # caller must supply a translation


def build(preset: str = "readable", answers: dict | None = None, language: str | None = None) -> dict:
    if preset not in PRESETS:
        raise SystemExit(f"unknown preset {preset!r}; choose from {sorted(PRESETS)}")
    defaults = load_defaults()
    style = deep_merge(defaults, PRESETS[preset])
    style["preset"] = preset
    answers = dict(answers or {})
    label_override = answers.pop("labels", None)  # flat {"previous": "...", ...} for the chosen language
    if answers:
        style = deep_merge(style, answers)
    lang = language or style.get("language", "en")
    style["language"] = lang
    labels, needs_translation = resolve_labels(defaults, lang)
    if isinstance(label_override, dict) and label_override:
        labels = deep_merge(labels, label_override)
        needs_translation = False
    style["labels"] = labels
    style["labels_need_translation"] = needs_translation
    style["built"] = now_iso()
    problems = validate(style)
    if problems:
        raise SystemExit("invalid style: " + "; ".join(problems))
    return style


def validate(style: dict) -> list[str]:
    problems = []
    for dotted, allowed in ENUMS.items():
        val = get_path(style, dotted)
        if val is not None and val not in allowed:
            problems.append(f"{dotted}={val!r} not in {sorted(allowed)}")
    accent = get_path(style, "look.color.accent")
    if accent is not None and accent not in NOTION_COLORS:
        problems.append(f"look.color.accent={accent!r} not a Notion colour {sorted(NOTION_COLORS)}")
    lv = get_path(style, "structure.heading_map.levels") or {}
    for k, v in lv.items():
        if str(v) not in {"1", "2", "3"}:
            problems.append(f"heading level map {k}->{v}: Notion supports levels 1-3")
    nav_layout = get_path(style, "chrome.navigation.layout")
    if nav_layout not in (None, "single_line"):
        problems.append("only the single_line navigation layout exists in v1")
    mc = get_path(style, "look.page_cover.mode")
    if mc == "url" and not get_path(style, "look.page_cover.url"):
        problems.append("look.page_cover.mode=url needs look.page_cover.url")
    return problems


def describe(style: dict, skip: set[str] | None = None) -> list[dict]:
    """Plain-language summary rows for the Quick run confirmation and the Gate 2 approval."""
    skip = skip or set()
    g = lambda p: get_path(style, p)  # noqa: E731
    col = g("look.color")
    colour_bits = [n for n, on in (("headings", col["headings"]), ("callouts by type", col["callouts_by_type"]),
                                   ("table header rows", col["table_header"])) if on]
    nav = g("chrome.navigation")
    coll = g("structure.collapsible")
    rows = {
        "structure.heading_map": (
            "Heading levels",
            "automatic (top section = H1, then H2, H3); deeper levels: " + g("structure.heading_map.deeper")
            if g("structure.heading_map.mode") == "auto"
            else f"manual {g('structure.heading_map.levels')}; deeper levels: {g('structure.heading_map.deeper')}"),
        "structure.chapter_numbering": ("Chapter numbering", g("structure.chapter_numbering")),
        "structure.collapsible": (
            "Collapsible sections",
            "off" if coll["mode"] == "none" else
            f"{coll['mode']}" + (f" (over {coll['min_words']} words)" if coll["mode"] == "long" else "")
),
        "structure.toc": ("Table of contents", g("structure.toc").replace("_", " ")),
        "structure.dividers": ("Dividers", g("structure.dividers").replace("_", " ")),
        "look.callouts": ("Callouts", "on, icons " + g("look.callouts.icons").replace("_", " ")
                          if g("look.callouts.enabled") else "off (plain text)"),
        "look.color": ("Colors", (", ".join(colour_bits) or "none") + f" (accent {col['accent']}, {col['palette']} palette)"),
        "look.page_icon": ("Page icons", g("look.page_icon").replace("_", " ")),
        "look.page_cover": ("Page cover", "none" if g("look.page_cover.mode") == "none"
                            else g("look.page_cover.url")),
        "blocks.tables": ("Tables", "native Notion tables, header row "
                          + ("on" if g("blocks.tables.header_row") else "off")
                          + (", header column on" if g("blocks.tables.header_column") else "")
                          + f", wide tables: {g('blocks.tables.wide')}"),
        "blocks.images": ("Images", f"captions {'on' if g('blocks.images.captions') else 'off'}, "
                          f"figure numbers {g('blocks.images.numbering')}, placement "
                          + g("blocks.images.placement").replace("_", " ")),
        "blocks.code_quotes": ("Code and quotes", f"code blocks {'on' if g('blocks.code.blocks') else 'off'}, "
                               f"quotes {g('blocks.quotes')}"),
        "blocks.lists": ("Lists", g("blocks.lists")),
        "blocks.footnotes": ("Footnotes", g("blocks.footnotes")),
        "chrome.attach_original_pdf": ("Original PDF attached", "yes" if g("chrome.attach_original_pdf") else "no"),
        "chrome.source_line": ("Source line", "yes" if g("chrome.source_line") else "no"),
        "chrome.navigation": (
            "Navigation links",
            "off" if not nav["enabled"] else
            f"{nav['placement'].replace('_', ' ')}, labels {nav['link_labels']}, "
            f"contents link {'yes' if nav['contents_link'] else 'no'}, divider {'yes' if nav['divider'] else 'no'}"),
        "split": ("Splitting", f"over {g('split.threshold_pages')} pages or {g('split.threshold_words')} words; "
                  f"images under {g('split.min_image_px')}px dropped"),
    }
    out = []
    for key, title, _ in GROUPS:
        if key in skip:
            continue
        label, value = rows[key]
        out.append({"key": key, "option": label, "value": value})
    return out


def applicable(inventory: dict) -> dict:
    """Which option groups matter for these PDFs (others are listed as skipped)."""
    f = inventory.get("features", {})
    have = {
        "headings": f.get("headings", 0) > 0,
        "callouts": f.get("callout_candidates", 0) > 0,
        "tables": f.get("tables", 0) > 0,
        "images": f.get("images", 0) > 0,
        "code_or_quotes": (f.get("code_blocks", 0) + f.get("quotes", 0)) > 0,
        "list_items": f.get("list_items", 0) > 0,
        "footnotes": f.get("footnote_candidates", 0) > 0,
        "split_pdfs": f.get("split_pdfs", 0) > 0,
    }
    ask, skipped = [], []
    for key, title, need in GROUPS:
        if need is None or have.get(need, True):
            ask.append({"key": key, "title": title})
        else:
            skipped.append({"key": key, "title": title, "reason": f"none found in these PDFs ({need})"
                            if need != "split_pdfs" else "no PDF is split into subpages"})
    return {"ask": ask, "skipped": skipped}


def save_profile(proj: Project, name: str, style: dict) -> str:
    proj.profiles.mkdir(parents=True, exist_ok=True)
    keep = json.loads(json.dumps(style))
    for k in ("built", "labels_need_translation"):
        keep.pop(k, None)
    path = proj.profiles / f"{name}.json"
    write_json(path, keep)
    return str(path)


def load_profile(proj: Project, name: str) -> dict:
    data = read_json(proj.profiles / f"{name}.json")
    if data is None:
        raise SystemExit(f"profile {name!r} not found in {proj.profiles}")
    style = deep_merge(load_defaults(), data)
    style["labels"] = data.get("labels") or resolve_labels(load_defaults(), style["language"])[0]
    style["labels_need_translation"] = False
    style["built"] = now_iso()
    problems = validate(style)
    if problems:
        raise SystemExit("invalid profile: " + "; ".join(problems))
    return style
