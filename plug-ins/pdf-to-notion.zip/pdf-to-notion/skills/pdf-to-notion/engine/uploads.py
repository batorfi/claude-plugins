"""Image (and original-PDF) uploads: prepare the queue locally, POST files to Notion's upload URLs.

Flow per file (Claude does step 1 with the Notion connector, this module does 2 and 3):
  1. notion-create-file-upload {filename}        -> upload_url + upload_headers + file upload id
  2. uploads.send(url, headers, file)            -> multipart POST (one request per file, <= 20 MiB)
  3. uploads.record(...)                         -> keeps markdown_source / suggested_markdown in manifest.json
"""
from __future__ import annotations

import io
import json
import mimetypes
import urllib.error
import urllib.request
import uuid
from pathlib import Path

from common import Project, log, read_json, sha1_file, write_json
import manifest as mf

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    Image = None  # type: ignore


def shrink_image(src: Path, dest: Path, limit: int) -> Path:
    """Recompress until the file fits the upload limit (JPEG, then progressively smaller)."""
    if src.stat().st_size <= limit:
        return src
    if Image is None:
        raise SystemExit(f"{src.name} is over the upload limit and Pillow is not installed to shrink it")
    img = Image.open(src)
    if img.mode in ("RGBA", "LA", "P"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        rgba = img.convert("RGBA")
        bg.paste(rgba, mask=rgba.split()[-1])
        img = bg
    else:
        img = img.convert("RGB")
    dest.parent.mkdir(parents=True, exist_ok=True)
    quality, scale = 88, 1.0
    for _ in range(12):
        w, h = int(img.width * scale), int(img.height * scale)
        buf = io.BytesIO()
        img.resize((w, h)).save(buf, "JPEG", quality=quality, optimize=True)
        if buf.tell() <= limit:
            dest.write_bytes(buf.getvalue())
            return dest
        quality = max(60, quality - 8)
        scale *= 0.85
    raise SystemExit(f"could not shrink {src.name} under {limit} bytes")


def prepare(proj: Project, style: dict, m: dict) -> dict:
    plan = read_json(proj.plan, {"pdfs": []})
    limit = style["limits"]["max_upload_bytes"]
    queue, skipped = [], []
    for pdf in plan["pdfs"]:
        slug = pdf["slug"]
        entry = m["pdfs"].setdefault(slug, {"chapters": [], "images": {}})
        imgs = read_json(proj.extract / slug / "images.json", [])
        for rec in imgs:
            if not rec.get("file"):
                continue
            src = Path(rec["file"])
            up = shrink_image(src, proj.extract / slug / "images" / "upload" / (rec["id"] + ".jpg"), limit)
            cur = entry["images"].setdefault(rec["id"], {})
            digest = sha1_file(up)
            if cur.get("sha1") != digest:
                cur.pop("markdown_source", None)
                cur.pop("suggested_markdown", None)
            cur.update({"file": str(src), "upload_file": str(up), "bytes": up.stat().st_size, "sha1": digest})
            if not cur.get("markdown_source") and not cur.get("suggested_markdown"):
                queue.append({"slug": slug, "id": rec["id"], "kind": "image", "upload_file": str(up),
                              "filename": up.name, "bytes": up.stat().st_size})
        if style["chrome"]["attach_original_pdf"]:
            src = Path(pdf["source"])
            if src.stat().st_size > limit:
                skipped.append({"slug": slug, "reason": f"original PDF is {src.stat().st_size // 1024} KiB, over the "
                                                         f"{limit // 1048576} MiB upload limit; not attached"})
                entry.pop("original_pdf", None)
            else:
                cur = entry.setdefault("original_pdf", {})
                digest = sha1_file(src)
                if cur.get("sha1") != digest:
                    cur.pop("markdown_source", None)
                    cur.pop("suggested_markdown", None)
                cur.update({"upload_file": str(src), "sha1": digest, "bytes": src.stat().st_size})
                entry["original_pdf_expected"] = True
                if not cur.get("markdown_source") and not cur.get("suggested_markdown"):
                    queue.append({"slug": slug, "id": "original_pdf", "kind": "pdf", "upload_file": str(src),
                                  "filename": src.name, "bytes": src.stat().st_size})
    mf.save(proj, m)
    write_json(proj.build / "uploads-queue.json", {"queue": queue, "skipped": skipped})
    return {"to_upload": len(queue), "queue": queue, "skipped": skipped}


def send(url: str, headers: dict, file: Path, filename: str | None = None) -> dict:
    """One multipart/form-data POST with the file in the `file` field. Header values are never logged."""
    file = Path(file)
    boundary = "----pdfnotion" + uuid.uuid4().hex
    ctype = mimetypes.guess_type(filename or file.name)[0] or "application/octet-stream"
    head = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{filename or file.name}\"\r\n"
            f"Content-Type: {ctype}\r\n\r\n").encode()
    tail = f"\r\n--{boundary}--\r\n".encode()
    body = head + file.read_bytes() + tail
    hdrs = {k: v for k, v in headers.items() if k.lower() not in ("content-type", "content-length")}
    hdrs["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    req = urllib.request.Request(url, data=body, headers=hdrs, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            raw = resp.read().decode("utf-8", "replace")
            status = resp.status
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        raise SystemExit(f"upload failed: HTTP {e.code}: {detail}")
    except urllib.error.URLError as e:
        raise SystemExit(f"upload failed: {e.reason}")
    try:
        data = json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        data = {"raw": raw[:500]}
    data["_status"] = status
    return data


def _find_key(obj, key: str):
    if isinstance(obj, dict):
        if key in obj and obj[key]:
            return obj[key]
        for v in obj.values():
            r = _find_key(v, key)
            if r:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find_key(v, key)
            if r:
                return r
    return None


def record(proj: Project, slug: str, item_id: str, response: dict, file_upload_id: str | None = None) -> dict:
    src = _find_key(response, "markdown_source")
    sug = _find_key(response, "suggested_markdown")
    if not (src or sug):
        raise SystemExit("upload response has neither markdown_source nor suggested_markdown; "
                         "check that the upload succeeded before recording it")
    fields = {"markdown_source": src, "suggested_markdown": sug,
              "file_upload_id": file_upload_id or _find_key(response, "id")}
    if item_id == "original_pdf":
        m = mf.load(proj)
        entry = m["pdfs"][slug]
        entry.setdefault("original_pdf", {}).update({k: v for k, v in fields.items() if v})
        mf.save(proj, m)
        return entry["original_pdf"]
    return mf.record_upload(proj, slug, item_id, **fields)
