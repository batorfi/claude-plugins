"""Verification: compare what was built with what Notion now holds.

Claude fetches each created page (notion-fetch) and saves its markdown as <fetched_dir>/<page_id>.md
(32-hex id, no dashes). Counts of headings, tables and images must match what the converter produced,
words must be within a tolerance, and navigation links must point at the right neighbours.
"""
from __future__ import annotations

import re
from pathlib import Path

from common import Project, normalize_id, read_json, write_json, write_text
from navigation import find_footers, page_url
from notion_md import count_markdown

WORD_TOLERANCE = 0.10


def _ids_in(text: str) -> list[str]:
    return [m.lower() for m in re.findall(r"(?<![0-9a-fA-F])([0-9a-fA-F]{32})(?![0-9a-fA-F])", text.replace("-", ""))]


def verify(proj: Project, style: dict, manifest: dict, fetched_dir: Path, fetched_props: dict | None = None) -> dict:
    built = read_json(proj.build / "pages.json", {"pages": []})
    plan = read_json(proj.plan, {"pdfs": []})
    nav_on = style["chrome"]["navigation"]["enabled"]
    rows, problems = [], 0
    chapter_ids: dict[str, list[dict]] = {}
    for pdf in plan["pdfs"]:
        entry = manifest["pdfs"].get(pdf["slug"], {})
        chapter_ids[pdf["slug"]] = entry.get("chapters", [])

    for p in built["pages"]:
        entry = manifest["pdfs"].get(p["slug"], {})
        if p["kind"] == "pdf":
            rec = entry.get("notion", {})
        else:
            rec = next((c for c in entry.get("chapters", []) if c["id"] == p["chapter_id"]), {})
        pid = normalize_id(rec.get("page_id", ""))
        row = {"title": p["title"], "kind": p["kind"], "page_id": pid, "checks": [], "status": "ok"}
        if not pid:
            row["status"] = "missing"
            row["checks"].append("page was never created")
            rows.append(row)
            problems += 1
            continue
        f = fetched_dir / f"{pid}.md"
        if not f.exists():
            row["status"] = "not-fetched"
            row["checks"].append(f"no fetched copy at {f.name}")
            rows.append(row)
            problems += 1
            continue
        actual = count_markdown(f.read_text(encoding="utf-8"))
        expected = p["counts"]
        for key in ("headings", "tables", "images"):
            if actual[key] != expected[key]:
                row["checks"].append(f"{key}: expected {expected[key]}, found {actual[key]}")
        # footers and the contents list add words/links; compare body words with slack
        if expected["words"]:
            diff = abs(actual["words"] - expected["words"]) / expected["words"]
            if diff > WORD_TOLERANCE + (0.15 if nav_on else 0):
                row["checks"].append(f"words: expected about {expected['words']}, found {actual['words']}")
        if "pending:" in f.read_text(encoding="utf-8"):
            row["checks"].append("an image is still a pending: placeholder")
        if nav_on and p["kind"] == "chapter":
            chs = chapter_ids[p["slug"]]
            idx = next((i for i, c in enumerate(chs) if c["id"] == p["chapter_id"]), None)
            top = normalize_id((entry.get("notion") or {}).get("page_id", ""))
            footers = find_footers(f.read_text(encoding="utf-8"))
            foot = footers["bottom"] or ""
            ids = set(_ids_in(foot))
            if not foot:
                row["checks"].append("navigation footer not found")
            else:
                want_prev = normalize_id(chs[idx - 1]["page_id"]) if idx and idx > 0 else None
                want_next = normalize_id(chs[idx + 1]["page_id"]) if idx is not None and idx + 1 < len(chs) else None
                if want_prev and want_prev not in ids:
                    row["checks"].append("footer does not link to the previous chapter")
                if want_next and want_next not in ids:
                    row["checks"].append("footer does not link to the next chapter")
                allowed = {x for x in (want_prev, want_next, top) if x}
                if ids - allowed:
                    row["checks"].append("footer links to a page that is not its previous, next or contents page")
                if style["chrome"]["navigation"]["contents_link"] and top and top not in ids:
                    row["checks"].append("footer does not link back to the contents page")
        if fetched_props and p["kind"] == "pdf":
            got = fetched_props.get(pid) or fetched_props.get(rec.get("page_id", ""))
            if got is not None:
                for key, want in (("type", entry.get("type")), ("tags", entry.get("tags"))):
                    if want in (None, [], "") or key not in got:
                        continue
                    have = got[key]
                    if isinstance(want, list):
                        if sorted(map(str, have if isinstance(have, list) else [have])) != sorted(want):
                            row["checks"].append(f"{key}: expected {want}, found {have}")
                    elif str(have) != str(want):
                        row["checks"].append(f"{key}: expected {want}, found {have}")
        if row["checks"]:
            row["status"] = "check"
            problems += 1
        rows.append(row)

    report = {"pages_checked": len(rows), "pages_with_problems": problems, "rows": rows}
    write_json(proj.build / "verify.json", report)
    lines = [f"# Verification report", "", f"{len(rows)} pages checked, {problems} with problems.", ""]
    for r in rows:
        mark = "OK " if r["status"] == "ok" else "!! "
        lines.append(f"- {mark}{r['title']} ({r['kind']})")
        for c in r["checks"]:
            lines.append(f"    - {c}")
    write_text(proj.build / "verify.md", "\n".join(lines) + "\n")
    return report
