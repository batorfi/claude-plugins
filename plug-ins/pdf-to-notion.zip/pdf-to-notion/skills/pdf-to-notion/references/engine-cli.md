# Engine CLI reference

`ENGINE` = `python3 <skill folder>/engine/pdfnotion.py [--work DIR] [--project NAME] [--language en|hu]`

JSON goes to stdout, logs to stderr. The work folder defaults to `$PDF_TO_NOTION_WORK`, then `./pdf-to-notion-work`.
A project lives in `<work>/<project>/`:

```
manifest.json    destination, pages created, uploads, gate timestamps (the resume record)
inventory.json   what was found in each PDF
plan.json        page tree and split plan (editable until Gate 1)
style.json       the approved formatting choices
extract/<slug>/  pages.json (blocks), images.json, images/, summary.json
build/           pages/*.md (Notion markdown), pages.json, nav.json, verify.md
profiles/        saved style profiles (in <work>/profiles)
```

| Command | Purpose |
|---|---|
| `doctor` | Check PyMuPDF, Pillow, tesseract, defaults.json |
| `inspect PATH... [--recursive] [--split-pages N --split-words N --range-pages N --min-image-px N]` | Inventory + split plan; prints the page tree |
| `tree` | Re-print the page tree with the chosen destination |
| `plan split-off SLUG` / `ranges SLUG N` / `rename SLUG IDX TITLE` / `merge SLUG A B` | Edit the split plan |
| `dest parse VALUE` | Notion URL or id -> 32-hex id |
| `dest map SCHEMA_JSON` | Map a database schema: Type, Tags, auto-fill candidates, read-only properties, notes |
| `dest set JSON` | Save the confirmed destination in the manifest |
| `dest props SPEC_JSON` | Build `properties` for every PDF page, and list select options that would be new |
| `classify [--existing JSON]` | Suggested Type and Tags per PDF, preferring existing database options |
| `record JSON` | Save approved per-PDF Type and Tags |
| `style presets` / `build --preset P [--lang L] [--answers JSON]` / `describe` / `applicable` / `set KEY JSON` / `profile-save NAME` / `profile-load NAME` / `profile-list` / `approve` | Style handling |
| `extract [--ocr-lang hun+eng]` | Text, tables, images to disk (OCR only for pages without a text layer) |
| `uploads prepare` | Queue of images (and original PDFs) still to upload; shrinks files over 20 MiB |
| `uploads send --url U --headers JSON --file F [--filename N]` | One multipart POST to Notion's upload URL |
| `uploads record --slug S --id I --response JSON [--file-upload-id ID]` | Keep the returned markdown reference |
| `convert [--allow-pending]` | Block model + style -> Notion markdown files and `build/pages.json` |
| `nav build` / `nav find --file F` | Footer markdown per page / locate an existing footer in a fetched page |
| `toc build` / `toc find --file F` | Contents list for each split PDF's top page / locate an existing one |
| `manifest status` / `mark STEP [NOTE]` / `record-page SLUG CHAPTER\|- --page-id ID [--url U]` / `show` | Resume state |
| `verify --fetched DIR [--props JSON]` | Compare fetched pages with what was built |
| `status` | Next step to run |

Steps recorded in the manifest, in order: `inspect, destination, gate1, style, extract, uploads, pages, nav, verify`.

`python3 <skill folder>/engine/selftest.py` builds sample PDFs and runs the whole local pipeline (needs reportlab).
