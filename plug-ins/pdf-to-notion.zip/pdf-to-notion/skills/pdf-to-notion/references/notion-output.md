# How the Notion pages are built

## Page tree

- A PDF under the page limits becomes **one page** (title from the PDF's metadata, first big heading, or file name).
- A long PDF becomes a **top page** (overview line, contents list, original PDF) with one **subpage per chapter**.
  Split points: top level of the PDF outline, else detected top-level headings, else ranges of 15 pages.
- Destination kinds: an existing **page** (top pages become its children), a **database** (each PDF becomes one entry
  with properties; chapter subpages are ordinary child pages of the entry and carry no properties), or a **private
  draft** (workspace-level private page to move later; never the default).

## Two passes

1. **Pass 1, pages**: top page, then chapters (parent = top page). Images and the original PDF are uploaded first
   (`notion-create-file-upload`, then one multipart POST per file, 20 MiB limit) and referenced by the returned markdown.
2. **Pass 2, links**: the page ids now exist, so the contents list replaces the `PDFNOTION-TOC` placeholder on each top
   page and every chapter gets its footer `← Previous | ↑ Contents | Next →` (page mentions, so renamed pages keep
   working). The footer is plain markdown at the end of the page (a `---` divider, then one line), which is how a
   re-run finds and replaces it instead of adding a second one.

## Conversion rules (style.json decides the options)

- Heading levels are relative to the page: the chapter heading becomes the page title; top sections are H1, then H2, H3.
- Lists keep nesting (tabs); numbered lists restart at 1; tables become native tables (cells hold rich text only).
- Detected notes / warnings / tips / examples (English and Hungarian keywords) become callouts.
- Figures keep their caption; images repeated on many pages (logos) and images smaller than the size filter are dropped;
  charts drawn as vector graphics are rendered as images.
- Running headers, footers and page numbers are removed; hyphenated line breaks are joined; paragraphs split by a page
  break are re-joined; two-column pages are read column by column.
- Special characters `\ * ~ ` $ [ ] < > { } | ^` are escaped in plain text.
- Pages over 60,000 characters are written in parts: the first part on creation, the rest appended in order.

## What the converter is not

It reads text, tables and images. It does not reproduce page layout, fonts, or exact positioning, and it cannot read
text inside scanned pages without OCR. Math, heavily designed pages and forms come out as plain text and need a look.
