# Formatting options (Custom run) and how they map to style.json

The Custom run asks these groups, in this order, four questions at a time (AskUserQuestion allows
1-4 questions of 2-4 options each; "Other" is always available). Put the recommended option first and mark it
"(Recommended)". The Quick-run default is the **Readable** preset. Groups that do not apply to the inspected PDFs
(`style applicable` lists them under `skipped`) are not asked; list them once as "skipped, not applicable".

Answers are collected as one nested JSON object and passed to
`ENGINE style build --preset <faithful|readable|compact> --answers '<json>'`. Only changed keys are needed.

## Presets (starting point, every option can still be overridden)

| Preset | What it does |
|---|---|
| Faithful | Mirrors the PDF: no toggles, no contents block, callouts stay plain text, no colors or icons, footnotes inline, no source line |
| **Readable** | Cleaned up for Notion: callouts, toggles for long sections, contents list on the parent, source line, icons by type |
| Compact | Dense reference style: every top-level section is a toggle, native contents block on each page, no icons |

## Group 1: Structure

| Group | Question | Choices -> JSON |
|---|---|---|
| `structure.heading_map` | How should PDF heading levels become Notion headings? | **Automatic** (top section = H1, then H2, H3) -> `{"structure":{"heading_map":{"mode":"auto"}}}`; **Manual** -> `{"mode":"manual","levels":{"1":2,"2":3}}` (maps relative depth to Notion level 1-3) |
| (same group) | What happens to levels deeper than three? | **Bold paragraph** -> `"deeper":"bold"`; **Toggle heading** -> `"deeper":"toggle"`; **Merge into H3** -> `"deeper":"merge"` |
| `structure.chapter_numbering` | Keep the numbers in headings ("2.1 Setup")? | `"keep"` / `"strip"` |
| `structure.collapsible` | Which sections become collapsible toggle headings? | `{"mode":"none"}`; `{"mode":"all"}` every top-level section; `{"mode":"long","min_words":400}` only long sections; `{"mode":"appendix"}` only appendices, references, glossary, footnote sections |
| `structure.toc` | Table of contents? | `"parent_list"` numbered list on the PDF's top page (split PDFs); `"native"` Notion contents block on each page; `"none"` |
| `structure.dividers` | Divider line between top-level sections? | `"between_sections"` / `"none"` |

## Group 2: Look

| Group | Question | Choices -> JSON |
|---|---|---|
| `look.callouts` | Turn detected notes, warnings, tips, examples into callouts? | `{"enabled":true,"icons":"per_type"}` / `"single"` / `"none"`; or `{"enabled":false}` (plain text, label kept in bold) |
| `look.color` | Where should color be used? (combinable) | `{"headings":true,"accent":"blue"}`, `{"callouts_by_type":true}`, `{"table_header":true}`; palette `"muted"` (type colors) or `"mono"` (all gray); accent is any Notion color: gray, brown, orange, yellow, green, blue, purple, pink, red |
| `look.page_icon` | Page icons? | `"by_type"` (emoji by document type, chapters get a page icon) / `"none"` |
| `look.page_cover` | Page cover? | `{"mode":"none"}` or `{"mode":"url","url":"https://..."}` (Notion covers are image URLs only; no solid colors) |

## Group 3: Content blocks

| Group | Question | Choices -> JSON |
|---|---|---|
| `blocks.tables` | Table style? | `header_row` true/false, `header_column` true/false, `wide`: `"keep"` or `"split"` (tables over `max_columns` columns are split, first column repeated) |
| `blocks.images` | Image captions, numbering, placement? | `captions` true/false; `numbering` `"keep"` ("Figure 3: ...") or `"drop"`; `placement` `"inline"` or `"end_of_section"` |
| `blocks.code_quotes` | Code and quotes? | `blocks.code`: `{"blocks":true,"language_guess":true}` or `{"blocks":false}`; `blocks.quotes`: `"preserve"` / `"plain"` |
| `blocks.lists` | Lists? | `"preserve"` nesting / `"flatten"` |
| `blocks.footnotes` | Footnotes? | `"collapsible"` (a toggle at the end of the page) / `"inline"` (small gray paragraphs where they occur) |

## Group 4: Page chrome and navigation

| Group | Question | Choices -> JSON |
|---|---|---|
| `chrome.attach_original_pdf` | Attach the original PDF to the page? | true/false (not attached when over 20 MiB) |
| `chrome.source_line` | "Source: file.pdf · pages 3-14" line on each page? | true/false |
| `chrome.navigation` | Previous / Contents / Next links? | `enabled` true/false; `placement` `"bottom"` or `"top_and_bottom"`; `contents_link` true/false; `link_labels` `"both"` ("Previous: Title"), `"title"` (arrow + page title), `"generic"` ("Previous", a text link; Notion may turn it into a page mention); `divider` true/false; `single_page_footer` `"contents"` or `"none"` (what a PDF that is not split gets) |

The only layout is the single line `← Previous | ↑ Contents | Next →`.

## Split settings (set at Gate 1, repeated in Custom run only for reference)

`split.threshold_pages` (30), `split.threshold_words` (15000), `split.points` (outline, h1, ranges),
`split.range_pages` (15), `split.min_image_px` (64: smaller images such as logos and bullets are dropped).
Split changes need a new `ENGINE inspect` with the flags `--split-pages`, `--split-words`, `--range-pages`,
`--min-image-px`, or the `plan` edits (`split-off`, `ranges N`, `rename`, `merge`).

## What Notion's markdown cannot express (say so plainly if asked)

- **Image width**: no attribute exists; Notion sizes images itself and the width is changed in the UI.
- **Toggle open/closed state**: not stored in the page; toggles start collapsed for each reader.
- **Page cover**: image URL only.
- **Heading levels**: three (Notion accepts a fourth, this plugin does not use it).
- **Colors**: Notion's built-in palette only.
- **Table cells**: rich text only (no lists or images inside cells); merged cells cannot be created.

## Labels and language

All questions, preset names and generated labels follow the language the user writes in. `style build --lang hu`
uses the built-in Hungarian labels; English is the default. For any other language the build reports
`labels_need_translation: true`: translate the nine labels (`previous, next, contents, source, pages, page,
footnotes, front_matter, overview`) and rebuild with `--answers '{"labels":{...}}'`.
Generated page content stays in the PDF's own language.
